import type { LucideIcon } from "lucide-react"
import {
  LayoutDashboard,
  UserCircle,
  BookOpen,
  Users,
  Building2,
  FileClock,
  Microscope,
  BookMarked,
  FileText,
  Lightbulb,
  Award,
  GraduationCap,
  ClipboardList,
  UserCheck,
  Handshake,
  Users2,
  Briefcase,
} from "lucide-react"

// === CONFIGURACIÓN DEL SISTEMA ===

// Tipos de Configuración
export interface ItemMenu {
  id: string
  etiqueta: string
  icono: LucideIcon
  ruta?: string
  subItems?: ItemMenu[]
}

export interface ConfiguracionRubro {
  tipo: string
  etiqueta: string
  descripcion: string
  campos: CampoFormulario[]
}

export interface CampoFormulario {
  id: string
  etiqueta: string
  tipo: "texto" | "numero" | "select" | "textarea"
  placeholder?: string
  ayuda?: string
  opciones?: string[] // Para campos tipo select
  requerido?: boolean
}

export interface EstadoSemaforo {
  categoria: string
  estado: "completado" | "en-proceso" | "pendiente" | "alerta"
  progreso: number
  descripcion: string
  color: "green" | "blue" | "amber" | "red"
}

// === MENÚ DEL SISTEMA (Jerarquía Completa) ===
export const MENU_SISTEMA: ItemMenu[] = [
  {
    id: "inicio",
    etiqueta: "Inicio / Semáforo",
    icono: LayoutDashboard,
    ruta: "/",
  },
  {
    id: "mis-datos",
    etiqueta: "Mis Datos",
    icono: UserCircle,
    ruta: "/profile",
  },
  {
    id: "docencia",
    etiqueta: "Docencia",
    icono: BookOpen,
    subItems: [
      {
        id: "clases-grupo",
        etiqueta: "Clases frente a Grupo",
        icono: Users2,
        ruta: "/teaching/classes",
      },
      {
        id: "material-didactico",
        etiqueta: "Material Didáctico",
        icono: FileText,
        ruta: "/teaching/materials",
      },
      {
        id: "evaluacion-docente",
        etiqueta: "Evaluación Docente",
        icono: ClipboardList,
        ruta: "/teaching/evaluation",
      },
      {
        id: "cursos-diplomados",
        etiqueta: "Cursos y Diplomados",
        icono: GraduationCap,
        ruta: "/teaching/courses",
      },
    ],
  },
  {
    id: "investigacion",
    etiqueta: "Investigación",
    icono: Microscope,
    subItems: [
      {
        id: "articulos-cientificos",
        etiqueta: "Artículos Científicos",
        icono: FileText,
        ruta: "/research/articles",
      },
      {
        id: "libros-capitulos",
        etiqueta: "Libros y Capítulos",
        icono: BookMarked,
        ruta: "/research/books",
      },
      {
        id: "proyectos-investigacion",
        etiqueta: "Proyectos de Investigación",
        icono: Lightbulb,
        ruta: "/research/projects",
      },
      {
        id: "congresos-ponencias",
        etiqueta: "Congresos y Ponencias",
        icono: Users,
        ruta: "/research/congresses",
      },
      {
        id: "patentes-prototipos",
        etiqueta: "Patentes y Prototipos",
        icono: Award,
        ruta: "/research/patents",
      },
      {
        id: "sni",
        etiqueta: "SNI (Sistema Nacional de Investigadores)",
        icono: Award,
        ruta: "/research/sni",
      },
    ],
  },
  {
    id: "tutorias",
    etiqueta: "Tutorías",
    icono: Users,
    subItems: [
      {
        id: "tutoria-permanente",
        etiqueta: "Tutoría Permanente (Individual/Grupal)",
        icono: UserCheck,
        ruta: "/tutoring/permanent",
      },
      {
        id: "direccion-tesis",
        etiqueta: "Dirección de Tesis",
        icono: GraduationCap,
        ruta: "/tutoring/thesis",
      },
      {
        id: "jurado-examenes",
        etiqueta: "Jurado de Exámenes",
        icono: ClipboardList,
        ruta: "/tutoring/jury",
      },
      {
        id: "asesoria-servicio-social",
        etiqueta: "Asesoría Servicio Social",
        icono: Handshake,
        ruta: "/tutoring/social-service",
      },
    ],
  },
  {
    id: "gestion",
    etiqueta: "Gestión",
    icono: Building2,
    subItems: [
      {
        id: "cuerpos-colegiados",
        etiqueta: "Cuerpos Colegiados",
        icono: Users2,
        ruta: "/management/boards",
      },
      {
        id: "comisiones-academicas",
        etiqueta: "Comisiones Académicas",
        icono: Briefcase,
        ruta: "/management/commissions",
      },
      {
        id: "cuerpos-academicos",
        etiqueta: "Cuerpos Académicos (PRODEP)",
        icono: Award,
        ruta: "/management/academic-bodies",
      },
    ],
  },
  {
    id: "mis-expedientes",
    etiqueta: "Mis Expedientes",
    icono: FileClock,
    ruta: "/expedients",
  },
]

// === CONFIGURACIÓN DE RUBROS (Define Campos Dinámicos) ===
export const CONFIGURACION_RUBROS: ConfiguracionRubro[] = [
  {
    tipo: "articulo",
    etiqueta: "Artículo JCR",
    descripcion: "Artículo publicado en revista indexada",
    campos: [
      {
        id: "issn",
        etiqueta: "ISSN",
        tipo: "texto",
        placeholder: "Ej: 1234-5678",
        ayuda: "Lo encuentra en la portada o página legal de la revista",
        requerido: true,
      },
      {
        id: "nombreRevista",
        etiqueta: "Nombre de la Revista",
        tipo: "texto",
        placeholder: "Ej: Nature Chemistry",
        ayuda: "Nombre completo exacto de la publicación",
        requerido: true,
      },
      {
        id: "factorImpacto",
        etiqueta: "Factor de Impacto",
        tipo: "numero",
        placeholder: "Ej: 3.75",
        ayuda: "Valor numérico del factor de impacto (JCR)",
        requerido: true,
      },
      {
        id: "cuartil",
        etiqueta: "Cuartil",
        tipo: "select",
        ayuda: "Posición de la revista en su área (Q1 es el mejor)",
        opciones: ["Q1", "Q2", "Q3", "Q4"],
        requerido: true,
      },
      {
        id: "doi",
        etiqueta: "DOI",
        tipo: "texto",
        placeholder: "Ej: 10.1234/example.doi",
        ayuda: "Identificador único del artículo",
        requerido: false,
      },
    ],
  },
  {
    tipo: "libro",
    etiqueta: "Libro",
    descripcion: "Libro completo o compilación",
    campos: [
      {
        id: "titulo",
        etiqueta: "Título del Libro",
        tipo: "texto",
        placeholder: "Ej: Historia del México Prehispánico",
        ayuda: "Título exacto como aparece en la portada",
        requerido: true,
      },
      {
        id: "isbn",
        etiqueta: "ISBN",
        tipo: "texto",
        placeholder: "Ej: 978-0-134-69418-0",
        ayuda: "Lo encuentra en la página legal del libro",
        requerido: true,
      },
      {
        id: "editorial",
        etiqueta: "Editorial",
        tipo: "texto",
        placeholder: "Ej: Fondo de Cultura Económica",
        ayuda: "Nombre completo de la editorial",
        requerido: true,
      },
      {
        id: "pais",
        etiqueta: "País de Publicación",
        tipo: "texto",
        placeholder: "Ej: México",
        ayuda: "País donde se publicó el libro",
        requerido: true,
      },
    ],
  },
  {
    tipo: "capitulo",
    etiqueta: "Capítulo de Libro",
    descripcion: "Capítulo en libro colaborativo",
    campos: [
      {
        id: "tituloCapitulo",
        etiqueta: "Título del Capítulo",
        tipo: "texto",
        placeholder: "Ej: Análisis de sistemas educativos",
        requerido: true,
      },
      {
        id: "tituloLibro",
        etiqueta: "Título del Libro",
        tipo: "texto",
        placeholder: "Ej: Tendencias en Educación Superior",
        requerido: true,
      },
      {
        id: "autores",
        etiqueta: "Autores del Capítulo",
        tipo: "texto",
        placeholder: "Ej: Dr. Juan Pérez, Dra. María López",
        ayuda: "Separe múltiples autores con comas",
        requerido: true,
      },
      {
        id: "isbn",
        etiqueta: "ISBN",
        tipo: "texto",
        placeholder: "Ej: 978-0-134-69418-0",
        requerido: true,
      },
      {
        id: "editorial",
        etiqueta: "Editorial",
        tipo: "texto",
        placeholder: "Ej: Fondo de Cultura Económica",
        requerido: true,
      },
    ],
  },
  {
    tipo: "clase",
    etiqueta: "Clase Frente a Grupo",
    descripcion: "Registro de actividad docente",
    campos: [
      {
        id: "nombreAsignatura",
        etiqueta: "Nombre de la Asignatura",
        tipo: "texto",
        placeholder: "Ej: Cálculo Diferencial",
        requerido: true,
      },
      {
        id: "semestre",
        etiqueta: "Semestre",
        tipo: "select",
        opciones: ["2024-1", "2024-2", "2025-1", "2025-2"],
        requerido: true,
      },
      {
        id: "numeroAlumnos",
        etiqueta: "Número de Alumnos",
        tipo: "numero",
        placeholder: "Ej: 35",
        requerido: true,
      },
    ],
  },
  {
    tipo: "patente",
    etiqueta: "Patente",
    descripcion: "Patente registrada o en trámite",
    campos: [
      {
        id: "numeroPatente",
        etiqueta: "Número de Patente",
        tipo: "texto",
        placeholder: "Ej: US 10,123,456 B2",
        ayuda: "Número asignado por la oficina de patentes",
        requerido: true,
      },
      {
        id: "tituloPatente",
        etiqueta: "Título de la Patente",
        tipo: "texto",
        placeholder: "Ej: Sistema de procesamiento avanzado",
        requerido: true,
      },
      {
        id: "nombresInventores",
        etiqueta: "Nombres de Inventores",
        tipo: "texto",
        placeholder: "Ej: Dr. Juan Pérez, Ing. Carlos López",
        ayuda: "Separe múltiples nombres con comas",
        requerido: true,
      },
    ],
  },
]

// === ESTADO INICIAL DEL SEMÁFORO (Dashboard) ===
export const ESTADO_SEMAFORO: EstadoSemaforo[] = [
  {
    categoria: "Docencia",
    estado: "completado",
    progreso: 100,
    descripcion: "4 clases activas registradas",
    color: "green",
  },
  {
    categoria: "Investigación",
    estado: "en-proceso",
    progreso: 75,
    descripcion: "2 artículos pendientes de revisión",
    color: "blue",
  },
  {
    categoria: "Tutorías",
    estado: "alerta",
    progreso: 85,
    descripcion: "12 alumnos asignados",
    color: "amber",
  },
  {
    categoria: "Expediente",
    estado: "completado",
    progreso: 100,
    descripcion: "Documentación 2024 al día",
    color: "green",
  },
]

// === DATOS DEL USUARIO (Simulado, se reemplazará con Backend) ===
export const DATOS_USUARIO = {
  nombre: "Dr. Juan Pérez",
  categoria: "PTC Titular C",
  institucion: "UABJO",
  facultad: "Ciencias Químicas",
  iniciales: "JP",
}

// === INFORMACIÓN DE CONVOCATORIA ===
export const INFO_CONVOCATORIA = {
  anio: "2025",
  estado: "ABIERTA",
  diasRestantes: 15,
}
