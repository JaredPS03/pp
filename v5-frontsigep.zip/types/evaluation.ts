// Core Types for the Teacher Evaluation Platform
// These interfaces define the exact JSON structure the backend needs to provide

export interface UploadedFile {
  id: string
  name: string
  size: string
  type: "main" | "complementary"
  uploadedAt?: string
  url?: string
}

export interface ForeignDocumentFields {
  country: string
  validationNumber: string
}

export interface RequirementItem {
  id: string
  title: string
  description: string
  isRequired: boolean
  hasNationalForeignToggle?: boolean
  isNational?: boolean
  foreignFields?: ForeignDocumentFields
  // State (managed by frontend, but can be pre-populated from backend)
  mainFile: UploadedFile | null
  complementaryFiles: UploadedFile[]
}

export interface EvaluationRubric {
  id: string
  code: string // e.g., "I.1", "II.2", "0"
  title: string
  description?: string
  sectionType: "generales" | "rubric" // "generales" has no scores
  // Score config (only for rubric type)
  scoring?: {
    minScore: number
    maxScore: number
    expectedScore?: number
  }
  // Requirements/documents to upload
  requirements: RequirementItem[]
  // Navigation
  nextRubricId?: string
  prevRubricId?: string
  nextRubricTitle?: string
  prevRubricTitle?: string
}

export interface ConfirmationChecklist {
  documentsComplete: boolean
  infoAccurate: boolean
  acceptTerms: boolean
}

export interface RubricState {
  requirements: RequirementItem[]
  confirmations: ConfirmationChecklist
  expectedScore: string
  comments: string
}

// Navigation context for the sidebar
export interface EvaluationSection {
  id: string
  code: string
  title: string
  icon?: string
  items?: EvaluationSection[]
}

// API Response types (for backend integration)
export interface GetRubricResponse {
  success: boolean
  data: EvaluationRubric
}

export interface SaveRubricRequest {
  rubricId: string
  requirements: RequirementItem[]
  confirmations: ConfirmationChecklist
  expectedScore?: string
  comments?: string
}

export interface SaveRubricResponse {
  success: boolean
  message: string
}
