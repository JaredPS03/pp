import { LayoutSistema } from "@/components/layout-sistema"
import { FormularioEvidenciaDinamico } from "@/components/formulario-evidencia-dinamico"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { FileCheck2, Clock, AlertCircle } from "lucide-react"

export default function PaginaEvidencias() {
  // TODO: Conectar con Server Action para obtener datos del historial de evidencias desde base de datos
  const historialEvidencias = [
    {
      id: 1,
      tipo: "Artículo JCR",
      titulo: "Optimization Algorithms for Machine Learning",
      fecha: "2024-12-15",
      estado: "Validado",
      cuartil: "Q1",
    },
    {
      id: 2,
      tipo: "Libro",
      titulo: "Diseño de Sistemas Escalables",
      fecha: "2024-11-20",
      estado: "Revisión",
      cuartil: "-",
    },
    {
      id: 3,
      tipo: "Clase",
      titulo: "Ingeniería de Software - 2024-A",
      fecha: "2024-10-10",
      estado: "Validado",
      cuartil: "-",
    },
  ]

  const obtenerIconoEstado = (estado: string) => {
    switch (estado) {
      case "Validado":
        return <FileCheck2 className="h-4 w-4 text-green-600" />
      case "Revisión":
        return <Clock className="h-4 w-4 text-blue-600" />
      default:
        return <AlertCircle className="h-4 w-4 text-amber-600" />
    }
  }

  const obtenerVarianteBadge = (estado: string) => {
    switch (estado) {
      case "Validado":
        return "default"
      case "Revisión":
        return "secondary"
      default:
        return "outline"
    }
  }

  return (
    <LayoutSistema>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-primary">Gestión de Evidencias</h1>
          <p className="text-muted-foreground mt-2">
            Sube y gestiona documentos que comprueben tus productos académicos
          </p>
        </div>

        <FormularioEvidenciaDinamico />

        {/* Historial de Evidencias Cargadas */}
        <Card className="border border-border shadow-sm">
          <CardHeader className="border-b border-border bg-muted/30">
            <CardTitle className="text-lg font-bold text-primary">Historial de Evidencias</CardTitle>
            <CardDescription>Documentos previamente cargados y su estado de validación</CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-border hover:bg-transparent">
                    <TableHead className="text-primary font-semibold">Tipo</TableHead>
                    <TableHead className="text-primary font-semibold">Título/Descripción</TableHead>
                    <TableHead className="text-primary font-semibold">Fecha Carga</TableHead>
                    <TableHead className="text-primary font-semibold">Cuartil</TableHead>
                    <TableHead className="text-primary font-semibold">Estado</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {historialEvidencias.map((evidencia) => (
                    <TableRow key={evidencia.id} className="border-border hover:bg-muted/50">
                      <TableCell>
                        <Badge variant="outline" className="bg-accent/50 text-accent-foreground border-accent">
                          {evidencia.tipo}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-medium text-foreground">{evidencia.titulo}</TableCell>
                      <TableCell className="text-muted-foreground text-sm">{evidencia.fecha}</TableCell>
                      <TableCell className="text-center">{evidencia.cuartil}</TableCell>
                      <TableCell>
                        <Badge
                          variant={obtenerVarianteBadge(evidencia.estado) as any}
                          className="flex items-center gap-2 w-fit"
                        >
                          {obtenerIconoEstado(evidencia.estado)}
                          {evidencia.estado}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {historialEvidencias.length === 0 && (
              <div className="text-center py-12">
                <FileCheck2 className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
                <p className="text-muted-foreground">No hay evidencias cargadas aún</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </LayoutSistema>
  )
}
