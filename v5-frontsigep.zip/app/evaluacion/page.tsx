import { TeacherEvaluationPlatform } from "@/components/evaluation/teacher-evaluation-platform"

export default function EvaluacionPage() {
  return <TeacherEvaluationPlatform />
}
