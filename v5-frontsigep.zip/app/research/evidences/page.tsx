import { FormularioEvidenciaDinamico } from "@/components/formulario-evidencia-dinamico"
import { LayoutSistema } from "@/components/layout-sistema"

export const metadata = {
  title: "Nueva Evidencia de Investigación - SIGEP",
  description: "Carga de evidencias de productos de investigación al sistema SIGEP",
}

export default function PaginaEvidenciasInvestigacion() {
  return (
    <LayoutSistema>
      <div className="max-w-6xl mx-auto">
        <FormularioEvidenciaDinamico />
      </div>
    </LayoutSistema>
  )
}
