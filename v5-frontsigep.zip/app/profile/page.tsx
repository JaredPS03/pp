import { IdentityCard } from "@/components/identity-card"
import { ProfileForm } from "@/components/profile-form"
import { LayoutSistema } from "@/components/layout-sistema"

export const metadata = {
  title: "Mis Datos - SIGEP",
  description: "Gestiona tu perfil y datos personales en el sistema SIGEP",
}

export default function PaginaPerfil() {
  // TODO: Conectar con Server Action para obtener datos reales del usuario desde la base de datos
  const datosUsuario = {
    name: "Dr. Juan Pérez García",
    rfc: "PEGJ850315HDF",
    curp: "PEGJ850315HDFRRR05",
    employeeNumber: "DOC-2021-0847",
    academicDegree: "doctorado",
    category: "ptc",
    phone: "+52 951 234 5678",
    institutionalEmail: "juan.perez@uabjo.edu.mx",
  }

  return (
    <LayoutSistema>
      <div className="space-y-8">
        {/* Encabezado */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-primary">Mis Datos</h1>
          <p className="text-base text-muted-foreground">Gestiona tu información personal y académica</p>
        </div>

        {/* Contenido en dos columnas responsivas */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Tarjeta de Identidad - Columna más estrecha */}
          <div className="lg:col-span-1">
            <IdentityCard
              rfc={datosUsuario.rfc}
              curp={datosUsuario.curp}
              employeeNumber={datosUsuario.employeeNumber}
            />
          </div>

          {/* Formulario de Edición - Columna más ancha */}
          <div className="lg:col-span-2">
            <ProfileForm initialData={datosUsuario} />
          </div>
        </div>
      </div>
    </LayoutSistema>
  )
}
