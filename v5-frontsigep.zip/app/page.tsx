"use client"

import { useState } from "react"
import { LoginScreen } from "@/components/login-screen"
import { ConvocatoriaSelection } from "@/components/convocatoria-selection"
import { AppLayout } from "@/components/app-layout"
import { EvFacMain } from "@/components/Ev_fac/ev-fac-main"
import { EvComMain } from "@/components/Ev_com/ev-com-main"

type UserRole = "profesor" | "admin" | "evaluador" | "ev_fac" | "ev_com"

interface Convocatoria {
  id: string
  nombre: string
  periodo: string
  estado: "activa" | "cerrada"
}

export default function SIGEPApp() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userRole, setUserRole] = useState<UserRole | null>(null)
  const [selectedConvocatoria, setSelectedConvocatoria] = useState<Convocatoria | null>(null)

  const handleLogin = (role: UserRole) => {
    setIsAuthenticated(true)
    setUserRole(role)
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    setUserRole(null)
    setSelectedConvocatoria(null)
  }

  const handleSelectConvocatoria = (convocatoria: Convocatoria) => {
    setSelectedConvocatoria(convocatoria)
  }

  const handleBackToConvocatorias = () => {
    setSelectedConvocatoria(null)
  }

  // Not authenticated - show login
  if (!isAuthenticated) {
    return <LoginScreen onLogin={handleLogin} />
  }

  if (userRole === "ev_fac") {
    return <EvFacMain onLogout={handleLogout} />
  }

  if (userRole === "ev_com") {
    return <EvComMain onLogout={handleLogout} />
  }

  // PTC/Profesor flow - show convocatoria selection first
  if (userRole === "profesor" && !selectedConvocatoria) {
    return <ConvocatoriaSelection onSelect={handleSelectConvocatoria} onLogout={handleLogout} />
  }

  // Admin, evaluador, or profesor with selected convocatoria
  return (
    <AppLayout
      onLogout={handleLogout}
      userType={userRole === "profesor" ? "profesor" : userRole === "admin" ? "admin" : "evaluador"}
      selectedConvocatoria={selectedConvocatoria}
      onBackToConvocatorias={handleBackToConvocatorias}
    />
  )
}
