// Mock Data for Backend Integration Reference
// This file shows the EXACT JSON structure the backend needs to provide
// Backend team: Use these interfaces and examples to build your API responses

import type { EvaluationRubric, EvaluationSection } from "@/types/evaluation"

// ============================================
// SAMPLE RUBRIC DATA - "GENERALES" SECTION
// ============================================
export const generalesRubricData: EvaluationRubric = {
  id: "generales",
  code: "0",
  title: "Documentos Generales",
  description: "Documentos requeridos para iniciar su evaluación",
  sectionType: "generales",
  // No scoring for generales
  requirements: [
    {
      id: "solicitud-ingreso",
      title: "Solicitud de Ingreso",
      description: "Formato oficial de solicitud de ingreso al programa de estímulos.",
      isRequired: true,
      mainFile: null,
      complementaryFiles: [],
    },
    {
      id: "carta-exclusividad",
      title: "Carta de Exclusividad",
      description: "Documento que acredita dedicación exclusiva a la institución.",
      isRequired: true,
      mainFile: null,
      complementaryFiles: [],
    },
    {
      id: "constancia-antiguedad",
      title: "Constancia de Antigüedad",
      description: "Documento oficial que avala los años de servicio en la institución.",
      isRequired: true,
      mainFile: null,
      complementaryFiles: [],
    },
    {
      id: "informe-evaluacion",
      title: "Informe de Evaluación",
      description: "Informe del periodo de evaluación anterior.",
      isRequired: true,
      mainFile: null,
      complementaryFiles: [],
    },
    {
      id: "documentos-grado",
      title: "Documentos de Grado",
      description: "Títulos y cédulas profesionales.",
      isRequired: true,
      hasNationalForeignToggle: true,
      isNational: true,
      foreignFields: { country: "", validationNumber: "" },
      mainFile: null,
      complementaryFiles: [],
    },
  ],
  nextRubricId: "docencia-1",
  nextRubricTitle: "I.1 DOCENCIA",
}

// ============================================
// SAMPLE RUBRIC DATA - "DOCENCIA" SECTION
// ============================================
export const docenciaRubricData: EvaluationRubric = {
  id: "docencia-1",
  code: "I.1",
  title: "DOCENCIA - Actividades de Docencia",
  description: "Evidencias de actividades docentes realizadas durante el periodo de evaluación.",
  sectionType: "rubric",
  scoring: {
    minScore: 0,
    maxScore: 100,
  },
  requirements: [
    {
      id: "carga-academica",
      title: "Carga Académica",
      description: "Documento oficial que muestra la carga académica asignada.",
      isRequired: true,
      mainFile: null,
      complementaryFiles: [],
    },
    {
      id: "evaluacion-docente",
      title: "Evaluación Docente",
      description: "Resultados de la evaluación docente por parte de los alumnos.",
      isRequired: true,
      mainFile: null,
      complementaryFiles: [],
    },
    {
      id: "material-didactico",
      title: "Material Didáctico",
      description: "Evidencia de material didáctico desarrollado.",
      isRequired: false,
      mainFile: null,
      complementaryFiles: [],
    },
  ],
  prevRubricId: "generales",
  prevRubricTitle: "Documentos Generales",
  nextRubricId: "investigacion-1",
  nextRubricTitle: "II.1 INVESTIGACIÓN",
}

// ============================================
// SAMPLE RUBRIC DATA - "INVESTIGACIÓN" SECTION
// ============================================
export const investigacionRubricData: EvaluationRubric = {
  id: "investigacion-1",
  code: "II.1",
  title: "INVESTIGACIÓN - Producción Científica",
  description: "Evidencias de producción científica y académica.",
  sectionType: "rubric",
  scoring: {
    minScore: 0,
    maxScore: 150,
  },
  requirements: [
    {
      id: "articulos-publicados",
      title: "Artículos Publicados",
      description: "Artículos publicados en revistas indexadas.",
      isRequired: true,
      mainFile: null,
      complementaryFiles: [],
    },
    {
      id: "proyectos-investigacion",
      title: "Proyectos de Investigación",
      description: "Proyectos de investigación en los que participa.",
      isRequired: true,
      mainFile: null,
      complementaryFiles: [],
    },
  ],
  prevRubricId: "docencia-1",
  prevRubricTitle: "I.1 DOCENCIA",
  nextRubricId: "tutorias-1",
  nextRubricTitle: "III.1 TUTORÍAS",
}

// ============================================
// SIDEBAR NAVIGATION STRUCTURE
// ============================================
export const evaluationSections: EvaluationSection[] = [
  {
    id: "generales",
    code: "0",
    title: "GENERALES",
  },
  {
    id: "docencia",
    code: "I",
    title: "DOCENCIA",
    items: [
      { id: "docencia-1", code: "I.1", title: "Actividades de Docencia" },
      { id: "docencia-2", code: "I.2", title: "Tutorías Académicas" },
    ],
  },
  {
    id: "investigacion",
    code: "II",
    title: "INVESTIGACIÓN",
    items: [
      { id: "investigacion-1", code: "II.1", title: "Producción Científica" },
      { id: "investigacion-2", code: "II.2", title: "Proyectos de Investigación" },
    ],
  },
  {
    id: "tutorias",
    code: "III",
    title: "TUTORÍAS",
    items: [{ id: "tutorias-1", code: "III.1", title: "Dirección de Tesis" }],
  },
  {
    id: "cuerpos-colegiados",
    code: "IV",
    title: "CUERPOS COLEGIADOS",
    items: [{ id: "cuerpos-1", code: "IV.1", title: "Participación en Comités" }],
  },
]

// ============================================
// HELPER: Get rubric data by ID
// Backend should implement this as an API endpoint
// ============================================
export function getRubricById(rubricId: string): EvaluationRubric | null {
  const rubricMap: Record<string, EvaluationRubric> = {
    generales: generalesRubricData,
    "docencia-1": docenciaRubricData,
    "investigacion-1": investigacionRubricData,
  }
  return rubricMap[rubricId] || null
}
