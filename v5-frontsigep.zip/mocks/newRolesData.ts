// Mock data for Ev_fac and Ev_com roles
export interface Convocatoria {
  id: string
  nombre: string
  periodo: string
  estado: "activa" | "cerrada"
  profesoresAsignados: number
  profesoresRevisados: number
}

export interface ProfesorEvaluacion {
  id: string
  nombre: string
  rfc: string
  facultad: string
  progress: number
  status: "pendiente" | "en_revision" | "revisado"
  documentosTotal: number
  documentosValidados: number
  puntajeAutoevaluacion?: number
  puntajeAsignado?: number
}

export interface DocumentoEvaluacion {
  id: string
  rubroId: string
  rubroNombre: string
  nombre: string
  archivo: string
  fechaSubida: string
  estado: "pendiente" | "aprobado" | "rechazado"
  puntosMax?: number
  puntosMin?: number
  puntosAutoevaluacion?: number
  puntosAsignados?: number
  feedback?: string
}

// Convocatorias for evaluators
export const convocatoriasEvaluadores: Convocatoria[] = [
  {
    id: "conv-1",
    nombre: "Estímulos al Desempeño Docente 2025",
    periodo: "Ene 2025 - Dic 2025",
    estado: "activa",
    profesoresAsignados: 45,
    profesoresRevisados: 12,
  },
  {
    id: "conv-2",
    nombre: "PRODEP 2024-2025",
    periodo: "Jul 2024 - Jun 2025",
    estado: "activa",
    profesoresAsignados: 32,
    profesoresRevisados: 28,
  },
  {
    id: "conv-3",
    nombre: "Reconocimiento Académico 2024",
    periodo: "Ene 2024 - Dic 2024",
    estado: "cerrada",
    profesoresAsignados: 50,
    profesoresRevisados: 50,
  },
]

// Professors for evaluation
export const profesoresEvaluacion: ProfesorEvaluacion[] = [
  {
    id: "prof-1",
    nombre: "Dr. Carlos Mendoza López",
    rfc: "MELC750315ABC",
    facultad: "Facultad de Derecho y Ciencias Sociales",
    progress: 85,
    status: "pendiente",
    documentosTotal: 24,
    documentosValidados: 18,
    puntajeAutoevaluacion: 720,
  },
  {
    id: "prof-2",
    nombre: "Dra. María Elena Ruiz",
    rfc: "RUME680422DEF",
    facultad: "Facultad de Medicina y Cirugía",
    progress: 100,
    status: "en_revision",
    documentosTotal: 30,
    documentosValidados: 30,
    puntajeAutoevaluacion: 850,
  },
  {
    id: "prof-3",
    nombre: "Mtro. Roberto García Sánchez",
    rfc: "GASR790810GHI",
    facultad: "Facultad de Contaduría y Administración",
    progress: 60,
    status: "pendiente",
    documentosTotal: 20,
    documentosValidados: 12,
    puntajeAutoevaluacion: 540,
  },
  {
    id: "prof-4",
    nombre: "Dra. Ana Patricia Hernández",
    rfc: "HEAP720115JKL",
    facultad: "Facultad de Arquitectura",
    progress: 95,
    status: "revisado",
    documentosTotal: 28,
    documentosValidados: 26,
    puntajeAutoevaluacion: 780,
    puntajeAsignado: 745,
  },
  {
    id: "prof-5",
    nombre: "Dr. Luis Fernando Torres",
    rfc: "TOFL800520MNO",
    facultad: "Facultad de Ciencias Químicas",
    progress: 75,
    status: "pendiente",
    documentosTotal: 22,
    documentosValidados: 16,
    puntajeAutoevaluacion: 620,
  },
  {
    id: "prof-6",
    nombre: "Mtra. Guadalupe Vásquez",
    rfc: "VAGU850315PQR",
    facultad: "Facultad de Idiomas",
    progress: 100,
    status: "revisado",
    documentosTotal: 18,
    documentosValidados: 18,
    puntajeAutoevaluacion: 480,
    puntajeAsignado: 465,
  },
  {
    id: "prof-7",
    nombre: "Dr. Miguel Ángel Reyes",
    rfc: "REMA770225STU",
    facultad: "Instituto de Investigaciones Sociológicas",
    progress: 90,
    status: "en_revision",
    documentosTotal: 35,
    documentosValidados: 32,
    puntajeAutoevaluacion: 920,
  },
  {
    id: "prof-8",
    nombre: "Dra. Patricia González Mora",
    rfc: "GOMP710810VWX",
    facultad: "Facultad de Enfermería y Obstetricia",
    progress: 70,
    status: "pendiente",
    documentosTotal: 25,
    documentosValidados: 17,
    puntajeAutoevaluacion: 580,
  },
]

// Documents per professor (example for one professor)
export const documentosProfesor: DocumentoEvaluacion[] = [
  // GENERALES
  {
    id: "doc-1",
    rubroId: "solicitud-ingreso",
    rubroNombre: "Solicitud de Ingreso",
    nombre: "Formato_Solicitud_2025.pdf",
    archivo: "/placeholder.pdf",
    fechaSubida: "2025-01-15",
    estado: "aprobado",
  },
  {
    id: "doc-2",
    rubroId: "carta-exclusividad",
    rubroNombre: "Carta de Exclusividad",
    nombre: "Carta_Exclusividad_UABJO.pdf",
    archivo: "/placeholder.pdf",
    fechaSubida: "2025-01-15",
    estado: "pendiente",
  },
  {
    id: "doc-3",
    rubroId: "constancia-antiguedad",
    rubroNombre: "Constancia de Antigüedad",
    nombre: "Constancia_15_años.pdf",
    archivo: "/placeholder.pdf",
    fechaSubida: "2025-01-16",
    estado: "pendiente",
  },
  // DOCENCIA
  {
    id: "doc-4",
    rubroId: "programas",
    rubroNombre: "Programas de asignatura",
    nombre: "Programa_Derecho_Civil.pdf",
    archivo: "/placeholder.pdf",
    fechaSubida: "2025-01-18",
    estado: "pendiente",
    puntosMax: 30,
    puntosMin: 0,
    puntosAutoevaluacion: 25,
  },
  {
    id: "doc-5",
    rubroId: "evaluacion",
    rubroNombre: "Constancia de evaluación docente",
    nombre: "Evaluacion_Docente_2024.pdf",
    archivo: "/placeholder.pdf",
    fechaSubida: "2025-01-18",
    estado: "aprobado",
    puntosMax: 50,
    puntosMin: 20,
    puntosAutoevaluacion: 45,
    puntosAsignados: 42,
  },
  {
    id: "doc-6",
    rubroId: "libros-isbn",
    rubroNombre: "Autor de libros con ISBN",
    nombre: "Libro_Derecho_Constitucional.pdf",
    archivo: "/placeholder.pdf",
    fechaSubida: "2025-01-20",
    estado: "pendiente",
    puntosMax: 80,
    puntosMin: 0,
    puntosAutoevaluacion: 80,
  },
  // INVESTIGACIÓN
  {
    id: "doc-7",
    rubroId: "articulos-indexados",
    rubroNombre: "Artículos revistas indexadas",
    nombre: "Articulo_Revista_Juridica.pdf",
    archivo: "/placeholder.pdf",
    fechaSubida: "2025-01-22",
    estado: "pendiente",
    puntosMax: 40,
    puntosMin: 0,
    puntosAutoevaluacion: 40,
  },
  {
    id: "doc-8",
    rubroId: "ponente-congresos",
    rubroNombre: "Ponente en congresos/foros",
    nombre: "Constancia_Congreso_Nacional.pdf",
    archivo: "/placeholder.pdf",
    fechaSubida: "2025-01-22",
    estado: "pendiente",
    puntosMax: 20,
    puntosMin: 0,
    puntosAutoevaluacion: 15,
  },
  // TUTORÍAS
  {
    id: "doc-9",
    rubroId: "dir-tesis-lic",
    rubroNombre: "Director de tesis licenciatura",
    nombre: "Acta_Tesis_Martinez_2024.pdf",
    archivo: "/placeholder.pdf",
    fechaSubida: "2025-01-25",
    estado: "pendiente",
    puntosMax: 25,
    puntosMin: 0,
    puntosAutoevaluacion: 25,
  },
  {
    id: "doc-10",
    rubroId: "tutorias-perm",
    rubroNombre: "Tutorías permanentes",
    nombre: "Certificacion_Tutorias_2024.pdf",
    archivo: "/placeholder.pdf",
    fechaSubida: "2025-01-25",
    estado: "pendiente",
    puntosMax: 30,
    puntosMin: 10,
    puntosAutoevaluacion: 30,
  },
]

// Helper to get documents by rubroId
export function getDocumentosByRubro(rubroId: string): DocumentoEvaluacion[] {
  return documentosProfesor.filter((doc) => doc.rubroId === rubroId)
}

// Helper to get all leaf document IDs in order
export function getAllDocumentIds(): string[] {
  return documentosProfesor.map((doc) => doc.rubroId)
}
