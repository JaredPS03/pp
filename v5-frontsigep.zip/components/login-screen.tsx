"use client"

import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { GraduationCap, Phone, Eye, EyeOff } from "lucide-react"

type UserType = "profesor" | "admin" | "evaluador" | "ev_fac" | "ev_com"

interface LoginScreenProps {
  onLogin: (type: UserType) => void
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [usuario, setUsuario] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    if (!usuario.trim() || !password.trim()) {
      setError("Por favor ingrese usuario y contraseña")
      return
    }

    const lowerUser = usuario.toLowerCase().trim()

    if (lowerUser === "usuario_ptc" || lowerUser === "ptc") {
      onLogin("profesor")
    } else if (lowerUser === "usuario_evfac" || lowerUser === "evfac") {
      onLogin("ev_fac")
    } else if (lowerUser === "usuario_evcom" || lowerUser === "evcom") {
      onLogin("ev_com")
    } else if (lowerUser.startsWith("admin")) {
      onLogin("admin")
    } else if (lowerUser.startsWith("eval") || lowerUser.startsWith("revisor")) {
      onLogin("evaluador")
    } else {
      // Default to profesor for any other user
      onLogin("profesor")
    }
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-background">
      {/* Left Side - Branding */}
      <div className="relative md:w-1/2 min-h-[40vh] md:min-h-screen overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: "url(/placeholder.svg?height=1080&width=1920&query=university campus academic building)",
          }}
        />
        <div className="absolute inset-0 bg-[#002060] opacity-90" />
        <div className="relative z-10 h-full flex flex-col items-center justify-center p-8 md:p-16">
          <div className="text-center space-y-6 md:space-y-8 max-w-lg">
            <div className="flex justify-center">
              <div className="bg-[#FFC107] rounded-full p-6 md:p-8 shadow-2xl">
                <GraduationCap className="h-16 w-16 md:h-28 md:w-28 text-[#002060]" />
              </div>
            </div>
            <div className="space-y-3 md:space-y-4">
              <h1 className="text-4xl md:text-6xl font-bold text-white drop-shadow-lg">SIGEP-UABJO</h1>
              <p className="text-lg md:text-2xl text-white font-semibold leading-relaxed drop-shadow-md">
                Sistema de Gestión de Expedientes para Profesores
              </p>
              <p className="text-base md:text-lg text-white/95 font-medium drop-shadow-md">
                Universidad Autónoma Benito Juárez de Oaxaca
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="md:w-1/2 flex items-center justify-center p-8 md:p-16 bg-white">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center md:text-left space-y-2">
            <h2 className="text-3xl md:text-4xl font-bold text-[#002060]">Bienvenido</h2>
            <p className="text-lg text-muted-foreground">Ingrese sus credenciales para acceder al sistema</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-base">{error}</div>
            )}

            <div className="space-y-2">
              <Label htmlFor="usuario" className="text-lg font-semibold text-[#002060]">
                Usuario o RFC
              </Label>
              <Input
                id="usuario"
                type="text"
                placeholder="Ingrese su usuario o RFC"
                value={usuario}
                onChange={(e) => setUsuario(e.target.value)}
                className="h-14 text-lg border-2 focus:border-amber-400 focus:ring-amber-400"
                autoComplete="username"
              />
              <p className="text-xs text-muted-foreground">
                Usuarios de prueba: usuario_ptc, usuario_evfac, usuario_evcom
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-lg font-semibold text-[#002060]">
                Contraseña
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Ingrese su contraseña"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-14 text-lg border-2 pr-12 focus:border-amber-400 focus:ring-amber-400"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-[#002060] transition-colors"
                  aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full h-16 text-xl font-bold bg-[#002060] hover:bg-[#003399] transition-colors"
              size="lg"
            >
              INGRESAR AL SISTEMA
            </Button>

            <div className="text-center md:text-left">
              <button type="button" className="text-[#002060] hover:underline text-base font-semibold">
                ¿Olvidó su contraseña?
              </button>
            </div>
          </form>

          <div className="pt-6 border-t border-border">
            <div className="flex items-center gap-3 text-muted-foreground">
              <Phone className="h-5 w-5" />
              <div>
                <p className="text-sm font-semibold">Soporte Técnico</p>
                <p className="text-base font-bold text-[#002060]">951-123-4567</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
