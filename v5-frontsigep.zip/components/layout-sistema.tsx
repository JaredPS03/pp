"use client"

import { useState } from "react"
import type { ReactNode } from "react"
import { ChevronRight, Bell } from "lucide-react"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarProvider,
  SidebarTrigger,
  SidebarGroup,
  SidebarGroupLabel,
} from "@/components/ui/sidebar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Collapsible, CollapsibleTrigger, CollapsibleContent } from "@/components/ui/collapsible"
import { MENU_SISTEMA, DATOS_USUARIO, INFO_CONVOCATORIA, type ItemMenu } from "@/config/sistema.config"

// === COMPONENTES ===

/**
 * Componente recursivo para renderizar items del menú
 * Lee la configuración de MENU_SISTEMA y genera automáticamente la navegación
 */
function ItemMenuRecursivo({ item, rutaActual }: { item: ItemMenu; rutaActual: string }) {
  const [abierto, setAbierto] = useState(false)
  const tieneSubitems = item.subItems && item.subItems.length > 0
  const estaActivo = item.ruta === rutaActual

  // Si no tiene subitems, renderiza un enlace simple
  if (!tieneSubitems) {
    return (
      <SidebarMenuItem>
        <SidebarMenuButton tooltip={item.etiqueta} isActive={estaActivo} asChild>
          <a href={item.ruta || "#"}>
            <item.icono className="h-5 w-5" />
            <span className="font-medium">{item.etiqueta}</span>
          </a>
        </SidebarMenuButton>
      </SidebarMenuItem>
    )
  }

  // Si tiene subitems, renderiza un collapsible
  return (
    <SidebarMenuItem>
      <Collapsible open={abierto} onOpenChange={setAbierto}>
        <CollapsibleTrigger asChild>
          <SidebarMenuButton tooltip={item.etiqueta} className="px-2">
            <div className="flex items-center gap-3 flex-1">
              <item.icono className="h-5 w-5" />
              <span className="font-medium">{item.etiqueta}</span>
            </div>
            <ChevronRight className={`h-4 w-4 transition-transform duration-200 ${abierto ? "rotate-90" : ""}`} />
          </SidebarMenuButton>
        </CollapsibleTrigger>
        <CollapsibleContent className="mt-1">
          <SidebarMenuSub>
            {item.subItems?.map((subItem) => (
              <SidebarMenuSubItem key={subItem.id}>
                <SidebarMenuSubButton asChild>
                  <a href={subItem.ruta || "#"}>{subItem.etiqueta}</a>
                </SidebarMenuSubButton>
              </SidebarMenuSubItem>
            ))}
          </SidebarMenuSub>
        </CollapsibleContent>
      </Collapsible>
    </SidebarMenuItem>
  )
}

/**
 * Sidebar del sistema
 * Se genera dinámicamente a partir de MENU_SISTEMA
 */
function BarraLateral() {
  const rutaActual = typeof window !== "undefined" ? window.location.pathname : "/"

  return (
    <Sidebar collapsible="icon" className="border-r-0">
      <SidebarHeader className="h-16 flex items-center px-6 border-b border-sidebar-border bg-sidebar">
        <div className="flex items-center gap-3">
          <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground font-bold text-xl">
            S
          </div>
          <div className="flex flex-col gap-0.5 leading-none group-data-[collapsible=icon]:hidden">
            <span className="font-bold text-lg tracking-tight text-white">SIGEP</span>
            <span className="text-[10px] text-sidebar-primary font-semibold uppercase tracking-widest">UABJO</span>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="bg-sidebar">
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground/40 font-bold uppercase tracking-widest text-[10px] px-6 py-4">
            Navegación
          </SidebarGroupLabel>
          <SidebarMenu className="px-3 space-y-1">
            {/* Renderizado recursivo del menú */}
            {MENU_SISTEMA.map((item) => (
              <ItemMenuRecursivo key={item.id} item={item} rutaActual={rutaActual} />
            ))}
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="bg-sidebar border-t border-sidebar-border p-4">
        <div className="flex items-center gap-3 group-data-[collapsible=icon]:justify-center">
          <div className="flex flex-col group-data-[collapsible=icon]:hidden">
            <span className="text-[10px] text-sidebar-foreground/50 font-medium">Versión</span>
            <span className="text-xs text-sidebar-primary font-bold tracking-tighter">2.5.0-ESPAÑOL</span>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}

/**
 * Barra superior con información del usuario
 */
function BarraSuperior() {
  return (
    <header className="h-16 border-b bg-white flex items-center justify-between px-6 sticky top-0 z-10">
      <div className="flex items-center gap-4">
        <SidebarTrigger className="lg:hidden" />
        <div className="flex flex-col">
          <h1 className="text-sm font-semibold text-primary">Bienvenido, {DATOS_USUARIO.nombre}</h1>
          <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">
            {DATOS_USUARIO.categoria}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <Badge
          variant="outline"
          className="border-secondary text-secondary-foreground bg-secondary/10 hidden md:flex animate-pulse"
        >
          Convocatoria {INFO_CONVOCATORIA.anio}: {INFO_CONVOCATORIA.estado} (Cierra en {INFO_CONVOCATORIA.diasRestantes}{" "}
          días)
        </Badge>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="text-muted-foreground">
            <Bell className="h-5 w-5" />
          </Button>
          <Avatar className="h-9 w-9 border-2 border-secondary/20">
            <AvatarImage src="/diverse-professor-lecturing.png" />
            <AvatarFallback className="bg-primary text-primary-foreground">{DATOS_USUARIO.iniciales}</AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  )
}

// === PÁGINA PRINCIPAL (Layout) ===

export function LayoutSistema({ children }: { children: ReactNode }) {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-[#f3f4f6]">
        <BarraLateral />
        <main className="flex-1 flex flex-col">
          <BarraSuperior />
          <div className="p-6">{children}</div>
        </main>
      </div>
    </SidebarProvider>
  )
}

export default LayoutSistema
