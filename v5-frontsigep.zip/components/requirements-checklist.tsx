"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"

export interface ChecklistItem {
  id: string
  label: string
  description?: string
}

interface RequirementsChecklistProps {
  title: string
  items: ChecklistItem[]
  className?: string
}

export function RequirementsChecklist({ title, items, className }: RequirementsChecklistProps) {
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set())

  const toggleItem = (id: string) => {
    const newChecked = new Set(checkedItems)
    if (newChecked.has(id)) {
      newChecked.delete(id)
    } else {
      newChecked.add(id)
    }
    setCheckedItems(newChecked)
  }

  return (
    <Card className={`p-6 ${className}`}>
      <h3 className="text-lg font-semibold mb-6">{title}</h3>
      <div className="space-y-4">
        {items.map((item) => (
          <div key={item.id} className="flex items-start gap-4">
            <Checkbox
              id={item.id}
              checked={checkedItems.has(item.id)}
              onCheckedChange={() => toggleItem(item.id)}
              className="mt-1 h-6 w-6"
            />
            <Label htmlFor={item.id} className="cursor-pointer flex-1 text-base leading-relaxed">
              {item.label}
              {item.description && <p className="text-sm text-muted-foreground mt-1">{item.description}</p>}
            </Label>
          </div>
        ))}
      </div>
    </Card>
  )
}
