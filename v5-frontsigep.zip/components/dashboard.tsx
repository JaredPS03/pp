"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, FlaskConical, Users, Briefcase, CheckCircle2, Circle, LogOut } from "lucide-react"

interface DashboardProps {
  onLogout: () => void
  onCategorySelect: (category: "docencia" | "investigacion" | "tutoria" | "gestion") => void
}

const categories = [
  {
    id: "docencia" as const,
    title: "Docencia",
    description: "Carga de materiales didácticos, programas de estudio y evidencias de enseñanza",
    icon: BookOpen,
    completed: true,
  },
  {
    id: "investigacion" as const,
    title: "Investigación",
    description: "Registro de publicaciones, proyectos de investigación y productos académicos",
    icon: FlaskConical,
    completed: false,
  },
  {
    id: "tutoria" as const,
    title: "Tutoría",
    description: "Seguimiento de estudiantes, asesorías y programas de tutorías",
    icon: Users,
    completed: false,
  },
  {
    id: "gestion" as const,
    title: "Gestión",
    description: "Actividades administrativas, comisiones y servicios institucionales",
    icon: Briefcase,
    completed: true,
  },
]

export function Dashboard({ onLogout, onCategorySelect }: DashboardProps) {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="container mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-accent rounded-full p-2">
              <BookOpen className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold">SIGEP UABJO</h1>
          </div>
          <Button onClick={onLogout} variant="secondary" size="lg" className="h-12 text-lg font-semibold">
            <LogOut className="mr-2 h-5 w-5" />
            Salir
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-primary mb-2">Panel Principal</h2>
          <p className="text-xl text-muted-foreground">Seleccione un rubro para cargar documentos</p>
        </div>

        {/* Category Cards Grid */}
        <div className="grid gap-8 md:grid-cols-2 max-w-6xl mx-auto">
          {categories.map((category) => {
            const Icon = category.icon
            return (
              <Card
                key={category.id}
                className="cursor-pointer transition-all hover:shadow-xl hover:scale-105 border-2 hover:border-accent"
                onClick={() => onCategorySelect(category.id)}
              >
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-4">
                      <div className="bg-primary/10 p-4 rounded-lg">
                        <Icon className="h-10 w-10 text-primary" />
                      </div>
                      <div>
                        <CardTitle className="text-2xl font-bold text-primary">{category.title}</CardTitle>
                      </div>
                    </div>
                    <div className="flex-shrink-0">
                      {category.completed ? (
                        <div className="bg-success/20 rounded-full p-2">
                          <CheckCircle2 className="h-10 w-10 text-success" />
                        </div>
                      ) : (
                        <div className="bg-accent/20 rounded-full p-2">
                          <Circle className="h-10 w-10 text-accent" />
                        </div>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-lg text-muted-foreground leading-relaxed">{category.description}</p>
                  <div className="mt-4 pt-4 border-t border-border">
                    <p className="text-base font-semibold">
                      {category.completed ? (
                        <span className="text-success">✓ Completado</span>
                      ) : (
                        <span className="text-accent">○ Pendiente</span>
                      )}
                    </p>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </main>
    </div>
  )
}
