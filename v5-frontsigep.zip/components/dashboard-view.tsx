"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Clock, Award, TrendingUp, CheckCircle2, FileText, AlertCircle, ArrowRight, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"

interface DashboardViewProps {
  onNavigate: (view: string) => void
  onOpenEvaluation?: () => void
}

const rubros = [
  {
    id: "calidad",
    title: "I. CALIDAD",
    subtitle: "Máximo 700 Puntos",
    icon: Award,
    color: "emerald",
    bgColor: "bg-emerald-50",
    borderColor: "border-emerald-200",
    textColor: "text-emerald-700",
    iconBg: "bg-emerald-100",
    iconColor: "text-emerald-600",
    progress: 45,
    pointsObtained: 315,
    pointsMax: 700,
    subrubros: [
      { name: "Docencia", points: "100-300 pts", completed: 8, total: 12 },
      { name: "Investigación", points: "25-150 pts", completed: 3, total: 8 },
      { name: "Tutorías", points: "30-150 pts", completed: 5, total: 10 },
      { name: "Cuerpos Colegiados", points: "30-100 pts", completed: 2, total: 5 },
    ],
  },
  {
    id: "dedicacion",
    title: "II. DEDICACIÓN",
    subtitle: "Máximo 200 Puntos",
    icon: Clock,
    color: "blue",
    bgColor: "bg-blue-50",
    borderColor: "border-blue-200",
    textColor: "text-blue-700",
    iconBg: "bg-blue-100",
    iconColor: "text-blue-600",
    progress: 100,
    pointsObtained: 200,
    pointsMax: 200,
    subrubros: [{ name: "Carga Horaria Docente", points: "200 pts", completed: 1, total: 1 }],
  },
  {
    id: "permanencia",
    title: "III. PERMANENCIA",
    subtitle: "Máximo 100 Puntos",
    icon: Users,
    color: "amber",
    bgColor: "bg-amber-50",
    borderColor: "border-amber-200",
    textColor: "text-amber-700",
    iconBg: "bg-amber-100",
    iconColor: "text-amber-600",
    progress: 80,
    pointsObtained: 80,
    pointsMax: 100,
    subrubros: [{ name: "Antigüedad", points: "100 pts", completed: 1, total: 1 }],
  },
]

const recentActivity = [
  {
    action: "Documento cargado",
    category: "Docencia",
    file: "Programa_Matematicas.pdf",
    date: "Hace 2 horas",
    status: "pendiente",
  },
  { action: "Documento validado", category: "Gestión", file: "Acta_Comision.pdf", date: "Ayer", status: "aprobado" },
  {
    action: "Documento observado",
    category: "Investigación",
    file: "Articulo_Revista.pdf",
    date: "Hace 3 días",
    status: "observado",
  },
]

export function DashboardView({ onNavigate, onOpenEvaluation }: DashboardViewProps) {
  const totalPoints = rubros.reduce((acc, r) => acc + r.pointsObtained, 0)
  const maxPoints = rubros.reduce((acc, r) => acc + r.pointsMax, 0)
  const overallProgress = Math.round((totalPoints / maxPoints) * 100)

  return (
    <div className="h-full overflow-y-auto p-4 md:p-6 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col gap-4">
          {/* Header con título y puntos */}
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl lg:text-3xl font-bold text-[#002060]">Panel de Inicio</h1>
              <p className="text-gray-600 mt-1">Resumen de su expediente académico</p>
            </div>

            <div className="bg-[#002060] text-white rounded-xl px-6 py-4 flex items-center gap-4">
              <div className="text-center">
                <p className="text-3xl font-bold">{totalPoints}</p>
                <p className="text-xs text-white/70">de {maxPoints} pts</p>
              </div>
              <div className="h-12 w-px bg-white/20" />
              <div>
                <p className="text-2xl font-bold">{overallProgress}%</p>
                <p className="text-xs text-white/70">Avance total</p>
              </div>
            </div>
          </div>

          {/* Botón principal para empezar a subir */}
          <Button
            onClick={() => onOpenEvaluation?.()}
            className="w-full md:w-auto bg-emerald-600 hover:bg-emerald-700 text-white py-6 text-lg font-semibold shadow-lg"
          >
            <Upload className="h-5 w-5 mr-2" />
            Empezar a subir documentos
          </Button>
        </div>

        <div className="grid gap-4 lg:gap-6 grid-cols-1 lg:grid-cols-3">
          {rubros.map((rubro) => {
            const Icon = rubro.icon
            return (
              <Card
                key={rubro.id}
                className={`cursor-pointer hover:shadow-lg transition-all border-2 ${rubro.borderColor} ${rubro.bgColor}`}
                onClick={() => onNavigate(rubro.id)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className={`p-3 rounded-xl ${rubro.iconBg}`}>
                      <Icon className={`h-6 w-6 ${rubro.iconColor}`} />
                    </div>
                    <div className="text-right">
                      <p className={`text-3xl font-bold ${rubro.textColor}`}>{rubro.pointsObtained}</p>
                      <p className="text-xs text-gray-500">de {rubro.pointsMax} pts</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <h3 className={`text-lg font-bold ${rubro.textColor}`}>{rubro.title}</h3>
                    <p className="text-sm text-gray-600">{rubro.subtitle}</p>
                  </div>

                  {/* Barra de progreso */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs text-gray-600">
                      <span>Progreso</span>
                      <span className="font-medium">{rubro.progress}%</span>
                    </div>
                    <div className="w-full bg-white rounded-full h-2.5 border">
                      <div
                        className={`h-2.5 rounded-full transition-all ${
                          rubro.color === "emerald"
                            ? "bg-emerald-500"
                            : rubro.color === "blue"
                              ? "bg-blue-500"
                              : "bg-amber-500"
                        }`}
                        style={{ width: `${rubro.progress}%` }}
                      />
                    </div>
                  </div>

                  {/* Subrubros */}
                  <div className="space-y-2 pt-2 border-t border-gray-200">
                    {rubro.subrubros.map((sub, idx) => (
                      <div key={idx} className="flex items-center justify-between text-sm">
                        <span className="text-gray-700">{sub.name}</span>
                        <span className="text-gray-500 text-xs">
                          {sub.completed}/{sub.total}
                        </span>
                      </div>
                    ))}
                  </div>

                  <Button
                    variant="ghost"
                    className={`w-full justify-between ${rubro.textColor} hover:bg-white/50`}
                    onClick={(e) => {
                      e.stopPropagation()
                      onNavigate(rubro.id)
                    }}
                  >
                    Ver detalles
                    <ArrowRight className="h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Sección inferior: Actividad y pendientes */}
        <div className="grid gap-4 lg:gap-6 grid-cols-1 lg:grid-cols-2">
          {/* Actividad Reciente */}
          <Card className="border-2">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-[#002060]" />
                Actividad Reciente
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                    <div
                      className={`mt-0.5 ${
                        activity.status === "aprobado"
                          ? "text-emerald-500"
                          : activity.status === "observado"
                            ? "text-amber-500"
                            : "text-blue-500"
                      }`}
                    >
                      {activity.status === "aprobado" ? (
                        <CheckCircle2 className="h-5 w-5" />
                      ) : activity.status === "observado" ? (
                        <AlertCircle className="h-5 w-5" />
                      ) : (
                        <FileText className="h-5 w-5" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800">{activity.action}</p>
                      <p className="text-xs text-gray-500 truncate">{activity.file}</p>
                    </div>
                    <div className="text-right">
                      <span
                        className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${
                          activity.status === "aprobado"
                            ? "bg-emerald-100 text-emerald-700"
                            : activity.status === "observado"
                              ? "bg-amber-100 text-amber-700"
                              : "bg-blue-100 text-blue-700"
                        }`}
                      >
                        {activity.category}
                      </span>
                      <p className="text-xs text-gray-400 mt-1">{activity.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Documentos pendientes */}
          <Card className="border-2 border-orange-200 bg-orange-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2 text-orange-700">
                <AlertCircle className="h-5 w-5" />
                Pendientes por Cargar
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-3 bg-white rounded-lg border border-orange-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-800">Programas de asignatura</p>
                      <p className="text-xs text-gray-500">I.1. Docencia - Calidad al desempeño</p>
                    </div>
                    <Button
                      size="sm"
                      className="bg-[#002060] hover:bg-[#003399]"
                      onClick={() => onNavigate("programas")}
                    >
                      Cargar
                    </Button>
                  </div>
                </div>
                <div className="p-3 bg-white rounded-lg border border-orange-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-800">Constancia de evaluación docente</p>
                      <p className="text-xs text-gray-500">I.1. Docencia - Calidad al desempeño</p>
                    </div>
                    <Button
                      size="sm"
                      className="bg-[#002060] hover:bg-[#003399]"
                      onClick={() => onNavigate("evaluacion")}
                    >
                      Cargar
                    </Button>
                  </div>
                </div>
                <div className="p-3 bg-white rounded-lg border border-orange-200">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-gray-800">Artículos en revistas indexadas</p>
                      <p className="text-xs text-gray-500">I.2. Investigación</p>
                    </div>
                    <Button
                      size="sm"
                      className="bg-[#002060] hover:bg-[#003399]"
                      onClick={() => onNavigate("articulos-indexados")}
                    >
                      Cargar
                    </Button>
                  </div>
                </div>
              </div>
              <p className="text-xs text-orange-600 mt-4 text-center">Tiene 15 documentos pendientes por cargar</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
