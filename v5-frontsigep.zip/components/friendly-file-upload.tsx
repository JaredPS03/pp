"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle2, Upload, X } from "lucide-react"
import { cn } from "@/lib/utils"

interface FriendlyFileUploadProps {
  onFileSelect?: (file: File) => void
  maxSizeMB?: number
  className?: string
}

export function FriendlyFileUpload({ onFileSelect, maxSizeMB = 10, className }: FriendlyFileUploadProps) {
  const [file, setFile] = useState<File | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)

    const files = e.dataTransfer.files
    if (files.length > 0) {
      const selectedFile = files[0]
      if (selectedFile.type === "application/pdf") {
        setFile(selectedFile)
        onFileSelect?.(selectedFile)
      }
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.currentTarget.files
    if (files && files.length > 0) {
      const selectedFile = files[0]
      setFile(selectedFile)
      onFileSelect?.(selectedFile)
    }
  }

  const handleRemove = () => {
    setFile(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleChange = () => {
    fileInputRef.current?.click()
  }

  if (file) {
    return (
      <Card className={cn("p-8", className)}>
        <div className="flex items-start gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <CheckCircle2 className="h-8 w-8 text-green-600 flex-shrink-0" />
              <div>
                <p className="font-semibold text-lg">Archivo cargado</p>
                <p className="text-sm text-muted-foreground">{file.name}</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground ml-11">Tamaño: {(file.size / 1024 / 1024).toFixed(2)} MB</p>
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <Button onClick={handleChange} variant="outline" size="lg" className="text-base font-semibold bg-transparent">
            Cambiar Archivo
          </Button>
          <Button onClick={handleRemove} variant="ghost" size="lg" className="text-base">
            <X className="h-5 w-5 mr-2" />
            Remover
          </Button>
        </div>
      </Card>
    )
  }

  return (
    <Card
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={cn(
        "p-8 border-2 border-dashed transition-all cursor-pointer",
        isDragging ? "border-primary bg-primary/5" : "border-muted-foreground",
        className,
      )}
      onClick={() => fileInputRef.current?.click()}
    >
      <div className="text-center py-12">
        <Upload className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
        <h3 className="text-xl font-semibold mb-2">Arrastra tu archivo aquí</h3>
        <p className="text-lg text-muted-foreground mb-4">o haz clic para seleccionar</p>
        <p className="text-sm text-muted-foreground">Solo archivos PDF (máximo {maxSizeMB} MB)</p>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="application/pdf"
        onChange={handleFileInput}
        className="hidden"
        aria-label="Seleccionar archivo PDF"
      />
    </Card>
  )
}
