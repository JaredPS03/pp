"use client"

import { Button } from "@/components/ui/button"
import { CircleHelp } from "lucide-react"

interface EvaluationHeaderProps {
  title: string
  onHelpClick?: () => void
}

export function EvaluationHeader({ title, onHelpClick }: EvaluationHeaderProps) {
  return (
    <header className="h-16 border-b bg-white flex items-center justify-between px-6">
      <h1 className="text-lg font-semibold text-foreground">{title}</h1>
      <Button variant="ghost" size="icon" onClick={onHelpClick} className="text-muted-foreground hover:text-foreground">
        <CircleHelp className="h-6 w-6" />
        <span className="sr-only">Ayuda</span>
      </Button>
    </header>
  )
}
