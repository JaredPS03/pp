"use client"

import type React from "react"

import { cn } from "@/lib/utils"
import { FileCheck, BookOpen, FlaskConical, Users, Building2, ChevronRight, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"

interface SidebarItem {
  id: string
  title: string
  icon: React.ElementType
  isActive?: boolean
}

interface EvaluationSidebarProps {
  activeSection: string
  onSectionChange: (sectionId: string) => void
  onBack?: () => void
  className?: string
}

const SIDEBAR_ITEMS: SidebarItem[] = [
  { id: "generales", title: "Generales", icon: FileCheck },
  { id: "docencia", title: "Docencia", icon: BookOpen },
  { id: "investigacion", title: "Investigación", icon: FlaskConical },
  { id: "tutorias", title: "Tutorías", icon: Users },
  { id: "cuerpos-colegiados", title: "Cuerpos Colegiados", icon: Building2 },
]

export function EvaluationSidebar({ activeSection, onSectionChange, onBack, className }: EvaluationSidebarProps) {
  return (
    <aside className={cn("w-72 bg-[#0a1628] text-white flex flex-col h-full", className)}>
      {/* Header */}
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-amber-400 rounded-lg flex items-center justify-center">
            <span className="font-bold text-[#0a1628] text-lg">E</span>
          </div>
          <div>
            <h1 className="font-bold text-lg">Evaluación</h1>
            <p className="text-xs text-white/60">Plataforma de Evaluación Docente</p>
          </div>
        </div>
      </div>

      {onBack && (
        <div className="px-4 pt-4">
          <Button
            variant="ghost"
            onClick={onBack}
            className="w-full justify-start gap-2 text-white/70 hover:text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-4 w-4" />
            Volver al Panel
          </Button>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-1">
        <p className="text-xs font-medium text-white/40 uppercase tracking-wider mb-3 px-3">Secciones de Evaluación</p>
        {SIDEBAR_ITEMS.map((item) => {
          const isActive = activeSection === item.id
          return (
            <button
              key={item.id}
              onClick={() => onSectionChange(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all",
                isActive ? "bg-white/15 text-white" : "text-white/70 hover:bg-white/10 hover:text-white",
              )}
            >
              <item.icon className={cn("h-5 w-5 flex-shrink-0", isActive ? "text-amber-400" : "text-white/50")} />
              <span className="flex-1 text-left">{item.title}</span>
              {isActive && <ChevronRight className="h-4 w-4 text-amber-400" />}
            </button>
          )
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-white/10">
        <p className="text-xs text-white/40 text-center">Sistema de Evaluación Docente v1.0</p>
      </div>
    </aside>
  )
}
