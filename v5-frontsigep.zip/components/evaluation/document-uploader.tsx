"use client"

import type React from "react"
import { useState, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Upload, FileText, X, Plus, CheckCircle2, AlertCircle } from "lucide-react"
import { cn } from "@/lib/utils"

export interface UploadedFile {
  id: string
  name: string
  size: number
  file: File
}

export interface DocumentUploaderProps {
  title: string
  description?: string
  requirementId: string
  mainFile: UploadedFile | null
  complementaryFiles: UploadedFile[]
  onMainFileUpload: (file: File | null, requirementId: string) => void
  onComplementaryUpload: (file: File, requirementId: string) => void
  onComplementaryRemove: (fileId: string, requirementId: string) => void
  showForeignToggle?: boolean
  isForeign?: boolean
  onForeignToggle?: (value: boolean) => void
  foreignCountry?: string
  onForeignCountryChange?: (value: string) => void
  foreignInstitution?: string
  onForeignInstitutionChange?: (value: string) => void
}

export function DocumentUploader({
  title,
  description,
  requirementId,
  mainFile,
  complementaryFiles,
  onMainFileUpload,
  onComplementaryUpload,
  onComplementaryRemove,
  showForeignToggle = false,
  isForeign = false,
  onForeignToggle,
  foreignCountry = "",
  onForeignCountryChange,
  foreignInstitution = "",
  onForeignInstitutionChange,
}: DocumentUploaderProps) {
  const [isDragging, setIsDragging] = useState(false)
  const mainInputRef = useRef<HTMLInputElement>(null)
  const complementaryInputRef = useRef<HTMLInputElement>(null)

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragging(false)

    const files = e.dataTransfer.files
    if (files.length > 0 && files[0].type === "application/pdf") {
      onMainFileUpload(files[0], requirementId)
    }
  }

  const handleMainFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      onMainFileUpload(files[0], requirementId)
    }
  }

  const handleComplementaryFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      onComplementaryUpload(files[0], requirementId)
    }
    if (complementaryInputRef.current) {
      complementaryInputRef.current.value = ""
    }
  }

  const handleRemoveMain = () => {
    onMainFileUpload(null, requirementId)
    if (mainInputRef.current) {
      mainInputRef.current.value = ""
    }
  }

  return (
    <Card
      className={cn(
        "transition-all duration-200 hover:shadow-lg border-2",
        mainFile ? "border-emerald-200 bg-emerald-50/30" : "border-border",
        isDragging && "border-primary bg-primary/5",
      )}
    >
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between gap-2">
          <div className="flex-1">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              {mainFile ? (
                <CheckCircle2 className="h-5 w-5 text-emerald-600 flex-shrink-0" />
              ) : (
                <AlertCircle className="h-5 w-5 text-muted-foreground flex-shrink-0" />
              )}
              {title}
            </CardTitle>
            {description && <p className="text-sm text-muted-foreground mt-1">{description}</p>}
          </div>
          {mainFile && (
            <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 flex-shrink-0">
              Cargado
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Foreign Toggle for Documentos de Grado */}
        {showForeignToggle && (
          <div className="space-y-3 p-3 bg-secondary/50 rounded-lg">
            <div className="flex items-center justify-between">
              <Label htmlFor={`foreign-${requirementId}`} className="text-sm font-medium">
                Documento Extranjero
              </Label>
              <Switch id={`foreign-${requirementId}`} checked={isForeign} onCheckedChange={onForeignToggle} />
            </div>

            {isForeign && (
              <div className="space-y-3 pt-2 border-t">
                <div>
                  <Label htmlFor={`country-${requirementId}`} className="text-xs text-muted-foreground">
                    País de Origen
                  </Label>
                  <Input
                    id={`country-${requirementId}`}
                    placeholder="Ej: Estados Unidos"
                    value={foreignCountry}
                    onChange={(e) => onForeignCountryChange?.(e.target.value)}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor={`institution-${requirementId}`} className="text-xs text-muted-foreground">
                    Institución
                  </Label>
                  <Input
                    id={`institution-${requirementId}`}
                    placeholder="Ej: Harvard University"
                    value={foreignInstitution}
                    onChange={(e) => onForeignInstitutionChange?.(e.target.value)}
                    className="mt-1"
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Main File Upload Zone */}
        {!mainFile ? (
          <div
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            onClick={() => mainInputRef.current?.click()}
            className={cn(
              "border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-all",
              isDragging
                ? "border-primary bg-primary/5"
                : "border-muted-foreground/30 hover:border-primary/50 hover:bg-muted/50",
            )}
          >
            <Upload className="h-10 w-10 mx-auto mb-3 text-muted-foreground" />
            <p className="text-sm font-medium mb-1">Arrastra tu archivo aquí</p>
            <p className="text-xs text-muted-foreground">o haz clic para seleccionar (PDF, máx. 10MB)</p>
          </div>
        ) : (
          <div className="flex items-center gap-3 p-3 bg-white rounded-lg border">
            <FileText className="h-8 w-8 text-red-500 flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{mainFile.name}</p>
              <p className="text-xs text-muted-foreground">{(mainFile.size / 1024 / 1024).toFixed(2)} MB</p>
            </div>
            <Button variant="ghost" size="icon" onClick={handleRemoveMain} className="flex-shrink-0 h-8 w-8">
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}

        <input
          ref={mainInputRef}
          type="file"
          accept="application/pdf"
          onChange={handleMainFileSelect}
          className="hidden"
          aria-label="Seleccionar archivo principal"
        />

        {/* Complementary Files Section */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-muted-foreground">
              Archivos Complementarios ({complementaryFiles.length})
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => complementaryInputRef.current?.click()}
              className="h-7 text-xs gap-1"
            >
              <Plus className="h-3 w-3" />
              Agregar
            </Button>
          </div>

          {complementaryFiles.length > 0 && (
            <div className="space-y-1">
              {complementaryFiles.map((file) => (
                <div key={file.id} className="flex items-center gap-2 p-2 bg-secondary/50 rounded text-xs">
                  <FileText className="h-4 w-4 text-blue-500 flex-shrink-0" />
                  <span className="flex-1 truncate">{file.name}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => onComplementaryRemove(file.id, requirementId)}
                    className="h-6 w-6 flex-shrink-0"
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>

        <input
          ref={complementaryInputRef}
          type="file"
          accept="application/pdf"
          onChange={handleComplementaryFileSelect}
          className="hidden"
          aria-label="Seleccionar archivo complementario"
        />
      </CardContent>
    </Card>
  )
}
