"use client"

import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"

export interface ChecklistItem {
  id: string
  label: string
  checked: boolean
}

interface ConfirmationChecklistProps {
  validationChecklistItems: ChecklistItem[]
  onChecklistChange: (id: string, checked: boolean) => void
  className?: string
}

export function ConfirmationChecklist({
  validationChecklistItems,
  onChecklistChange,
  className,
}: ConfirmationChecklistProps) {
  const allChecked = validationChecklistItems.every((item) => item.checked)
  const someChecked = validationChecklistItems.some((item) => item.checked)

  return (
    <div className={cn("space-y-4", className)}>
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-foreground">Confirmación de Carga</h3>
        <span
          className={cn(
            "text-xs font-medium px-2 py-1 rounded-full",
            allChecked
              ? "bg-emerald-100 text-emerald-700"
              : someChecked
                ? "bg-amber-100 text-amber-700"
                : "bg-muted text-muted-foreground",
          )}
        >
          {validationChecklistItems.filter((i) => i.checked).length} / {validationChecklistItems.length}
        </span>
      </div>

      <div className="space-y-3 p-4 bg-muted/50 rounded-lg border">
        {validationChecklistItems.map((item) => (
          <div key={item.id} className="flex items-start gap-3">
            <Checkbox
              id={item.id}
              checked={item.checked}
              onCheckedChange={(checked) => onChecklistChange(item.id, checked as boolean)}
              className="mt-0.5"
            />
            <Label
              htmlFor={item.id}
              className={cn(
                "text-sm leading-relaxed cursor-pointer",
                item.checked ? "text-foreground" : "text-muted-foreground",
              )}
            >
              {item.label}
            </Label>
          </div>
        ))}
      </div>
    </div>
  )
}
