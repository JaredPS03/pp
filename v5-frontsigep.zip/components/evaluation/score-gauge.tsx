"use client"

import { cn } from "@/lib/utils"

interface ScoreGaugeProps {
  score: number
  minScore: number
  maxScore: number
  className?: string
}

export function ScoreGauge({ score, minScore, maxScore, className }: ScoreGaugeProps) {
  const percentage = Math.min(100, Math.max(0, ((score - minScore) / (maxScore - minScore)) * 100))

  const getScoreColor = () => {
    if (percentage < 33) return { bg: "bg-red-500", text: "text-red-600", ring: "ring-red-200" }
    if (percentage < 66) return { bg: "bg-amber-500", text: "text-amber-600", ring: "ring-amber-200" }
    return { bg: "bg-emerald-500", text: "text-emerald-600", ring: "ring-emerald-200" }
  }

  const colors = getScoreColor()

  return (
    <div className={cn("flex flex-col gap-3", className)}>
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-muted-foreground">Puntuación Actual</span>
        <span className={cn("text-2xl font-bold", colors.text)}>{score}</span>
      </div>

      <div className="relative h-4 bg-secondary rounded-full overflow-hidden">
        <div
          className={cn("h-full transition-all duration-500 ease-out rounded-full", colors.bg)}
          style={{ width: `${percentage}%` }}
        />
      </div>

      <div className="flex justify-between text-xs text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-red-100 text-red-700 font-medium">
            Min: {minScore}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 font-medium">
            Max: {maxScore}
          </span>
        </div>
      </div>
    </div>
  )
}
