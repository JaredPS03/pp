"use client"

import { useState } from "react"
import { EvaluationSidebar } from "./evaluation-sidebar"
import { EvaluationHeader } from "./evaluation-header"
import { GeneralesView } from "./generales-view"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"

const SECTION_TITLES: Record<string, string> = {
  generales: "Documentos Generales",
  docencia: "Evidencias de Docencia",
  investigacion: "Evidencias de Investigación",
  tutorias: "Evidencias de Tutorías",
  "cuerpos-colegiados": "Evidencias de Cuerpos Colegiados",
}

interface TeacherEvaluationPlatformProps {
  onBack?: () => void
}

export function TeacherEvaluationPlatform({ onBack }: TeacherEvaluationPlatformProps) {
  const [activeSection, setActiveSection] = useState("generales")
  const [helpDialogOpen, setHelpDialogOpen] = useState(false)

  const handleNextStep = () => {
    const sections = Object.keys(SECTION_TITLES)
    const currentIndex = sections.indexOf(activeSection)
    if (currentIndex < sections.length - 1) {
      setActiveSection(sections[currentIndex + 1])
    }
  }

  const renderContent = () => {
    switch (activeSection) {
      case "generales":
        return <GeneralesView onNextStep={handleNextStep} />
      default:
        return (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <h2 className="text-xl font-semibold text-muted-foreground mb-2">{SECTION_TITLES[activeSection]}</h2>
              <p className="text-sm text-muted-foreground">Esta sección está en desarrollo</p>
            </div>
          </div>
        )
    }
  }

  return (
    <div className="flex h-full bg-background">
      {/* Sidebar */}
      <EvaluationSidebar activeSection={activeSection} onSectionChange={setActiveSection} onBack={onBack} />

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <EvaluationHeader title={SECTION_TITLES[activeSection]} onHelpClick={() => setHelpDialogOpen(true)} />
        <main className="flex-1 overflow-hidden">{renderContent()}</main>
      </div>

      {/* Help Dialog */}
      <Dialog open={helpDialogOpen} onOpenChange={setHelpDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Centro de Ayuda</DialogTitle>
            <DialogDescription>Información sobre el uso de la plataforma de evaluación docente.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="font-semibold text-blue-800 mb-1">Soporte Técnico</h4>
              <p className="text-blue-700 text-sm">soporte@universidad.edu.mx</p>
              <p className="text-blue-600 text-xs mt-1">Horario: Lun-Vie 9:00 - 18:00</p>
            </div>
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
              <h4 className="font-semibold text-amber-800 mb-1">Instrucciones</h4>
              <ul className="text-amber-700 text-sm space-y-1 list-disc list-inside">
                <li>Carga los documentos en formato PDF</li>
                <li>Tamaño máximo: 10 MB por archivo</li>
                <li>Completa todas las confirmaciones antes de continuar</li>
              </ul>
            </div>
          </div>
          <div className="flex justify-end">
            <Button variant="outline" onClick={() => setHelpDialogOpen(false)}>
              Cerrar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
