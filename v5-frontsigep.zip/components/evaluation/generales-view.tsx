"use client"

import { useState, useCallback } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ScoreGauge } from "./score-gauge"
import { DocumentUploader, type UploadedFile } from "./document-uploader"
import { UploadedFilesTable } from "./uploaded-files-table"
import { ConfirmationChecklist, type ChecklistItem } from "./confirmation-checklist"
import { ChevronRight } from "lucide-react"

interface RequirementState {
  requirementId: string
  requirementName: string
  mainFile: UploadedFile | null
  complementaryFiles: UploadedFile[]
}

const INITIAL_REQUIREMENTS: RequirementState[] = [
  {
    requirementId: "solicitud-ingreso",
    requirementName: "Solicitud de Ingreso",
    mainFile: null,
    complementaryFiles: [],
  },
  {
    requirementId: "carta-exclusividad",
    requirementName: "Carta de Exclusividad",
    mainFile: null,
    complementaryFiles: [],
  },
  {
    requirementId: "constancia-antiguedad",
    requirementName: "Constancia de Antigüedad",
    mainFile: null,
    complementaryFiles: [],
  },
  {
    requirementId: "informe-evaluacion",
    requirementName: "Informe de Evaluación",
    mainFile: null,
    complementaryFiles: [],
  },
  { requirementId: "documentos-grado", requirementName: "Documentos de Grado", mainFile: null, complementaryFiles: [] },
]

const INITIAL_CHECKLIST: ChecklistItem[] = [
  {
    id: "check-solicitud",
    label: "Confirmo que la solicitud de ingreso está correctamente llenada y firmada.",
    checked: false,
  },
  {
    id: "check-exclusividad",
    label: "Confirmo que la carta de exclusividad es vigente y corresponde al periodo actual.",
    checked: false,
  },
  {
    id: "check-antiguedad",
    label: "Confirmo que la constancia de antigüedad refleja mis años de servicio reales.",
    checked: false,
  },
  {
    id: "check-evaluacion",
    label: "Confirmo que el informe de evaluación corresponde al ciclo escolar actual.",
    checked: false,
  },
  { id: "check-grado", label: "Confirmo que los documentos de grado son legibles y están validados.", checked: false },
]

interface GeneralesViewProps {
  onNextStep?: () => void
}

export function GeneralesView({ onNextStep }: GeneralesViewProps) {
  const [expectedScoreValue, setExpectedScoreValue] = useState<string>("")
  const [requirements, setRequirements] = useState<RequirementState[]>(INITIAL_REQUIREMENTS)
  const [validationChecklistItems, setValidationChecklistItems] = useState<ChecklistItem[]>(INITIAL_CHECKLIST)

  // Foreign document state for "Documentos de Grado"
  const [isForeignDocument, setIsForeignDocument] = useState(false)
  const [foreignCountry, setForeignCountry] = useState("")
  const [foreignInstitution, setForeignInstitution] = useState("")

  const calculateCurrentScore = () => {
    const uploadedCount = requirements.filter((r) => r.mainFile !== null).length
    return uploadedCount * 20 // Each document is worth 20 points
  }

  const handleMainFileUpload = useCallback((file: File | null, requirementId: string) => {
    setRequirements((prev) =>
      prev.map((req) => {
        if (req.requirementId === requirementId) {
          return {
            ...req,
            mainFile: file
              ? {
                  id: `main-${requirementId}-${Date.now()}`,
                  name: file.name,
                  size: file.size,
                  file,
                }
              : null,
          }
        }
        return req
      }),
    )
  }, [])

  const handleComplementaryUpload = useCallback((file: File, requirementId: string) => {
    setRequirements((prev) =>
      prev.map((req) => {
        if (req.requirementId === requirementId) {
          return {
            ...req,
            complementaryFiles: [
              ...req.complementaryFiles,
              {
                id: `comp-${requirementId}-${Date.now()}`,
                name: file.name,
                size: file.size,
                file,
              },
            ],
          }
        }
        return req
      }),
    )
  }, [])

  const handleComplementaryRemove = useCallback((fileId: string, requirementId: string) => {
    setRequirements((prev) =>
      prev.map((req) => {
        if (req.requirementId === requirementId) {
          return {
            ...req,
            complementaryFiles: req.complementaryFiles.filter((f) => f.id !== fileId),
          }
        }
        return req
      }),
    )
  }, [])

  const handleChecklistChange = useCallback((id: string, checked: boolean) => {
    setValidationChecklistItems((prev) => prev.map((item) => (item.id === id ? { ...item, checked } : item)))
  }, [])

  const handleViewFile = (file: UploadedFile) => {
    const url = URL.createObjectURL(file.file)
    window.open(url, "_blank")
  }

  const handleDeleteMainFile = (requirementId: string) => {
    handleMainFileUpload(null, requirementId)
  }

  const allChecklistCompleted = validationChecklistItems.every((item) => item.checked)
  const currentScore = calculateCurrentScore()

  return (
    <div className="flex flex-col h-full">
      {/* Scrollable Content */}
      <div className="flex-1 overflow-y-auto p-6 content-scroll">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Top Info Bar */}
          <Card>
            <CardContent className="p-6">
              <div className="grid md:grid-cols-2 gap-6">
                {/* Score Gauge */}
                <ScoreGauge score={currentScore} minScore={0} maxScore={100} />

                {/* Expected Score Input */}
                <div className="space-y-3">
                  <Label htmlFor="expected-score" className="text-sm font-medium">
                    Puntaje Auto-Evaluado Esperado
                  </Label>
                  <Input
                    id="expected-score"
                    type="number"
                    placeholder="Ingresa tu puntaje esperado"
                    value={expectedScoreValue}
                    onChange={(e) => setExpectedScoreValue(e.target.value)}
                    className="text-lg"
                    min={0}
                    max={100}
                  />
                  <p className="text-xs text-muted-foreground">
                    Ingresa el puntaje que esperas obtener en esta sección (0-100)
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Document Uploaders Grid */}
          <div>
            <h2 className="text-lg font-semibold mb-4">Documentos Requeridos</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {requirements.map((req) => (
                <DocumentUploader
                  key={req.requirementId}
                  title={req.requirementName}
                  requirementId={req.requirementId}
                  mainFile={req.mainFile}
                  complementaryFiles={req.complementaryFiles}
                  onMainFileUpload={handleMainFileUpload}
                  onComplementaryUpload={handleComplementaryUpload}
                  onComplementaryRemove={handleComplementaryRemove}
                  showForeignToggle={req.requirementId === "documentos-grado"}
                  isForeign={req.requirementId === "documentos-grado" ? isForeignDocument : undefined}
                  onForeignToggle={req.requirementId === "documentos-grado" ? setIsForeignDocument : undefined}
                  foreignCountry={req.requirementId === "documentos-grado" ? foreignCountry : undefined}
                  onForeignCountryChange={req.requirementId === "documentos-grado" ? setForeignCountry : undefined}
                  foreignInstitution={req.requirementId === "documentos-grado" ? foreignInstitution : undefined}
                  onForeignInstitutionChange={
                    req.requirementId === "documentos-grado" ? setForeignInstitution : undefined
                  }
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Fixed Footer */}
      <div className="border-t bg-muted/30 p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Summary Table */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Resumen de Documentos Cargados</CardTitle>
            </CardHeader>
            <CardContent>
              <UploadedFilesTable
                requirements={requirements}
                onViewFile={handleViewFile}
                onDeleteMainFile={handleDeleteMainFile}
                onDeleteComplementaryFile={handleComplementaryRemove}
              />
            </CardContent>
          </Card>

          {/* Confirmation Checklist */}
          <ConfirmationChecklist
            validationChecklistItems={validationChecklistItems}
            onChecklistChange={handleChecklistChange}
          />

          {/* Next Step Button */}
          <div className="flex justify-end pt-2">
            <Button size="lg" disabled={!allChecklistCompleted} onClick={onNextStep} className="gap-2">
              Siguiente Paso
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
