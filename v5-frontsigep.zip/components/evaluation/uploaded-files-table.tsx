"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { FileText, Trash2, Eye } from "lucide-react"
import type { UploadedFile } from "./document-uploader"

interface RequirementData {
  requirementId: string
  requirementName: string
  mainFile: UploadedFile | null
  complementaryFiles: UploadedFile[]
}

interface UploadedFilesTableProps {
  requirements: RequirementData[]
  onViewFile: (file: UploadedFile) => void
  onDeleteMainFile: (requirementId: string) => void
  onDeleteComplementaryFile: (fileId: string, requirementId: string) => void
}

export function UploadedFilesTable({
  requirements,
  onViewFile,
  onDeleteMainFile,
  onDeleteComplementaryFile,
}: UploadedFilesTableProps) {
  const uploadedRequirements = requirements.filter((r) => r.mainFile !== null)

  if (uploadedRequirements.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
        <p className="text-sm">No hay archivos cargados todavía</p>
      </div>
    )
  }

  return (
    <div className="border rounded-lg overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="font-semibold">Requisito</TableHead>
            <TableHead className="font-semibold">Archivo Principal</TableHead>
            <TableHead className="font-semibold">Archivos Complementarios</TableHead>
            <TableHead className="font-semibold text-center">Estado</TableHead>
            <TableHead className="font-semibold text-right">Acciones</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {uploadedRequirements.map((req) => (
            <TableRow key={req.requirementId}>
              <TableCell className="font-medium">{req.requirementName}</TableCell>
              <TableCell>
                {req.mainFile && (
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4 text-red-500 flex-shrink-0" />
                    <span className="text-sm truncate max-w-[150px]">{req.mainFile.name}</span>
                  </div>
                )}
              </TableCell>
              <TableCell>
                {req.complementaryFiles.length > 0 ? (
                  <div className="flex flex-col gap-1">
                    {req.complementaryFiles.map((file) => (
                      <Badge key={file.id} variant="outline" className="text-xs w-fit flex items-center gap-1">
                        <FileText className="h-3 w-3 text-blue-500" />
                        <span className="truncate max-w-[100px]">{file.name}</span>
                        <button
                          onClick={() => onDeleteComplementaryFile(file.id, req.requirementId)}
                          className="ml-1 hover:text-destructive"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                  </div>
                ) : (
                  <span className="text-xs text-muted-foreground">—</span>
                )}
              </TableCell>
              <TableCell className="text-center">
                <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">Cargado</Badge>
              </TableCell>
              <TableCell className="text-right">
                <div className="flex items-center justify-end gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => req.mainFile && onViewFile(req.mainFile)}
                  >
                    <Eye className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-destructive hover:text-destructive"
                    onClick={() => onDeleteMainFile(req.requirementId)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  )
}
