"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Upload, FileCheck2 } from "lucide-react"

type ProductType = "jcr" | "book" | "class" | ""

interface FormData {
  productType: ProductType
  // JCR fields
  issn?: string
  journalName?: string
  quartile?: string
  doi?: string
  impactFactor?: string
  // Book fields
  isbn?: string
  publisher?: string
  country?: string
  bookTitle?: string
  // Class fields
  subjectName?: string
  semester?: string
  studentCount?: string
  // File
  file?: File
}

export default function EvidenceUploadForm() {
  const [formData, setFormData] = useState<FormData>({
    productType: "",
  })
  const [file, setFile] = useState<File | null>(null)
  const [isDragActive, setIsDragActive] = useState(false)

  const handleProductTypeChange = (value: string) => {
    setFormData({ productType: value as ProductType })
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleDrag = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setIsDragActive(true)
    } else if (e.type === "dragleave") {
      setIsDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    e.stopPropagation()
    setIsDragActive(false)

    const droppedFiles = e.dataTransfer.files
    if (droppedFiles.length > 0) {
      const droppedFile = droppedFiles[0]
      if (droppedFile.type === "application/pdf") {
        setFile(droppedFile)
      }
    }
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFile = e.target.files[0]
      if (selectedFile.type === "application/pdf") {
        setFile(selectedFile)
      }
    }
  }

  const handleSave = () => {
    if (!formData.productType || !file) {
      alert("Por favor completa todos los campos y selecciona un archivo")
      return
    }

    console.log("Guardando evidencia:", {
      ...formData,
      fileName: file.name,
      fileSize: file.size,
    })

    // Here you would typically send the data to your backend
    alert("Evidencia guardada exitosamente")
  }

  return (
    <div className="w-full max-w-2xl mx-auto p-6">
      <Card className="shadow-lg border-0">
        <CardHeader className="bg-primary text-primary-foreground rounded-t-lg">
          <CardTitle className="flex items-center gap-2">
            <FileCheck2 className="h-6 w-6" />
            Formulario de Carga de Evidencias
          </CardTitle>
        </CardHeader>

        <CardContent className="p-6 space-y-6">
          {/* Product Type Select */}
          <div className="space-y-2">
            <Label htmlFor="product-type" className="text-sm font-semibold text-primary">
              Selecciona el Tipo de Producto
            </Label>
            <Select value={formData.productType} onValueChange={handleProductTypeChange}>
              <SelectTrigger
                id="product-type"
                className="border-2 border-border hover:border-primary focus:border-primary"
              >
                <SelectValue placeholder="Elige un tipo de producto..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="jcr">Artículo JCR</SelectItem>
                <SelectItem value="book">Libro</SelectItem>
                <SelectItem value="class">Clase Frente a Grupo</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Dynamic Sections Based on Product Type */}
          {formData.productType === "jcr" && (
            <div className="space-y-4 p-4 bg-accent/30 rounded-lg border border-accent">
              <h3 className="font-semibold text-primary text-sm uppercase tracking-wide">
                Información del Artículo JCR
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="issn" className="text-xs font-medium">
                    ISSN
                  </Label>
                  <Input
                    id="issn"
                    name="issn"
                    placeholder="ej: 1234-5678"
                    value={formData.issn || ""}
                    onChange={handleInputChange}
                    className="border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="journal-name" className="text-xs font-medium">
                    Nombre de la Revista
                  </Label>
                  <Input
                    id="journal-name"
                    name="journalName"
                    placeholder="ej: Nature"
                    value={formData.journalName || ""}
                    onChange={handleInputChange}
                    className="border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="quartile" className="text-xs font-medium">
                    Cuartil
                  </Label>
                  <Select
                    value={formData.quartile || ""}
                    onValueChange={(value) => handleSelectChange("quartile", value)}
                  >
                    <SelectTrigger id="quartile" className="border-border focus:border-primary">
                      <SelectValue placeholder="Selecciona cuartil..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="q1">Q1</SelectItem>
                      <SelectItem value="q2">Q2</SelectItem>
                      <SelectItem value="q3">Q3</SelectItem>
                      <SelectItem value="q4">Q4</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="doi" className="text-xs font-medium">
                    DOI
                  </Label>
                  <Input
                    id="doi"
                    name="doi"
                    placeholder="ej: 10.1234/example"
                    value={formData.doi || ""}
                    onChange={handleInputChange}
                    className="border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="impact-factor" className="text-xs font-medium">
                    Factor de Impacto
                  </Label>
                  <Input
                    id="impact-factor"
                    name="impactFactor"
                    placeholder="ej: 5.2"
                    value={formData.impactFactor || ""}
                    onChange={handleInputChange}
                    className="border-border focus:border-primary"
                  />
                </div>
              </div>
            </div>
          )}

          {formData.productType === "book" && (
            <div className="space-y-4 p-4 bg-accent/30 rounded-lg border border-accent">
              <h3 className="font-semibold text-primary text-sm uppercase tracking-wide">Información del Libro</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="isbn" className="text-xs font-medium">
                    ISBN
                  </Label>
                  <Input
                    id="isbn"
                    name="isbn"
                    placeholder="ej: 978-1234567890"
                    value={formData.isbn || ""}
                    onChange={handleInputChange}
                    className="border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="publisher" className="text-xs font-medium">
                    Editorial
                  </Label>
                  <Input
                    id="publisher"
                    name="publisher"
                    placeholder="ej: Pearson"
                    value={formData.publisher || ""}
                    onChange={handleInputChange}
                    className="border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="country" className="text-xs font-medium">
                    País
                  </Label>
                  <Input
                    id="country"
                    name="country"
                    placeholder="ej: México"
                    value={formData.country || ""}
                    onChange={handleInputChange}
                    className="border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="book-title" className="text-xs font-medium">
                    Título del Libro
                  </Label>
                  <Input
                    id="book-title"
                    name="bookTitle"
                    placeholder="ej: Fundamentos de Programación"
                    value={formData.bookTitle || ""}
                    onChange={handleInputChange}
                    className="border-border focus:border-primary"
                  />
                </div>
              </div>
            </div>
          )}

          {formData.productType === "class" && (
            <div className="space-y-4 p-4 bg-accent/30 rounded-lg border border-accent">
              <h3 className="font-semibold text-primary text-sm uppercase tracking-wide">Información de la Clase</h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="subject-name" className="text-xs font-medium">
                    Nombre de la Asignatura
                  </Label>
                  <Input
                    id="subject-name"
                    name="subjectName"
                    placeholder="ej: Algoritmos"
                    value={formData.subjectName || ""}
                    onChange={handleInputChange}
                    className="border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="semester" className="text-xs font-medium">
                    Semestre
                  </Label>
                  <Input
                    id="semester"
                    name="semester"
                    placeholder="ej: 2024-1"
                    value={formData.semester || ""}
                    onChange={handleInputChange}
                    className="border-border focus:border-primary"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="student-count" className="text-xs font-medium">
                    No. de Alumnos
                  </Label>
                  <Input
                    id="student-count"
                    name="studentCount"
                    placeholder="ej: 35"
                    type="number"
                    value={formData.studentCount || ""}
                    onChange={handleInputChange}
                    className="border-border focus:border-primary"
                  />
                </div>
              </div>
            </div>
          )}

          {/* File Upload Area */}
          <div className="space-y-2">
            <Label className="text-sm font-semibold text-primary">Archivo de Evidencia (PDF)</Label>
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              className={`relative border-2 border-dashed rounded-lg p-8 transition-colors ${
                isDragActive ? "border-primary bg-primary/5" : "border-border bg-muted/30 hover:border-primary/50"
              }`}
            >
              <div className="flex flex-col items-center justify-center space-y-3">
                <div className="p-3 bg-primary/10 rounded-full">
                  <Upload className="h-6 w-6 text-primary" />
                </div>
                <div className="text-center">
                  <p className="text-sm font-semibold text-primary">{file ? file.name : "Arrastra el PDF aquí"}</p>
                  <p className="text-xs text-muted-foreground mt-1">o haz clic para seleccionar un archivo</p>
                </div>
              </div>
              <input
                type="file"
                accept="application/pdf"
                onChange={handleFileInput}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
            </div>
            {file && (
              <p className="text-xs text-muted-foreground">
                Archivo seleccionado: {(file.size / 1024 / 1024).toFixed(2)} MB
              </p>
            )}
          </div>

          {/* Save Button */}
          <Button
            onClick={handleSave}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-6 rounded-lg transition-colors"
          >
            Guardar Evidencia
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
