"use client"

import type React from "react"

import { useState } from "react"
import { Upload, X, AlertCircle } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

type ProductType = "research-article" | "book" | "thesis-direction" | "teaching" | null

interface EvidenceFormData {
  productType: ProductType
  // Research Article fields
  issn?: string
  journalName?: string
  doi?: string
  index?: "jcr" | "scopus"
  quartile?: "q1" | "q2" | "q3" | "q4"
  impactFactor?: string
  // Book fields
  isbn?: string
  publisher?: string
  country?: string
  bookTitle?: string
  // Thesis Direction fields
  degree?: "lic" | "mtra" | "doc"
  studentName?: string
  examDate?: string
  // Teaching fields
  subjectName?: string
  semester?: string
  weeklyHours?: string
  // File
  file?: File
}

export function SmartEvidenceForm() {
  const [formData, setFormData] = useState<EvidenceFormData>({
    productType: null,
  })
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [dragActive, setDragActive] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const handleProductTypeChange = (value: string) => {
    setFormData({
      productType: value as ProductType,
      // Reset all fields when changing product type
      issn: undefined,
      journalName: undefined,
      doi: undefined,
      index: undefined,
      quartile: undefined,
      impactFactor: undefined,
      isbn: undefined,
      publisher: undefined,
      country: undefined,
      bookTitle: undefined,
      degree: undefined,
      studentName: undefined,
      examDate: undefined,
      subjectName: undefined,
      semester: undefined,
      weeklyHours: undefined,
    })
    setErrors({})
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
    // Clear error for this field
    if (errors[field]) {
      setErrors((prev) => {
        const { [field]: _, ...rest } = prev
        return rest
      })
    }
  }

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    const files = e.dataTransfer.files
    if (files && files[0]) {
      const file = files[0]
      if (file.type === "application/pdf") {
        setUploadedFile(file)
        setFormData((prev) => ({ ...prev, file }))
      } else {
        setErrors((prev) => ({
          ...prev,
          file: "Solo se permiten archivos PDF",
        }))
      }
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.currentTarget.files
    if (files && files[0]) {
      const file = files[0]
      if (file.type === "application/pdf") {
        setUploadedFile(file)
        setFormData((prev) => ({ ...prev, file }))
        setErrors((prev) => {
          const { file: _, ...rest } = prev
          return rest
        })
      } else {
        setErrors((prev) => ({
          ...prev,
          file: "Solo se permiten archivos PDF",
        }))
      }
    }
  }

  const removeFile = () => {
    setUploadedFile(null)
    setFormData((prev) => ({ ...prev, file: undefined }))
  }

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {}

    if (!formData.productType) {
      newErrors.productType = "Selecciona un tipo de producto"
    }

    if (!uploadedFile) {
      newErrors.file = "Sube un archivo PDF de evidencia"
    }

    if (formData.productType === "research-article") {
      if (!formData.issn) newErrors.issn = "ISSN es requerido"
      if (!formData.journalName) newErrors.journalName = "Nombre de revista es requerido"
      if (!formData.doi) newErrors.doi = "DOI es requerido"
      if (!formData.index) newErrors.index = "Índice es requerido"
      if (!formData.quartile) newErrors.quartile = "Cuartil es requerido"
    }

    if (formData.productType === "book") {
      if (!formData.isbn) newErrors.isbn = "ISBN es requerido"
      if (!formData.publisher) newErrors.publisher = "Editorial es requerida"
      if (!formData.country) newErrors.country = "País es requerido"
      if (!formData.bookTitle) newErrors.bookTitle = "Título del libro es requerido"
    }

    if (formData.productType === "thesis-direction") {
      if (!formData.degree) newErrors.degree = "Grado es requerido"
      if (!formData.studentName) newErrors.studentName = "Nombre del alumno es requerido"
      if (!formData.examDate) newErrors.examDate = "Fecha de examen es requerida"
    }

    if (formData.productType === "teaching") {
      if (!formData.subjectName) newErrors.subjectName = "Nombre de asignatura es requerido"
      if (!formData.semester) newErrors.semester = "Semestre es requerido"
      if (!formData.weeklyHours) newErrors.weeklyHours = "Horas semanales es requerido"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      return
    }

    // TODO_BACKEND: Implementar conexión con Supabase/MySQL aquí
    // TODO_ACTION: Validar archivo PDF y generar Hash
    // TODO_ACTION: Almacenar en storage (Vercel Blob o S3)
    // TODO_ACTION: Registrar evidencia en base de datos
    console.log("[v0] Evidence Form Data:", formData)
    console.log("[v0] File to upload:", uploadedFile)

    // Simular envío
    alert("Evidencia guardada exitosamente (simulación)")
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="border border-border shadow-sm">
        <CardHeader className="border-b border-border bg-muted/30">
          <CardTitle className="text-2xl font-bold text-primary flex items-center gap-2">
            <Upload className="h-6 w-6" />
            Formulario de Carga de Evidencias
          </CardTitle>
          <CardDescription>
            Selecciona el tipo de producto académico y completa los campos correspondientes
          </CardDescription>
        </CardHeader>

        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Tipo de Producto Principal */}
            <div className="space-y-3">
              <Label htmlFor="product-type" className="text-base font-semibold">
                Selecciona el Tipo de Producto
              </Label>
              <Select value={formData.productType || ""} onValueChange={handleProductTypeChange}>
                <SelectTrigger
                  id="product-type"
                  className={`w-full h-11 ${errors.productType ? "border-destructive" : ""}`}
                >
                  <SelectValue placeholder="Elige una opción..." />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="research-article">Artículo de Investigación (JCR/Scopus)</SelectItem>
                  <SelectItem value="book">Libro</SelectItem>
                  <SelectItem value="thesis-direction">Dirección de Tesis</SelectItem>
                  <SelectItem value="teaching">Docencia</SelectItem>
                </SelectContent>
              </Select>
              {errors.productType && <p className="text-sm text-destructive">{errors.productType}</p>}
            </div>

            {/* Sección Dinámica - Artículo de Investigación */}
            {formData.productType === "research-article" && (
              <div className="space-y-4 p-4 bg-accent/30 rounded-lg border border-accent/50">
                <h3 className="font-semibold text-primary">Información del Artículo</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="issn">ISSN</Label>
                    <Input
                      id="issn"
                      placeholder="0123-4567"
                      value={formData.issn || ""}
                      onChange={(e) => handleInputChange("issn", e.target.value)}
                      className={errors.issn ? "border-destructive" : ""}
                    />
                    {errors.issn && <p className="text-xs text-destructive">{errors.issn}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="journalName">Nombre de la Revista</Label>
                    <Input
                      id="journalName"
                      placeholder="Nature, Science..."
                      value={formData.journalName || ""}
                      onChange={(e) => handleInputChange("journalName", e.target.value)}
                      className={errors.journalName ? "border-destructive" : ""}
                    />
                    {errors.journalName && <p className="text-xs text-destructive">{errors.journalName}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="doi">DOI</Label>
                    <Input
                      id="doi"
                      placeholder="10.1234/example"
                      value={formData.doi || ""}
                      onChange={(e) => handleInputChange("doi", e.target.value)}
                      className={errors.doi ? "border-destructive" : ""}
                    />
                    {errors.doi && <p className="text-xs text-destructive">{errors.doi}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="index">Índice</Label>
                    <Select value={formData.index || ""} onValueChange={(v) => handleInputChange("index", v)}>
                      <SelectTrigger id="index" className={errors.index ? "border-destructive" : ""}>
                        <SelectValue placeholder="Selecciona índice..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="jcr">JCR</SelectItem>
                        <SelectItem value="scopus">Scopus</SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.index && <p className="text-xs text-destructive">{errors.index}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="quartile">Cuartil</Label>
                    <Select value={formData.quartile || ""} onValueChange={(v) => handleInputChange("quartile", v)}>
                      <SelectTrigger id="quartile" className={errors.quartile ? "border-destructive" : ""}>
                        <SelectValue placeholder="Selecciona cuartil..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="q1">Q1</SelectItem>
                        <SelectItem value="q2">Q2</SelectItem>
                        <SelectItem value="q3">Q3</SelectItem>
                        <SelectItem value="q4">Q4</SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.quartile && <p className="text-xs text-destructive">{errors.quartile}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="impactFactor">Factor de Impacto (opcional)</Label>
                    <Input
                      id="impactFactor"
                      placeholder="2.5"
                      value={formData.impactFactor || ""}
                      onChange={(e) => handleInputChange("impactFactor", e.target.value)}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Sección Dinámica - Libro */}
            {formData.productType === "book" && (
              <div className="space-y-4 p-4 bg-accent/30 rounded-lg border border-accent/50">
                <h3 className="font-semibold text-primary">Información del Libro</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="isbn">ISBN</Label>
                    <Input
                      id="isbn"
                      placeholder="978-84-123456-7"
                      value={formData.isbn || ""}
                      onChange={(e) => handleInputChange("isbn", e.target.value)}
                      className={errors.isbn ? "border-destructive" : ""}
                    />
                    {errors.isbn && <p className="text-xs text-destructive">{errors.isbn}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="publisher">Editorial</Label>
                    <Input
                      id="publisher"
                      placeholder="Editorial Universitaria"
                      value={formData.publisher || ""}
                      onChange={(e) => handleInputChange("publisher", e.target.value)}
                      className={errors.publisher ? "border-destructive" : ""}
                    />
                    {errors.publisher && <p className="text-xs text-destructive">{errors.publisher}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="country">País</Label>
                    <Input
                      id="country"
                      placeholder="México"
                      value={formData.country || ""}
                      onChange={(e) => handleInputChange("country", e.target.value)}
                      className={errors.country ? "border-destructive" : ""}
                    />
                    {errors.country && <p className="text-xs text-destructive">{errors.country}</p>}
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="bookTitle">Título del Libro</Label>
                    <Input
                      id="bookTitle"
                      placeholder="Título completo del libro"
                      value={formData.bookTitle || ""}
                      onChange={(e) => handleInputChange("bookTitle", e.target.value)}
                      className={errors.bookTitle ? "border-destructive" : ""}
                    />
                    {errors.bookTitle && <p className="text-xs text-destructive">{errors.bookTitle}</p>}
                  </div>
                </div>
              </div>
            )}

            {/* Sección Dinámica - Dirección de Tesis */}
            {formData.productType === "thesis-direction" && (
              <div className="space-y-4 p-4 bg-accent/30 rounded-lg border border-accent/50">
                <h3 className="font-semibold text-primary">Información de la Tesis</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="degree">Grado</Label>
                    <Select value={formData.degree || ""} onValueChange={(v) => handleInputChange("degree", v)}>
                      <SelectTrigger id="degree" className={errors.degree ? "border-destructive" : ""}>
                        <SelectValue placeholder="Selecciona grado..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="lic">Licenciatura</SelectItem>
                        <SelectItem value="mtra">Maestría</SelectItem>
                        <SelectItem value="doc">Doctorado</SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.degree && <p className="text-xs text-destructive">{errors.degree}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="studentName">Nombre del Alumno</Label>
                    <Input
                      id="studentName"
                      placeholder="Juan García López"
                      value={formData.studentName || ""}
                      onChange={(e) => handleInputChange("studentName", e.target.value)}
                      className={errors.studentName ? "border-destructive" : ""}
                    />
                    {errors.studentName && <p className="text-xs text-destructive">{errors.studentName}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="examDate">Fecha de Examen</Label>
                    <Input
                      id="examDate"
                      type="date"
                      value={formData.examDate || ""}
                      onChange={(e) => handleInputChange("examDate", e.target.value)}
                      className={errors.examDate ? "border-destructive" : ""}
                    />
                    {errors.examDate && <p className="text-xs text-destructive">{errors.examDate}</p>}
                  </div>
                </div>
              </div>
            )}

            {/* Sección Dinámica - Docencia */}
            {formData.productType === "teaching" && (
              <div className="space-y-4 p-4 bg-accent/30 rounded-lg border border-accent/50">
                <h3 className="font-semibold text-primary">Información de la Asignatura</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="subjectName">Nombre de la Asignatura</Label>
                    <Input
                      id="subjectName"
                      placeholder="Ingeniería de Software"
                      value={formData.subjectName || ""}
                      onChange={(e) => handleInputChange("subjectName", e.target.value)}
                      className={errors.subjectName ? "border-destructive" : ""}
                    />
                    {errors.subjectName && <p className="text-xs text-destructive">{errors.subjectName}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="semester">Semestre</Label>
                    <Input
                      id="semester"
                      placeholder="2024-A"
                      value={formData.semester || ""}
                      onChange={(e) => handleInputChange("semester", e.target.value)}
                      className={errors.semester ? "border-destructive" : ""}
                    />
                    {errors.semester && <p className="text-xs text-destructive">{errors.semester}</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="weeklyHours">Horas Semanales</Label>
                    <Input
                      id="weeklyHours"
                      type="number"
                      placeholder="4"
                      value={formData.weeklyHours || ""}
                      onChange={(e) => handleInputChange("weeklyHours", e.target.value)}
                      className={errors.weeklyHours ? "border-destructive" : ""}
                    />
                    {errors.weeklyHours && <p className="text-xs text-destructive">{errors.weeklyHours}</p>}
                  </div>
                </div>
              </div>
            )}

            {/* Área Drag & Drop */}
            <div className="space-y-3">
              <Label className="text-base font-semibold">Sube el PDF de Evidencia</Label>
              {!uploadedFile ? (
                <div
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                  className={`relative p-8 border-2 border-dashed rounded-lg transition-colors cursor-pointer ${
                    dragActive ? "border-primary bg-primary/5" : "border-border bg-muted/30"
                  } ${errors.file ? "border-destructive bg-destructive/5" : ""}`}
                >
                  <input
                    type="file"
                    accept=".pdf"
                    onChange={handleFileSelect}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  <div className="flex flex-col items-center justify-center gap-3">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <Upload className="h-6 w-6 text-primary" />
                    </div>
                    <div className="text-center">
                      <p className="font-semibold text-primary">Arrastra tu archivo PDF aquí</p>
                      <p className="text-sm text-muted-foreground">o haz clic para seleccionar</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-green-100 rounded">
                      <Upload className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium text-green-900">{uploadedFile.name}</p>
                      <p className="text-sm text-green-700">{(uploadedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={removeFile}
                    className="text-green-600 hover:bg-green-100"
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>
              )}
              {errors.file && (
                <p className="text-sm text-destructive flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  {errors.file}
                </p>
              )}
            </div>

            {/* Botón Guardar */}
            <div className="flex gap-3 pt-4 border-t border-border">
              <Button
                type="submit"
                className="flex-1 h-11 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
              >
                <Upload className="h-4 w-4 mr-2" />
                Guardar Evidencia
              </Button>
              <Button type="button" variant="outline" className="px-6 bg-transparent">
                Cancelar
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
