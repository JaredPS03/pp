"use client"

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { RubricEvaluationLayout } from "./rubrics/rubric-evaluation-layout"
import type { EvaluationRubric, RequirementItem } from "@/types/evaluation"

interface UploadedFile {
  id: string
  name: string
  size: string
}

interface SectionContentProps {
  item: {
    id: string
    title: string
    description?: string
    isFolder?: boolean
    items?: any[]
  }
  onNavigateNext?: () => void
  onNavigatePrev?: () => void
  hasNext?: boolean
  hasPrev?: boolean
  nextTitle?: string
  prevTitle?: string
  breadcrumbPath?: string[]
}

function itemToRubricData(item: SectionContentProps["item"], props: SectionContentProps): EvaluationRubric {
  // Create a single requirement from the item
  const requirement: RequirementItem = {
    id: item.id,
    title: item.title,
    description: item.description || "Suba el documento requerido para este rubro.",
    isRequired: true,
    mainFile: null,
    complementaryFiles: [],
  }

  return {
    id: item.id,
    code: item.id.split("-")[0]?.toUpperCase() || "",
    title: item.title,
    description: item.description,
    sectionType: "rubric",
    scoring: {
      minScore: 0,
      maxScore: 100,
    },
    requirements: [requirement],
    nextRubricId: props.hasNext ? "next" : undefined,
    prevRubricId: props.hasPrev ? "prev" : undefined,
    nextRubricTitle: props.nextTitle,
    prevRubricTitle: props.prevTitle,
  }
}

export function SectionContent({
  item,
  onNavigateNext,
  onNavigatePrev,
  hasNext = false,
  hasPrev = false,
  nextTitle,
  prevTitle,
  breadcrumbPath = [],
}: SectionContentProps) {
  const [files, setFiles] = useState<UploadedFile[]>([])
  const [complementaryFiles, setComplementaryFiles] = useState<UploadedFile[]>([])
  const [comments, setComments] = useState("")
  const [expectedScore, setExpectedScore] = useState("")
  const [isDragging, setIsDragging] = useState(false)
  const [isDraggingComplementary, setIsDraggingComplementary] = useState(false)
  const [confirmations, setConfirmations] = useState({
    documentsComplete: false,
    infoAccurate: false,
    acceptTerms: false,
  })
  const [submitSuccess, setSubmitSuccess] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const complementaryInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTo({ top: 0, behavior: "smooth" })
    }
    setFiles([])
    setComplementaryFiles([])
    setComments("")
    setExpectedScore("")
    setConfirmations({ documentsComplete: false, infoAccurate: false, acceptTerms: false })
    setSubmitSuccess(false)
  }, [item.id])

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, isComplementary = false) => {
    const uploadedFiles = e.target.files
    if (uploadedFiles && uploadedFiles.length > 0) {
      const newFiles: UploadedFile[] = Array.from(uploadedFiles).map((file, index) => ({
        id: `${Date.now()}-${index}`,
        name: file.name,
        size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
      }))
      if (isComplementary) {
        setComplementaryFiles((prev) => [...prev, ...newFiles])
      } else {
        setFiles((prev) => [...prev, ...newFiles])
      }
    }
    e.target.value = ""
  }

  const handleDragOver = (e: React.DragEvent, isComplementary = false) => {
    e.preventDefault()
    if (isComplementary) {
      setIsDraggingComplementary(true)
    } else {
      setIsDragging(true)
    }
  }

  const handleDragLeave = (e: React.DragEvent, isComplementary = false) => {
    e.preventDefault()
    if (isComplementary) {
      setIsDraggingComplementary(false)
    } else {
      setIsDragging(false)
    }
  }

  const handleDrop = (e: React.DragEvent, isComplementary = false) => {
    e.preventDefault()
    if (isComplementary) {
      setIsDraggingComplementary(false)
    } else {
      setIsDragging(false)
    }
    const droppedFiles = e.dataTransfer.files
    if (droppedFiles.length > 0) {
      const newFiles: UploadedFile[] = Array.from(droppedFiles).map((file, index) => ({
        id: `${Date.now()}-${index}`,
        name: file.name,
        size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
      }))
      if (isComplementary) {
        setComplementaryFiles((prev) => [...prev, ...newFiles])
      } else {
        setFiles((prev) => [...prev, ...newFiles])
      }
    }
  }

  const handleRemoveFile = (id: string, isComplementary = false) => {
    if (isComplementary) {
      setComplementaryFiles((prev) => prev.filter((f) => f.id !== id))
    } else {
      setFiles((prev) => prev.filter((f) => f.id !== id))
    }
  }

  const minScore = 0
  const maxScore = 100

  const allConfirmed = confirmations.documentsComplete && confirmations.infoAccurate && confirmations.acceptTerms
  const canProceed = files.length > 0 && allConfirmed

  // If it's a folder, show folder view
  if (item.isFolder || (item.items && item.items.length > 0)) {
    return (
      <div className="h-full overflow-y-auto p-6 md:p-8 bg-white">
        <div className="max-w-4xl mx-auto">
          {breadcrumbPath.length > 1 && (
            <p className="text-sm text-gray-500 mb-2">{breadcrumbPath.slice(0, -1).join(" > ")}</p>
          )}
          <h1 className="text-2xl md:text-3xl font-bold text-[#002060] mb-6">{item.title}</h1>

          <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-6 mb-8">
            <div className="flex items-start gap-4">
              <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                <span className="text-blue-600 font-bold">i</span>
              </div>
              <div>
                <p className="text-lg text-blue-800 font-medium mb-2">
                  Esta sección contiene {item.items?.length || 0} elementos
                </p>
                <p className="text-blue-700">Seleccione uno del menú de la izquierda para cargar sus documentos.</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border-2 border-gray-200 divide-y divide-gray-200">
            {item.items?.map((subItem: any) => (
              <div key={subItem.id} className="flex items-center gap-4 p-5 hover:bg-gray-50 transition-colors">
                <span className="text-lg text-gray-700 flex-1">{subItem.title}</span>
                {subItem.items && (
                  <span className="text-sm text-gray-400 bg-gray-100 px-3 py-1 rounded-full">
                    {subItem.items.length} sub-elementos
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    )
  }

  const rubricData = itemToRubricData(item, {
    item,
    onNavigateNext,
    onNavigatePrev,
    hasNext,
    hasPrev,
    nextTitle,
    prevTitle,
    breadcrumbPath,
  })

  return (
    <RubricEvaluationLayout rubricData={rubricData} onNavigateNext={onNavigateNext} onNavigatePrev={onNavigatePrev} />
  )
}
