"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { BookOpen, Upload, CheckCircle2, ArrowLeft, LogOut } from "lucide-react"

interface UploadWizardProps {
  category: string | null
  onBack: () => void
  onLogout: () => void
}

export function UploadWizard({ category, onBack, onLogout }: UploadWizardProps) {
  const [step, setStep] = useState(1)
  const [uploadedFile, setUploadedFile] = useState<File | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [isChecked, setIsChecked] = useState(false)

  const categoryTitles: Record<string, string> = {
    docencia: "Docencia",
    investigacion: "Investigación",
    tutoria: "Tutoría",
    gestion: "Gestión",
  }

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const files = e.dataTransfer.files
    if (files.length > 0) {
      setUploadedFile(files[0])
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      setUploadedFile(files[0])
    }
  }

  const handleSave = () => {
    if (uploadedFile && isChecked) {
      // Simulate save
      alert("Documento guardado exitosamente")
      onBack()
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="container mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-accent rounded-full p-2">
              <BookOpen className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold">SIGEP UABJO</h1>
          </div>
          <Button onClick={onLogout} variant="secondary" size="lg" className="h-12 text-lg font-semibold">
            <LogOut className="mr-2 h-5 w-5" />
            Salir
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12 max-w-4xl">
        <div className="mb-8">
          <Button onClick={onBack} variant="outline" size="lg" className="mb-4 text-lg h-12 bg-transparent">
            <ArrowLeft className="mr-2 h-5 w-5" />
            Volver al Panel
          </Button>
          <h2 className="text-3xl font-bold text-primary mb-2">
            Carga de Documentos - {category ? categoryTitles[category] : ""}
          </h2>
          <p className="text-xl text-muted-foreground">Paso {step} de 2</p>
        </div>

        {step === 1 && (
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-primary">Paso 1: Subir Documento</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Drag and Drop Area */}
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                className={`border-4 border-dashed rounded-lg p-12 text-center transition-all ${
                  isDragging
                    ? "border-accent bg-accent/10"
                    : uploadedFile
                      ? "border-success bg-success/10"
                      : "border-border bg-muted/30"
                }`}
              >
                {uploadedFile ? (
                  <div className="space-y-4">
                    <div className="flex justify-center">
                      <CheckCircle2 className="h-20 w-20 text-success" />
                    </div>
                    <p className="text-2xl font-bold text-success">Archivo Cargado</p>
                    <p className="text-xl text-foreground">{uploadedFile.name}</p>
                    <Button
                      variant="outline"
                      onClick={() => setUploadedFile(null)}
                      size="lg"
                      className="text-lg h-12 mt-4"
                    >
                      Cambiar Archivo
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex justify-center">
                      <Upload className="h-20 w-20 text-muted-foreground" />
                    </div>
                    <p className="text-2xl font-bold text-foreground">Arrastra tu documento aquí</p>
                    <p className="text-lg text-muted-foreground">o haz clic para seleccionar</p>
                    <input
                      type="file"
                      id="file-input"
                      className="hidden"
                      onChange={handleFileSelect}
                      accept=".pdf,.doc,.docx"
                    />
                    <Button
                      variant="default"
                      size="lg"
                      className="text-xl h-14 px-8 mt-4"
                      onClick={() => document.getElementById("file-input")?.click()}
                    >
                      Seleccionar Archivo
                    </Button>
                  </div>
                )}
              </div>

              <div className="flex justify-end pt-4">
                <Button
                  onClick={() => setStep(2)}
                  disabled={!uploadedFile}
                  size="lg"
                  className="text-xl h-14 px-12 font-semibold"
                >
                  Continuar
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 2 && (
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-primary">Paso 2: Validar y Guardar</CardTitle>
            </CardHeader>
            <CardContent className="space-y-8">
              {/* File Summary */}
              <div className="bg-muted/50 p-6 rounded-lg border-2 border-border">
                <p className="text-lg font-semibold text-muted-foreground mb-2">Documento Seleccionado:</p>
                <p className="text-2xl font-bold text-primary">{uploadedFile?.name}</p>
              </div>

              {/* Legal Checkbox */}
              <div className="bg-accent/10 border-2 border-accent p-6 rounded-lg">
                <div className="flex items-start gap-4">
                  <Checkbox
                    id="legal-declaration"
                    checked={isChecked}
                    onCheckedChange={(checked) => setIsChecked(checked as boolean)}
                    className="mt-1 h-6 w-6"
                  />
                  <Label htmlFor="legal-declaration" className="text-lg leading-relaxed cursor-pointer">
                    <span className="font-bold text-primary">
                      Declaro bajo protesta de decir verdad que este documento es auténtico
                    </span>{" "}
                    y me hago responsable de su contenido conforme a la normativa universitaria vigente.
                  </Label>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-4 pt-4">
                <Button onClick={() => setStep(1)} variant="outline" size="lg" className="text-xl h-14 px-8 flex-1">
                  Atrás
                </Button>
                <Button
                  onClick={handleSave}
                  disabled={!isChecked}
                  size="lg"
                  className="text-xl h-14 px-12 flex-1 font-bold"
                >
                  GUARDAR DOCUMENTO
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  )
}
