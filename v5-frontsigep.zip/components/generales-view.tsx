"use client"

import { RubricEvaluationLayout } from "./rubrics/rubric-evaluation-layout"
import { generalesRubricData } from "@/lib/mock-data"

interface GeneralesViewProps {
  onNavigateNext?: () => void
}

export function GeneralesView({ onNavigateNext }: GeneralesViewProps) {
  // Simply use the master component with the generales data
  return <RubricEvaluationLayout rubricData={generalesRubricData} onNavigateNext={onNavigateNext} />
}
