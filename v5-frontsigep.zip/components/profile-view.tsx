"use client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { User, Users, Award, FileText, GraduationCap, Calendar, CheckCircle2, Star, Briefcase } from "lucide-react"

interface ProfileData {
  nombreCompleto: string
  rfc: string
  curp: string
  cuerpoAcademico: {
    nombre: string
    nivel: string
    constancia: string
  }
  sni: {
    nivel: string
    fechaInicio: string
    fechaFin: string
  }
  prodep: {
    perfil: string
    fechaInicio: string
    fechaFin: string
  }
  areaEstudios: {
    licenciatura: { titulo: string; institucion: string; año: string }[]
    maestria: { titulo: string; institucion: string; año: string }[]
    doctorado: { titulo: string; institucion: string; año: string }[]
  }
}

// Datos de ejemplo
const profileData: ProfileData = {
  nombreCompleto: "Dr. Juan Carlos Pérez García",
  rfc: "PEGJ750815ABC",
  curp: "PEGJ750815HOCRRC09",
  cuerpoAcademico: {
    nombre: "Sistemas Computacionales y Tecnologías de la Información",
    nivel: "Consolidado",
    constancia: "CA-UABJO-2023-045",
  },
  sni: {
    nivel: "Nivel I",
    fechaInicio: "01/01/2022",
    fechaFin: "31/12/2025",
  },
  prodep: {
    perfil: "Perfil Deseable",
    fechaInicio: "15/03/2023",
    fechaFin: "14/03/2026",
  },
  areaEstudios: {
    licenciatura: [
      {
        titulo: "Licenciatura en Ciencias de la Computación",
        institucion: "Universidad Autónoma Benito Juárez de Oaxaca",
        año: "1998",
      },
    ],
    maestria: [
      {
        titulo: "Maestría en Ciencias en Computación",
        institucion: "Centro de Investigación y de Estudios Avanzados del IPN",
        año: "2003",
      },
    ],
    doctorado: [
      {
        titulo: "Doctorado en Ciencias de la Computación",
        institucion: "Instituto Tecnológico y de Estudios Superiores de Monterrey",
        año: "2010",
      },
    ],
  },
}

function InfoRow({
  icon: Icon,
  label,
  value,
  iconColor = "text-[#0a1628]",
}: { icon: any; label: string; value: string; iconColor?: string }) {
  return (
    <div className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
      <div className={`p-2.5 rounded-lg bg-white shadow-sm ${iconColor}`}>
        <Icon className="h-5 w-5" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm text-gray-500 mb-0.5">{label}</p>
        <p className="font-semibold text-gray-800 break-words">{value}</p>
      </div>
    </div>
  )
}

function DateRangeCard({
  title,
  nivel,
  fechaInicio,
  fechaFin,
  icon: Icon,
  color,
  extra,
}: {
  title: string
  nivel: string
  fechaInicio: string
  fechaFin: string
  icon: any
  color: string
  extra?: string
}) {
  const isActive = new Date(fechaFin.split("/").reverse().join("-")) > new Date()

  return (
    <div className={`p-5 rounded-xl border-2 ${color} bg-white`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-lg ${color.replace("border-", "bg-").replace("-200", "-100")}`}>
            <Icon className={`h-5 w-5 ${color.replace("border-", "text-").replace("-200", "-600")}`} />
          </div>
          <div>
            <h4 className="font-semibold text-gray-800">{title}</h4>
            <p className="text-sm text-gray-500">{extra}</p>
          </div>
        </div>
        <Badge
          variant={isActive ? "default" : "secondary"}
          className={isActive ? "bg-emerald-500 hover:bg-emerald-600" : ""}
        >
          {isActive ? "Vigente" : "Expirado"}
        </Badge>
      </div>

      <div className="flex items-center justify-center gap-2 py-3 px-4 bg-gray-50 rounded-lg">
        <Star className={`h-5 w-5 ${color.replace("border-", "text-").replace("-200", "-500")}`} />
        <span className="font-bold text-lg text-gray-800">{nivel}</span>
      </div>

      <div className="grid grid-cols-2 gap-3 mt-4">
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <p className="text-xs text-gray-500 mb-1">Fecha Inicio</p>
          <p className="font-semibold text-gray-700 text-sm">{fechaInicio}</p>
        </div>
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <p className="text-xs text-gray-500 mb-1">Fecha Fin</p>
          <p className="font-semibold text-gray-700 text-sm">{fechaFin}</p>
        </div>
      </div>
    </div>
  )
}

function GradoCard({
  titulo,
  institucion,
  año,
  tipo,
}: {
  titulo: string
  institucion: string
  año: string
  tipo: "licenciatura" | "maestria" | "doctorado"
}) {
  const colors = {
    licenciatura: { bg: "bg-blue-50", border: "border-blue-200", icon: "text-blue-600" },
    maestria: { bg: "bg-amber-50", border: "border-amber-200", icon: "text-amber-600" },
    doctorado: { bg: "bg-emerald-50", border: "border-emerald-200", icon: "text-emerald-600" },
  }

  const tipoLabels = {
    licenciatura: "Licenciatura",
    maestria: "Maestría",
    doctorado: "Doctorado",
  }

  return (
    <div className={`p-4 rounded-xl border-2 ${colors[tipo].border} ${colors[tipo].bg}`}>
      <div className="flex items-start gap-3">
        <div className={`p-2 rounded-lg bg-white shadow-sm ${colors[tipo].icon}`}>
          <GraduationCap className="h-5 w-5" />
        </div>
        <div className="flex-1 min-w-0">
          <Badge variant="outline" className="mb-2 text-xs">
            {tipoLabels[tipo]}
          </Badge>
          <h4 className="font-semibold text-gray-800 text-sm mb-1">{titulo}</h4>
          <p className="text-xs text-gray-500 mb-2">{institucion}</p>
          <div className="flex items-center gap-1 text-xs text-gray-600">
            <Calendar className="h-3.5 w-3.5" />
            <span>Año: {año}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export function ProfileView() {
  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <div className="w-20 h-20 bg-gradient-to-br from-[#0a1628] to-[#1e3a5f] rounded-2xl flex items-center justify-center text-white text-3xl font-bold shadow-lg">
          {profileData.nombreCompleto
            .split(" ")
            .map((n) => n[0])
            .slice(0, 2)
            .join("")}
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-800">{profileData.nombreCompleto}</h1>
          <p className="text-gray-500">Profesor Investigador de Tiempo Completo</p>
          <div className="flex items-center gap-2 mt-2">
            <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">
              <CheckCircle2 className="h-3 w-3 mr-1" />
              SNI Nivel I
            </Badge>
            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
              <Award className="h-3 w-3 mr-1" />
              PRODEP
            </Badge>
          </div>
        </div>
      </div>

      {/* Datos Personales */}
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg flex items-center gap-2">
            <User className="h-5 w-5 text-[#0a1628]" />
            Datos Personales
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <InfoRow icon={User} label="Nombre Completo" value={profileData.nombreCompleto} />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <InfoRow icon={FileText} label="RFC" value={profileData.rfc} />
            <InfoRow icon={FileText} label="CURP" value={profileData.curp} />
          </div>
        </CardContent>
      </Card>

      {/* Cuerpo Académico */}
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg flex items-center gap-2">
            <Users className="h-5 w-5 text-[#0a1628]" />
            Cuerpo Académico
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-5 bg-gradient-to-r from-[#0a1628] to-[#1e3a5f] rounded-xl text-white">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-white/70 text-sm mb-1">Nombre del Cuerpo Académico</p>
                <h3 className="font-semibold text-lg mb-3">{profileData.cuerpoAcademico.nombre}</h3>
              </div>
              <Badge className="bg-amber-400 text-[#0a1628] hover:bg-amber-500">
                {profileData.cuerpoAcademico.nivel}
              </Badge>
            </div>
            <Separator className="bg-white/20 my-4" />
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-white/70" />
              <span className="text-sm text-white/70">Constancia:</span>
              <span className="text-sm font-medium">{profileData.cuerpoAcademico.constancia}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* SNI y PRODEP */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="border-0 shadow-md">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <Award className="h-5 w-5 text-emerald-600" />
              Sistema Nacional de Investigadores (SNI)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <DateRangeCard
              title="SNI"
              nivel={profileData.sni.nivel}
              fechaInicio={profileData.sni.fechaInicio}
              fechaFin={profileData.sni.fechaFin}
              icon={Award}
              color="border-emerald-200"
              extra="CONAHCYT"
            />
          </CardContent>
        </Card>

        <Card className="border-0 shadow-md">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <Briefcase className="h-5 w-5 text-blue-600" />
              PRODEP
            </CardTitle>
          </CardHeader>
          <CardContent>
            <DateRangeCard
              title="PRODEP"
              nivel={profileData.prodep.perfil}
              fechaInicio={profileData.prodep.fechaInicio}
              fechaFin={profileData.prodep.fechaFin}
              icon={Briefcase}
              color="border-blue-200"
              extra="SEP"
            />
          </CardContent>
        </Card>
      </div>

      {/* Área de Estudios */}
      <Card className="border-0 shadow-md">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg flex items-center gap-2">
            <GraduationCap className="h-5 w-5 text-[#0a1628]" />
            Área de Estudios (Grados Académicos)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Doctorado */}
            <div>
              <h4 className="text-sm font-semibold text-gray-600 mb-3 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                Doctorado
              </h4>
              <div className="space-y-3">
                {profileData.areaEstudios.doctorado.map((grado, idx) => (
                  <GradoCard key={idx} {...grado} tipo="doctorado" />
                ))}
              </div>
            </div>

            {/* Maestría */}
            <div>
              <h4 className="text-sm font-semibold text-gray-600 mb-3 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                Maestría
              </h4>
              <div className="space-y-3">
                {profileData.areaEstudios.maestria.map((grado, idx) => (
                  <GradoCard key={idx} {...grado} tipo="maestria" />
                ))}
              </div>
            </div>

            {/* Licenciatura */}
            <div>
              <h4 className="text-sm font-semibold text-gray-600 mb-3 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-500" />
                Licenciatura
              </h4>
              <div className="space-y-3">
                {profileData.areaEstudios.licenciatura.map((grado, idx) => (
                  <GradoCard key={idx} {...grado} tipo="licenciatura" />
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
