"use client"

import { useState } from "react"
import { ConvocatoriasList } from "@/components/SharedEvaluation/convocatorias-list"
import { ProfesoresDashboard } from "@/components/SharedEvaluation/profesores-dashboard"
import { FocusModeLayout } from "@/components/SharedEvaluation/focus-mode-layout"
import { ValidationPanel } from "@/components/SharedEvaluation/validation-panel"
import {
  convocatoriasEvaluadores,
  profesoresEvaluacion,
  type Convocatoria,
  type ProfesorEvaluacion,
} from "@/mocks/newRolesData"

interface EvFacMainProps {
  onLogout: () => void
}

export function EvFacMain({ onLogout }: EvFacMainProps) {
  const [currentView, setCurrentView] = useState<"convocatorias" | "dashboard" | "focus">("convocatorias")
  const [selectedConvocatoria, setSelectedConvocatoria] = useState<Convocatoria | null>(null)
  const [selectedProfesor, setSelectedProfesor] = useState<ProfesorEvaluacion | null>(null)

  const handleSelectConvocatoria = (convocatoria: Convocatoria) => {
    setSelectedConvocatoria(convocatoria)
    setCurrentView("dashboard")
  }

  const handleSelectProfesor = (profesor: ProfesorEvaluacion) => {
    setSelectedProfesor(profesor)
    setCurrentView("focus")
  }

  const handleBackToConvocatorias = () => {
    setSelectedConvocatoria(null)
    setCurrentView("convocatorias")
  }

  const handleBackToDashboard = () => {
    setSelectedProfesor(null)
    setCurrentView("dashboard")
  }

  // Convocatorias list
  if (currentView === "convocatorias") {
    return (
      <ConvocatoriasList
        convocatorias={convocatoriasEvaluadores}
        onSelect={handleSelectConvocatoria}
        onLogout={onLogout}
        userType="ev_fac"
        userName="Usuario Ev. Facultad"
      />
    )
  }

  // Dashboard with professors list
  if (currentView === "dashboard" && selectedConvocatoria) {
    return (
      <ProfesoresDashboard
        convocatoria={selectedConvocatoria}
        profesores={profesoresEvaluacion}
        onSelectProfesor={handleSelectProfesor}
        onBack={handleBackToConvocatorias}
        userType="ev_fac"
      />
    )
  }

  // Focus mode - validation
  if (currentView === "focus" && selectedProfesor) {
    return (
      <FocusModeLayout profesor={selectedProfesor} onBack={handleBackToDashboard} userType="ev_fac">
        {({ selectedRubroId, onNavigateNext, onNavigatePrev, hasNext, hasPrev, currentIndex, totalItems }) => (
          <ValidationPanel
            selectedRubroId={selectedRubroId}
            onNavigateNext={onNavigateNext}
            onNavigatePrev={onNavigatePrev}
            hasNext={hasNext}
            hasPrev={hasPrev}
            currentIndex={currentIndex}
            totalItems={totalItems}
          />
        )}
      </FocusModeLayout>
    )
  }

  return null
}
