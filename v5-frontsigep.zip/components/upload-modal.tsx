"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Upload, FileText, X } from "lucide-react"

interface UploadModalProps {
  isOpen: boolean
  onClose: () => void
  category: string
  onUpload: (file: File) => void
}

export function UploadModal({ isOpen, onClose, category, onUpload }: UploadModalProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const [acceptDeclaration, setAcceptDeclaration] = useState(false)

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const file = e.dataTransfer.files[0]
    if (file && file.type === "application/pdf") {
      setSelectedFile(file)
    }
  }, [])

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setSelectedFile(file)
    }
  }

  const handleSubmit = () => {
    if (selectedFile && acceptDeclaration) {
      onUpload(selectedFile)
      setSelectedFile(null)
      setAcceptDeclaration(false)
    }
  }

  const handleClose = () => {
    setSelectedFile(null)
    setAcceptDeclaration(false)
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl">Subir Nueva Evidencia - {category}</DialogTitle>
          <DialogDescription>Arrastre un archivo PDF o haga clic para seleccionar</DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Drag and Drop Area */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-lg p-12 text-center transition-colors ${
              isDragging ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
            }`}
          >
            {selectedFile ? (
              <div className="space-y-4">
                <div className="inline-flex items-center gap-3 px-4 py-3 bg-muted rounded-lg">
                  <FileText className="h-8 w-8 text-primary" />
                  <div className="text-left">
                    <p className="font-semibold">{selectedFile.name}</p>
                    <p className="text-sm text-muted-foreground">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => setSelectedFile(null)} className="ml-4">
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-sm text-muted-foreground">Archivo seleccionado correctamente</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10">
                  <Upload className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <p className="text-lg font-semibold mb-1">Arrastre su archivo PDF aquí</p>
                  <p className="text-muted-foreground mb-4">o</p>
                  <label htmlFor="file-upload">
                    <Button type="button" variant="outline" size="lg" asChild>
                      <span>Seleccionar Archivo</span>
                    </Button>
                  </label>
                  <input
                    id="file-upload"
                    type="file"
                    accept="application/pdf"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Legal Declaration */}
          <div className="bg-muted/50 p-4 rounded-lg space-y-3">
            <div className="flex items-start gap-3">
              <Checkbox
                id="declaration"
                checked={acceptDeclaration}
                onCheckedChange={(checked) => setAcceptDeclaration(checked as boolean)}
                className="mt-1"
              />
              <Label htmlFor="declaration" className="text-sm leading-relaxed cursor-pointer">
                Declaro bajo protesta de decir verdad que los documentos que estoy cargando son auténticos y
                corresponden a mi actividad académica. Estoy consciente de que cualquier falsificación o alteración de
                documentos puede resultar en sanciones conforme a la normatividad institucional.
              </Label>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-4">
            <Button variant="outline" onClick={handleClose} size="lg">
              Cancelar
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={!selectedFile || !acceptDeclaration}
              size="lg"
              className="min-w-[140px]"
            >
              <Upload className="mr-2 h-4 w-4" />
              Cargar Archivo
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
