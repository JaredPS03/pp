"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileText, Eye, CheckCircle2, XCircle, MessageSquare, Clock, User } from "lucide-react"

interface Evidence {
  id: string
  profesor: string
  profesorId: string
  categoria: "Docencia" | "Investigación" | "Tutorías" | "Gestión"
  documento: string
  fecha: string
  estado: "pendiente" | "aprobado" | "rechazado"
  comentarios?: string
}

const mockEvidences: Evidence[] = [
  {
    id: "1",
    profesor: "Dr. Juan Pérez García",
    profesorId: "P001",
    categoria: "Docencia",
    documento: "Programa_Matematicas_2024.pdf",
    fecha: "2024-01-20",
    estado: "pendiente",
  },
  {
    id: "2",
    profesor: "Dra. Ana López Torres",
    profesorId: "P002",
    categoria: "Investigación",
    documento: "Articulo_Publicado_Nature.pdf",
    fecha: "2024-01-20",
    estado: "pendiente",
  },
  {
    id: "3",
    profesor: "Dr. Carlos Ruiz Mendoza",
    profesorId: "P003",
    categoria: "Tutorías",
    documento: "Lista_Tutorados_2024.pdf",
    fecha: "2024-01-19",
    estado: "pendiente",
  },
  {
    id: "4",
    profesor: "Dra. Laura Sánchez Díaz",
    profesorId: "P004",
    categoria: "Gestión",
    documento: "Informe_Comision_Academica.pdf",
    fecha: "2024-01-19",
    estado: "aprobado",
  },
  {
    id: "5",
    profesor: "Dr. Miguel Ángel Torres",
    profesorId: "P005",
    categoria: "Docencia",
    documento: "Examen_Final_Calculo.pdf",
    fecha: "2024-01-18",
    estado: "rechazado",
    comentarios: "El documento no está firmado",
  },
  {
    id: "6",
    profesor: "Dr. Juan Pérez García",
    profesorId: "P001",
    categoria: "Investigación",
    documento: "Proyecto_Investigacion_2024.pdf",
    fecha: "2024-01-18",
    estado: "aprobado",
  },
  {
    id: "7",
    profesor: "Dra. Ana López Torres",
    profesorId: "P002",
    categoria: "Docencia",
    documento: "Lista_Asistencia_Semestre.pdf",
    fecha: "2024-01-17",
    estado: "pendiente",
  },
  {
    id: "8",
    profesor: "Dr. Juan Pérez García",
    profesorId: "P001",
    categoria: "Tutorías",
    documento: "Reporte_Tutorias_Enero.pdf",
    fecha: "2024-01-16",
    estado: "pendiente",
  },
]

export function AdminReviewView() {
  const [evidences, setEvidences] = useState<Evidence[]>(mockEvidences)
  const [selectedEvidence, setSelectedEvidence] = useState<Evidence | null>(null)
  const [isPreviewOpen, setIsPreviewOpen] = useState(false)
  const [reviewComment, setReviewComment] = useState("")
  const [activeTab, setActiveTab] = useState("pendiente")
  const [selectedProfesor, setSelectedProfesor] = useState<string>("todos")
  const [selectedCategoria, setSelectedCategoria] = useState<string>("todos")

  const uniqueProfesores = Array.from(new Set(evidences.map((ev) => ev.profesor))).sort()

  const filteredEvidences = evidences.filter((ev) => {
    const matchesStatus = activeTab === "todos" ? true : ev.estado === activeTab
    const matchesProfesor = selectedProfesor === "todos" ? true : ev.profesor === selectedProfesor
    const matchesCategoria = selectedCategoria === "todos" ? true : ev.categoria === selectedCategoria
    return matchesStatus && matchesProfesor && matchesCategoria
  })

  const evidencesByProfesor = filteredEvidences.reduce(
    (acc, ev) => {
      if (!acc[ev.profesor]) {
        acc[ev.profesor] = []
      }
      acc[ev.profesor].push(ev)
      return acc
    },
    {} as Record<string, Evidence[]>,
  )

  const handleApprove = () => {
    if (selectedEvidence) {
      setEvidences(
        evidences.map((ev) =>
          ev.id === selectedEvidence.id ? { ...ev, estado: "aprobado", comentarios: reviewComment } : ev,
        ),
      )
      setIsPreviewOpen(false)
      setReviewComment("")
      setSelectedEvidence(null)
    }
  }

  const handleReject = () => {
    if (selectedEvidence) {
      setEvidences(
        evidences.map((ev) =>
          ev.id === selectedEvidence.id ? { ...ev, estado: "rechazado", comentarios: reviewComment } : ev,
        ),
      )
      setIsPreviewOpen(false)
      setReviewComment("")
      setSelectedEvidence(null)
    }
  }

  const openPreview = (evidence: Evidence) => {
    setSelectedEvidence(evidence)
    setReviewComment(evidence.comentarios || "")
    setIsPreviewOpen(true)
  }

  const getStatusBadge = (estado: Evidence["estado"]) => {
    if (estado === "aprobado") {
      return (
        <Badge className="bg-[#10B981]/10 text-[#10B981] hover:bg-[#10B981]/20">
          <CheckCircle2 className="h-3 w-3 mr-1" />
          Aprobado
        </Badge>
      )
    }
    if (estado === "rechazado") {
      return (
        <Badge className="bg-red-500/10 text-red-500 hover:bg-red-500/20">
          <XCircle className="h-3 w-3 mr-1" />
          Rechazado
        </Badge>
      )
    }
    return (
      <Badge className="bg-[#FFC107]/10 text-[#FFC107] hover:bg-[#FFC107]/20">
        <Clock className="h-3 w-3 mr-1" />
        Pendiente
      </Badge>
    )
  }

  const getCategoryColor = (categoria: Evidence["categoria"]) => {
    const colors = {
      Docencia: "bg-blue-500/10 text-blue-500",
      Investigación: "bg-purple-500/10 text-purple-500",
      Tutorías: "bg-green-500/10 text-green-500",
      Gestión: "bg-orange-500/10 text-orange-500",
    }
    return colors[categoria]
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-primary mb-2">Revisión de Evidencias</h1>
        <p className="text-muted-foreground">Revisa, aprueba o rechaza las evidencias enviadas por los profesores</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold flex items-center gap-2">
                <User className="h-4 w-4" />
                Filtrar por Profesor
              </label>
              <Select value={selectedProfesor} onValueChange={setSelectedProfesor}>
                <SelectTrigger className="text-base">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todos los Profesores</SelectItem>
                  {uniqueProfesores.map((prof) => (
                    <SelectItem key={prof} value={prof}>
                      {prof}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold flex items-center gap-2">
                <FileText className="h-4 w-4" />
                Filtrar por Categoría
              </label>
              <Select value={selectedCategoria} onValueChange={setSelectedCategoria}>
                <SelectTrigger className="text-base">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="todos">Todas las Categorías</SelectItem>
                  <SelectItem value="Docencia">Docencia</SelectItem>
                  <SelectItem value="Investigación">Investigación</SelectItem>
                  <SelectItem value="Tutorías">Tutorías</SelectItem>
                  <SelectItem value="Gestión">Gestión</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs for filtering */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full max-w-md grid-cols-4">
          <TabsTrigger value="todos">Todos ({evidences.length})</TabsTrigger>
          <TabsTrigger value="pendiente">
            Pendientes ({evidences.filter((e) => e.estado === "pendiente").length})
          </TabsTrigger>
          <TabsTrigger value="aprobado">
            Aprobados ({evidences.filter((e) => e.estado === "aprobado").length})
          </TabsTrigger>
          <TabsTrigger value="rechazado">
            Rechazados ({evidences.filter((e) => e.estado === "rechazado").length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6 space-y-6">
          {Object.entries(evidencesByProfesor).map(([profesor, profesorEvidences]) => (
            <Card key={profesor}>
              <CardContent className="pt-6">
                <div className="mb-4 pb-3 border-b">
                  <h3 className="text-xl font-bold text-primary flex items-center gap-2">
                    <User className="h-5 w-5" />
                    {profesor}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {profesorEvidences.length} documento(s) • ID: {profesorEvidences[0].profesorId}
                  </p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b-2 border-border">
                        <th className="text-left py-4 px-4 font-semibold">Categoría</th>
                        <th className="text-left py-4 px-4 font-semibold">Documento</th>
                        <th className="text-left py-4 px-4 font-semibold">Fecha</th>
                        <th className="text-left py-4 px-4 font-semibold">Estado</th>
                        <th className="text-right py-4 px-4 font-semibold">Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {profesorEvidences.map((evidence) => (
                        <tr key={evidence.id} className="border-b last:border-0 hover:bg-muted/50">
                          <td className="py-4 px-4">
                            <Badge className={getCategoryColor(evidence.categoria)}>{evidence.categoria}</Badge>
                          </td>
                          <td className="py-4 px-4">
                            <div className="flex items-center gap-2">
                              <FileText className="h-4 w-4 text-red-500" />
                              <span className="font-medium">{evidence.documento}</span>
                            </div>
                          </td>
                          <td className="py-4 px-4 text-muted-foreground">{evidence.fecha}</td>
                          <td className="py-4 px-4">{getStatusBadge(evidence.estado)}</td>
                          <td className="py-4 px-4">
                            <div className="flex items-center justify-end gap-2">
                              <Button variant="outline" size="sm" onClick={() => openPreview(evidence)}>
                                <Eye className="h-4 w-4 mr-1" />
                                Revisar
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          ))}

          {filteredEvidences.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-lg text-muted-foreground">
                  No se encontraron evidencias con los filtros seleccionados
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Preview and Review Dialog */}
      <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">Revisión de Evidencia</DialogTitle>
          </DialogHeader>

          {selectedEvidence && (
            <div className="space-y-6">
              {/* Evidence Info */}
              <div className="grid grid-cols-2 gap-4 p-4 bg-muted rounded-lg">
                <div>
                  <p className="text-sm text-muted-foreground">Profesor</p>
                  <p className="font-semibold">{selectedEvidence.profesor}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Categoría</p>
                  <Badge className={getCategoryColor(selectedEvidence.categoria)}>{selectedEvidence.categoria}</Badge>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Documento</p>
                  <p className="font-semibold">{selectedEvidence.documento}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Fecha de envío</p>
                  <p className="font-semibold">{selectedEvidence.fecha}</p>
                </div>
              </div>

              {/* PDF Preview */}
              <div className="border rounded-lg p-4 bg-gray-100 min-h-[400px] flex items-center justify-center">
                <div className="text-center">
                  <FileText className="h-24 w-24 text-gray-400 mx-auto mb-4" />
                  <p className="text-lg font-semibold text-gray-600">Vista Previa del Documento</p>
                  <p className="text-sm text-gray-500 mt-2">{selectedEvidence.documento}</p>
                  <Button variant="outline" className="mt-4 bg-transparent">
                    <Eye className="h-4 w-4 mr-2" />
                    Abrir en nueva pestaña
                  </Button>
                </div>
              </div>

              {/* Comments/Feedback */}
              <div className="space-y-2">
                <label className="text-sm font-semibold flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Comentarios / Feedback
                </label>
                <Textarea
                  placeholder="Escribe tus comentarios aquí (opcional para aprobar, requerido para rechazar)..."
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  rows={4}
                  className="text-base"
                />
              </div>

              {/* Previous comments if any */}
              {selectedEvidence.comentarios && (
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-sm font-semibold text-yellow-800 mb-2">Comentario Anterior:</p>
                  <p className="text-sm text-yellow-900">{selectedEvidence.comentarios}</p>
                </div>
              )}
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setIsPreviewOpen(false)}>
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={handleReject}
              disabled={!reviewComment.trim()}
              className="bg-red-500 hover:bg-red-600"
            >
              <XCircle className="h-4 w-4 mr-2" />
              Rechazar
            </Button>
            <Button onClick={handleApprove} className="bg-[#10B981] hover:bg-[#059669]">
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Aprobar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
