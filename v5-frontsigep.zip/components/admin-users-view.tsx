"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { UserPlus, Mail, Lock, Shield, Edit, Trash2, Search, CheckCircle2 } from "lucide-react"
import { Checkbox } from "@/components/ui/checkbox"

interface User {
  id: string
  nombre: string
  email: string
  usuario: string
  tipo: "Profesor" | "Administrativo" | "Administrador" | "Revisor" | "Coordinador" | "Supervisor"
  estado: "activo" | "inactivo"
  permisos: {
    docencia: boolean
    investigacion: boolean
    tutoria: boolean
    gestion: boolean
  }
  permisosAdmin?: {
    gestionarUsuarios: boolean
    revisarDocumentos: boolean
    verReportes: boolean
    configurarSistema: boolean
  }
}

const mockUsers: User[] = [
  {
    id: "1",
    nombre: "Dr. Juan Pérez García",
    email: "juan.perez@uabjo.mx",
    usuario: "jperez",
    tipo: "Profesor",
    estado: "activo",
    permisos: { docencia: true, investigacion: true, tutoria: true, gestion: true },
  },
  {
    id: "2",
    nombre: "Dra. Ana López Torres",
    email: "ana.lopez@uabjo.mx",
    usuario: "alopez",
    tipo: "Profesor",
    estado: "activo",
    permisos: { docencia: true, investigacion: true, tutoria: false, gestion: false },
  },
  {
    id: "3",
    nombre: "Lic. Carlos Ruiz Mendoza",
    email: "carlos.ruiz@uabjo.mx",
    usuario: "cruiz",
    tipo: "Administrativo",
    estado: "activo",
    permisos: { docencia: false, investigacion: false, tutoria: false, gestion: true },
  },
  {
    id: "4",
    nombre: "Mtro. Roberto Sánchez Vega",
    email: "roberto.sanchez@uabjo.mx",
    usuario: "rsanchez",
    tipo: "Revisor",
    estado: "activo",
    permisos: { docencia: true, investigacion: true, tutoria: true, gestion: true },
    permisosAdmin: {
      gestionarUsuarios: false,
      revisarDocumentos: true,
      verReportes: true,
      configurarSistema: false,
    },
  },
  {
    id: "5",
    nombre: "Dra. Patricia Gómez Luna",
    email: "patricia.gomez@uabjo.mx",
    usuario: "pgomez",
    tipo: "Coordinador",
    estado: "activo",
    permisos: { docencia: true, investigacion: true, tutoria: true, gestion: true },
    permisosAdmin: {
      gestionarUsuarios: true,
      revisarDocumentos: true,
      verReportes: true,
      configurarSistema: false,
    },
  },
]

export function AdminUsersView() {
  const [users, setUsers] = useState<User[]>(mockUsers)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [searchTerm, setSearchTerm] = useState("")
  const [emailSent, setEmailSent] = useState(false)

  const [newUser, setNewUser] = useState({
    nombre: "",
    email: "",
    usuario: "",
    password: "",
    tipo: "Profesor" as User["tipo"],
    permisos: { docencia: true, investigacion: true, tutoria: true, gestion: true },
    permisosAdmin: {
      gestionarUsuarios: false,
      revisarDocumentos: false,
      verReportes: false,
      configurarSistema: false,
    },
  })

  const requiresAdminPermissions = (tipo: User["tipo"]) => {
    return ["Administrador", "Revisor", "Coordinador", "Supervisor"].includes(tipo)
  }

  const handleCreateUser = () => {
    const user: User = {
      id: String(users.length + 1),
      nombre: newUser.nombre,
      email: newUser.email,
      usuario: newUser.usuario,
      tipo: newUser.tipo,
      estado: "activo",
      permisos: newUser.permisos,
      ...(requiresAdminPermissions(newUser.tipo) && { permisosAdmin: newUser.permisosAdmin }),
    }
    setUsers([...users, user])
    setEmailSent(true)
    setTimeout(() => {
      setEmailSent(false)
      setIsCreateDialogOpen(false)
      setNewUser({
        nombre: "",
        email: "",
        usuario: "",
        password: "",
        tipo: "Profesor",
        permisos: { docencia: true, investigacion: true, tutoria: true, gestion: true },
        permisosAdmin: {
          gestionarUsuarios: false,
          revisarDocumentos: false,
          verReportes: false,
          configurarSistema: false,
        },
      })
    }, 2000)
  }

  const handleEditUser = () => {
    if (selectedUser) {
      setUsers(users.map((u) => (u.id === selectedUser.id ? selectedUser : u)))
      setIsEditDialogOpen(false)
      setSelectedUser(null)
    }
  }

  const handleDeleteUser = (id: string) => {
    if (confirm("¿Está seguro de eliminar este usuario?")) {
      setUsers(users.filter((u) => u.id !== id))
    }
  }

  const openEditDialog = (user: User) => {
    setSelectedUser({ ...user })
    setIsEditDialogOpen(true)
  }

  const filteredUsers = users.filter(
    (user) =>
      user.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.usuario.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getTipoBadge = (tipo: User["tipo"]) => {
    const colors = {
      Profesor: "bg-blue-500/10 text-blue-500",
      Administrativo: "bg-green-500/10 text-green-500",
      Administrador: "bg-purple-500/10 text-purple-500",
      Revisor: "bg-orange-500/10 text-orange-500",
      Coordinador: "bg-pink-500/10 text-pink-500",
      Supervisor: "bg-teal-500/10 text-teal-500",
    }
    return <Badge className={colors[tipo]}>{tipo}</Badge>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-primary mb-2">Gestión de Usuarios</h1>
          <p className="text-muted-foreground">Crea y administra usuarios del sistema SIGEP</p>
        </div>
        <Button onClick={() => setIsCreateDialogOpen(true)} size="lg" className="h-12 text-base">
          <UserPlus className="mr-2 h-5 w-5" />
          Crear Nuevo Usuario
        </Button>
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-2">
            <Search className="h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Buscar por nombre, email o usuario..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="text-base"
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">Usuarios Registrados ({filteredUsers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-border">
                  <th className="text-left py-4 px-4 font-semibold">Nombre</th>
                  <th className="text-left py-4 px-4 font-semibold">Email</th>
                  <th className="text-left py-4 px-4 font-semibold">Usuario</th>
                  <th className="text-left py-4 px-4 font-semibold">Tipo</th>
                  <th className="text-left py-4 px-4 font-semibold">Estado</th>
                  <th className="text-right py-4 px-4 font-semibold">Acciones</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.map((user) => (
                  <tr key={user.id} className="border-b last:border-0 hover:bg-muted/50">
                    <td className="py-4 px-4 font-medium">{user.nombre}</td>
                    <td className="py-4 px-4 text-muted-foreground">{user.email}</td>
                    <td className="py-4 px-4">
                      <code className="bg-muted px-2 py-1 rounded text-sm">{user.usuario}</code>
                    </td>
                    <td className="py-4 px-4">{getTipoBadge(user.tipo)}</td>
                    <td className="py-4 px-4">
                      <Badge className="bg-[#10B981]/10 text-[#10B981]">Activo</Badge>
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="outline" size="sm" onClick={() => openEditDialog(user)}>
                          <Edit className="h-4 w-4 mr-1" />
                          Editar
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteUser(user.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">Crear Nuevo Usuario</DialogTitle>
            <DialogDescription>Complete la información para crear una nueva cuenta de usuario</DialogDescription>
          </DialogHeader>

          {emailSent ? (
            <div className="py-12 text-center">
              <CheckCircle2 className="h-16 w-16 text-[#10B981] mx-auto mb-4" />
              <h3 className="text-xl font-bold text-[#10B981] mb-2">Usuario Creado Exitosamente</h3>
              <p className="text-muted-foreground">
                Se ha enviado un correo a <strong>{newUser.email}</strong> con las credenciales de acceso.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2 col-span-2">
                  <Label htmlFor="nombre" className="text-base font-semibold">
                    Nombre Completo
                  </Label>
                  <Input
                    id="nombre"
                    placeholder="Dr. Juan Pérez García"
                    value={newUser.nombre}
                    onChange={(e) => setNewUser({ ...newUser, nombre: e.target.value })}
                    className="text-base"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email" className="text-base font-semibold">
                    <Mail className="h-4 w-4 inline mr-1" />
                    Correo Electrónico
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="juan.perez@uabjo.mx"
                    value={newUser.email}
                    onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                    className="text-base"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tipo" className="text-base font-semibold">
                    <Shield className="h-4 w-4 inline mr-1" />
                    Tipo de Usuario
                  </Label>
                  <Select
                    value={newUser.tipo}
                    onValueChange={(value: User["tipo"]) => setNewUser({ ...newUser, tipo: value })}
                  >
                    <SelectTrigger className="text-base">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Profesor">Profesor</SelectItem>
                      <SelectItem value="Administrativo">Administrativo</SelectItem>
                      <SelectItem value="Administrador">Administrador</SelectItem>
                      <SelectItem value="Revisor">Revisor</SelectItem>
                      <SelectItem value="Coordinador">Coordinador</SelectItem>
                      <SelectItem value="Supervisor">Supervisor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="usuario" className="text-base font-semibold">
                    Usuario
                  </Label>
                  <Input
                    id="usuario"
                    placeholder="jperez"
                    value={newUser.usuario}
                    onChange={(e) => setNewUser({ ...newUser, usuario: e.target.value })}
                    className="text-base"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password" className="text-base font-semibold">
                    <Lock className="h-4 w-4 inline mr-1" />
                    Contraseña Temporal
                  </Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={newUser.password}
                    onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                    className="text-base"
                  />
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-base font-semibold">Permisos de Acceso a Categorías</Label>
                <div className="grid grid-cols-2 gap-3">
                  {(["docencia", "investigacion", "tutoria", "gestion"] as const).map((permiso) => (
                    <div key={permiso} className="flex items-center space-x-2 p-3 border rounded-lg">
                      <Checkbox
                        id={permiso}
                        checked={newUser.permisos[permiso]}
                        onCheckedChange={(checked) =>
                          setNewUser({
                            ...newUser,
                            permisos: { ...newUser.permisos, [permiso]: checked },
                          })
                        }
                      />
                      <label htmlFor={permiso} className="text-base font-medium capitalize cursor-pointer">
                        {permiso}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {requiresAdminPermissions(newUser.tipo) && (
                <div className="space-y-3 p-4 bg-purple-50 border border-purple-200 rounded-lg">
                  <Label className="text-base font-semibold text-purple-900">Permisos Administrativos</Label>
                  <p className="text-sm text-purple-700 mb-3">
                    Este tipo de usuario puede acceder a funciones de gestión del sistema
                  </p>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex items-center space-x-2 p-3 bg-white border rounded-lg">
                      <Checkbox
                        id="gestionarUsuarios"
                        checked={newUser.permisosAdmin.gestionarUsuarios}
                        onCheckedChange={(checked) =>
                          setNewUser({
                            ...newUser,
                            permisosAdmin: { ...newUser.permisosAdmin, gestionarUsuarios: !!checked },
                          })
                        }
                      />
                      <label htmlFor="gestionarUsuarios" className="text-sm font-medium cursor-pointer">
                        Gestionar Usuarios
                      </label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 bg-white border rounded-lg">
                      <Checkbox
                        id="revisarDocumentos"
                        checked={newUser.permisosAdmin.revisarDocumentos}
                        onCheckedChange={(checked) =>
                          setNewUser({
                            ...newUser,
                            permisosAdmin: { ...newUser.permisosAdmin, revisarDocumentos: !!checked },
                          })
                        }
                      />
                      <label htmlFor="revisarDocumentos" className="text-sm font-medium cursor-pointer">
                        Revisar Documentos
                      </label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 bg-white border rounded-lg">
                      <Checkbox
                        id="verReportes"
                        checked={newUser.permisosAdmin.verReportes}
                        onCheckedChange={(checked) =>
                          setNewUser({
                            ...newUser,
                            permisosAdmin: { ...newUser.permisosAdmin, verReportes: !!checked },
                          })
                        }
                      />
                      <label htmlFor="verReportes" className="text-sm font-medium cursor-pointer">
                        Ver Reportes
                      </label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 bg-white border rounded-lg">
                      <Checkbox
                        id="configurarSistema"
                        checked={newUser.permisosAdmin.configurarSistema}
                        onCheckedChange={(checked) =>
                          setNewUser({
                            ...newUser,
                            permisosAdmin: { ...newUser.permisosAdmin, configurarSistema: !!checked },
                          })
                        }
                      />
                      <label htmlFor="configurarSistema" className="text-sm font-medium cursor-pointer">
                        Configurar Sistema
                      </label>
                    </div>
                  </div>
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>Nota:</strong> Se enviará un correo automático a{" "}
                  {newUser.email || "la dirección especificada"} con las credenciales de acceso y un enlace para iniciar
                  sesión en el sistema.
                </p>
              </div>
            </div>
          )}

          {!emailSent && (
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Cancelar
              </Button>
              <Button
                onClick={handleCreateUser}
                disabled={!newUser.nombre || !newUser.email || !newUser.usuario || !newUser.password}
              >
                <UserPlus className="h-4 w-4 mr-2" />
                Crear Usuario y Enviar Correo
              </Button>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">Editar Usuario</DialogTitle>
          </DialogHeader>

          {selectedUser && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2 col-span-2">
                  <Label className="text-base font-semibold">Nombre Completo</Label>
                  <Input
                    value={selectedUser.nombre}
                    onChange={(e) => setSelectedUser({ ...selectedUser, nombre: e.target.value })}
                    className="text-base"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-base font-semibold">Correo Electrónico</Label>
                  <Input
                    type="email"
                    value={selectedUser.email}
                    onChange={(e) => setSelectedUser({ ...selectedUser, email: e.target.value })}
                    className="text-base"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-base font-semibold">Tipo de Usuario</Label>
                  <Select
                    value={selectedUser.tipo}
                    onValueChange={(value: User["tipo"]) => setSelectedUser({ ...selectedUser, tipo: value })}
                  >
                    <SelectTrigger className="text-base">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Profesor">Profesor</SelectItem>
                      <SelectItem value="Administrativo">Administrativo</SelectItem>
                      <SelectItem value="Administrador">Administrador</SelectItem>
                      <SelectItem value="Revisor">Revisor</SelectItem>
                      <SelectItem value="Coordinador">Coordinador</SelectItem>
                      <SelectItem value="Supervisor">Supervisor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-base font-semibold">Permisos de Acceso a Categorías</Label>
                <div className="grid grid-cols-2 gap-3">
                  {(["docencia", "investigacion", "tutoria", "gestion"] as const).map((permiso) => (
                    <div key={permiso} className="flex items-center space-x-2 p-3 border rounded-lg">
                      <Checkbox
                        id={`edit-${permiso}`}
                        checked={selectedUser.permisos[permiso]}
                        onCheckedChange={(checked) =>
                          setSelectedUser({
                            ...selectedUser,
                            permisos: { ...selectedUser.permisos, [permiso]: checked },
                          })
                        }
                      />
                      <label htmlFor={`edit-${permiso}`} className="text-base font-medium capitalize cursor-pointer">
                        {permiso}
                      </label>
                    </div>
                  ))}
                </div>
              </div>

              {requiresAdminPermissions(selectedUser.tipo) && selectedUser.permisosAdmin && (
                <div className="space-y-3 p-4 bg-purple-50 border border-purple-200 rounded-lg">
                  <Label className="text-base font-semibold text-purple-900">Permisos Administrativos</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="flex items-center space-x-2 p-3 bg-white border rounded-lg">
                      <Checkbox
                        id="edit-gestionarUsuarios"
                        checked={selectedUser.permisosAdmin.gestionarUsuarios}
                        onCheckedChange={(checked) =>
                          setSelectedUser({
                            ...selectedUser,
                            permisosAdmin: { ...selectedUser.permisosAdmin!, gestionarUsuarios: !!checked },
                          })
                        }
                      />
                      <label htmlFor="edit-gestionarUsuarios" className="text-sm font-medium cursor-pointer">
                        Gestionar Usuarios
                      </label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 bg-white border rounded-lg">
                      <Checkbox
                        id="edit-revisarDocumentos"
                        checked={selectedUser.permisosAdmin.revisarDocumentos}
                        onCheckedChange={(checked) =>
                          setSelectedUser({
                            ...selectedUser,
                            permisosAdmin: { ...selectedUser.permisosAdmin!, revisarDocumentos: !!checked },
                          })
                        }
                      />
                      <label htmlFor="edit-revisarDocumentos" className="text-sm font-medium cursor-pointer">
                        Revisar Documentos
                      </label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 bg-white border rounded-lg">
                      <Checkbox
                        id="edit-verReportes"
                        checked={selectedUser.permisosAdmin.verReportes}
                        onCheckedChange={(checked) =>
                          setSelectedUser({
                            ...selectedUser,
                            permisosAdmin: { ...selectedUser.permisosAdmin!, verReportes: !!checked },
                          })
                        }
                      />
                      <label htmlFor="edit-verReportes" className="text-sm font-medium cursor-pointer">
                        Ver Reportes
                      </label>
                    </div>
                    <div className="flex items-center space-x-2 p-3 bg-white border rounded-lg">
                      <Checkbox
                        id="edit-configurarSistema"
                        checked={selectedUser.permisosAdmin.configurarSistema}
                        onCheckedChange={(checked) =>
                          setSelectedUser({
                            ...selectedUser,
                            permisosAdmin: { ...selectedUser.permisosAdmin!, configurarSistema: !!checked },
                          })
                        }
                      />
                      <label htmlFor="edit-configurarSistema" className="text-sm font-medium cursor-pointer">
                        Configurar Sistema
                      </label>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleEditUser}>Guardar Cambios</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
