"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  FileText,
  User,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ChevronRight,
  ChevronLeft,
  Clock,
  Calculator,
  MessageSquare,
  ZoomIn,
  ZoomOut,
  Download,
} from "lucide-react"

interface Expediente {
  id: string
  profesor: string
  profesorId: string
  categoria: "Docencia" | "Investigación" | "Tutorías" | "Gestión"
  subcategoria: string
  documentos: {
    id: string
    nombre: string
    estado: "pendiente" | "aprobado" | "subsanar" | "rechazado"
  }[]
  puntosAsignados?: number
  puntosMaximos: number
}

interface EvaluadorDashboardProps {
  onNavigate: (view: string) => void
  showReview?: boolean
}

const mockExpedientes: Expediente[] = [
  {
    id: "1",
    profesor: "Dr. Juan Pérez García",
    profesorId: "P001",
    categoria: "Docencia",
    subcategoria: "1.1 Carga Académica",
    documentos: [
      { id: "d1", nombre: "Nombramiento_2024.pdf", estado: "pendiente" },
      { id: "d2", nombre: "Tira_Materias_SemA.pdf", estado: "pendiente" },
    ],
    puntosMaximos: 20,
  },
  {
    id: "2",
    profesor: "Dr. Juan Pérez García",
    profesorId: "P001",
    categoria: "Investigación",
    subcategoria: "2.1 Artículos Indizados",
    documentos: [
      { id: "d3", nombre: "Articulo_Revista_Q1.pdf", estado: "pendiente" },
      { id: "d4", nombre: "Constancia_Publicacion.pdf", estado: "pendiente" },
    ],
    puntosMaximos: 25,
  },
  {
    id: "3",
    profesor: "Dra. Ana López Torres",
    profesorId: "P002",
    categoria: "Docencia",
    subcategoria: "1.2 Planeación Didáctica",
    documentos: [{ id: "d5", nombre: "Programa_Estudios_2024.pdf", estado: "pendiente" }],
    puntosMaximos: 15,
  },
]

const motivosRechazo = [
  "Documento ilegible",
  "Fecha fuera del periodo de evaluación",
  "Falta firma institucional",
  "No corresponde al rubro indicado",
  "Documento incompleto",
  "Formato no válido",
]

export function EvaluadorDashboard({ onNavigate, showReview = false }: EvaluadorDashboardProps) {
  const [expedientes, setExpedientes] = useState<Expediente[]>(mockExpedientes)
  const [currentIndex, setCurrentIndex] = useState(0)
  const [currentDocIndex, setCurrentDocIndex] = useState(0)
  const [puntosAsignados, setPuntosAsignados] = useState("")
  const [motivoRechazo, setMotivoRechazo] = useState("")
  const [observaciones, setObservaciones] = useState("")
  const [zoom, setZoom] = useState(100)

  const currentExpediente = expedientes[currentIndex]
  const currentDoc = currentExpediente?.documentos[currentDocIndex]
  const totalExpedientes = expedientes.length
  const expedientesRevisados = expedientes.filter((e) => e.documentos.every((d) => d.estado !== "pendiente")).length

  const handleApprove = () => {
    if (!currentExpediente || !currentDoc) return

    const updatedExpedientes = [...expedientes]
    updatedExpedientes[currentIndex].documentos[currentDocIndex].estado = "aprobado"

    if (puntosAsignados) {
      updatedExpedientes[currentIndex].puntosAsignados = Number.parseInt(puntosAsignados)
    }

    setExpedientes(updatedExpedientes)
    goToNextDocument()
  }

  const handleSubsanar = () => {
    if (!currentExpediente || !currentDoc) return

    const updatedExpedientes = [...expedientes]
    updatedExpedientes[currentIndex].documentos[currentDocIndex].estado = "subsanar"
    setExpedientes(updatedExpedientes)
    goToNextDocument()
  }

  const handleReject = () => {
    if (!currentExpediente || !currentDoc || !motivoRechazo) return

    const updatedExpedientes = [...expedientes]
    updatedExpedientes[currentIndex].documentos[currentDocIndex].estado = "rechazado"
    setExpedientes(updatedExpedientes)
    goToNextDocument()
  }

  const goToNextDocument = () => {
    setPuntosAsignados("")
    setMotivoRechazo("")
    setObservaciones("")

    if (currentDocIndex < currentExpediente.documentos.length - 1) {
      setCurrentDocIndex(currentDocIndex + 1)
    } else if (currentIndex < expedientes.length - 1) {
      setCurrentIndex(currentIndex + 1)
      setCurrentDocIndex(0)
    }
  }

  const goToPreviousDocument = () => {
    if (currentDocIndex > 0) {
      setCurrentDocIndex(currentDocIndex - 1)
    } else if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1)
      setCurrentDocIndex(expedientes[currentIndex - 1].documentos.length - 1)
    }
  }

  // Dashboard view (not review mode)
  if (!showReview) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-[#002060] mb-2">Panel de Evaluación</h1>
          <p className="text-muted-foreground text-base lg:text-lg">
            Gestione y evalúe los expedientes de los profesores
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="bg-[#FFC107]/10 p-3 rounded-lg">
                  <Clock className="h-6 w-6 text-[#FFC107]" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-[#002060]">{totalExpedientes - expedientesRevisados}</p>
                  <p className="text-sm text-muted-foreground">Pendientes de revisión</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="bg-[#10B981]/10 p-3 rounded-lg">
                  <CheckCircle2 className="h-6 w-6 text-[#10B981]" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-[#002060]">{expedientesRevisados}</p>
                  <p className="text-sm text-muted-foreground">Revisados hoy</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="bg-[#002060]/10 p-3 rounded-lg">
                  <User className="h-6 w-6 text-[#002060]" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-[#002060]">
                    {new Set(expedientes.map((e) => e.profesorId)).size}
                  </p>
                  <p className="text-sm text-muted-foreground">Profesores asignados</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Action */}
        <Card className="bg-gradient-to-br from-[#002060] to-[#003399] text-white">
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold mb-2">Iniciar Evaluación</h3>
                <p className="text-white/80">
                  Hay {totalExpedientes - expedientesRevisados} expedientes pendientes de revisión
                </p>
              </div>
              <Button
                onClick={() => onNavigate("evaluador-review")}
                size="lg"
                className="bg-[#FFC107] text-[#002060] hover:bg-[#FFD54F]"
              >
                Comenzar Revisión
                <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Pending List */}
        <Card>
          <CardHeader>
            <CardTitle>Expedientes Pendientes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {expedientes.map((exp, index) => (
                <div
                  key={exp.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 cursor-pointer"
                  onClick={() => {
                    setCurrentIndex(index)
                    setCurrentDocIndex(0)
                    onNavigate("evaluador-review")
                  }}
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-full bg-[#002060]/10 flex items-center justify-center">
                      <User className="h-5 w-5 text-[#002060]" />
                    </div>
                    <div>
                      <p className="font-semibold">{exp.profesor}</p>
                      <p className="text-sm text-muted-foreground">
                        {exp.categoria} - {exp.subcategoria}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge className="bg-[#FFC107]/10 text-[#FFC107]">
                      {exp.documentos.filter((d) => d.estado === "pendiente").length} pendientes
                    </Badge>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Split-view review mode
  return (
    <div className="h-[calc(100vh-140px)] flex flex-col lg:flex-row gap-4">
      {/* Left Panel - Document Viewer (60%) */}
      <div className="lg:w-[60%] flex flex-col bg-white rounded-lg shadow overflow-hidden">
        {/* Document Tabs */}
        <div className="border-b bg-gray-50 px-4 py-2">
          <Tabs value={currentDoc?.id} className="w-full">
            <TabsList className="bg-transparent gap-1">
              {currentExpediente?.documentos.map((doc, idx) => (
                <TabsTrigger
                  key={doc.id}
                  value={doc.id}
                  onClick={() => setCurrentDocIndex(idx)}
                  className={`data-[state=active]:bg-[#002060] data-[state=active]:text-white ${
                    doc.estado === "aprobado"
                      ? "border-l-2 border-l-[#10B981]"
                      : doc.estado === "rechazado"
                        ? "border-l-2 border-l-red-500"
                        : doc.estado === "subsanar"
                          ? "border-l-2 border-l-[#FFC107]"
                          : ""
                  }`}
                >
                  Archivo {idx + 1}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>
        </div>

        {/* Zoom Controls */}
        <div className="flex items-center justify-between px-4 py-2 border-b bg-gray-50">
          <p className="text-sm font-medium text-muted-foreground truncate max-w-[50%]">{currentDoc?.nombre}</p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setZoom(Math.max(50, zoom - 10))}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <span className="text-sm w-12 text-center">{zoom}%</span>
            <Button variant="outline" size="sm" onClick={() => setZoom(Math.min(200, zoom + 10))}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* PDF Viewer Area */}
        <div className="flex-1 bg-gray-200 flex items-center justify-center overflow-auto p-4">
          <div
            className="bg-white shadow-lg flex items-center justify-center"
            style={{
              width: `${(595 * zoom) / 100}px`,
              height: `${(842 * zoom) / 100}px`,
            }}
          >
            <div className="text-center p-8">
              <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <p className="text-lg font-semibold text-gray-600">Vista Previa del Documento</p>
              <p className="text-sm text-gray-500 mt-2">{currentDoc?.nombre}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - Evaluation Controls (40%) */}
      <div className="lg:w-[40%] flex flex-col bg-white rounded-lg shadow overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b bg-[#002060] text-white">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-[#FFC107] flex items-center justify-center">
              <User className="h-5 w-5 text-[#002060]" />
            </div>
            <div>
              <p className="font-semibold">{currentExpediente?.profesor}</p>
              <p className="text-sm text-white/80">
                {currentExpediente?.categoria} - {currentExpediente?.subcategoria}
              </p>
            </div>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span>
              Expediente {currentIndex + 1} de {totalExpedientes}
            </span>
            <span>
              Doc. {currentDocIndex + 1} de {currentExpediente?.documentos.length}
            </span>
          </div>
          <Progress value={(currentIndex * 100) / totalExpedientes} className="mt-2 h-2 bg-white/20" />
        </div>

        {/* Evaluation Form */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6">
          {/* Scoring Calculator */}
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-sm font-semibold text-[#002060]">
              <Calculator className="h-4 w-4" />
              Puntos Asignados
            </label>
            <div className="flex items-center gap-3">
              <Input
                type="number"
                min="0"
                max={currentExpediente?.puntosMaximos}
                value={puntosAsignados}
                onChange={(e) => setPuntosAsignados(e.target.value)}
                placeholder="0"
                className="text-lg font-bold text-center w-24"
              />
              <span className="text-muted-foreground">
                de máximo <strong>{currentExpediente?.puntosMaximos}</strong> pts
              </span>
            </div>
            <p className="text-xs text-muted-foreground">
              Sugerido: Máx {currentExpediente?.puntosMaximos} pts para este rubro
            </p>
          </div>

          {/* Validation Actions */}
          <div className="space-y-3">
            <p className="text-sm font-semibold text-[#002060]">Acción de Validación</p>
            <div className="grid grid-cols-3 gap-2">
              <Button onClick={handleApprove} className="bg-[#10B981] hover:bg-[#059669] text-white h-14 text-base">
                <CheckCircle2 className="mr-2 h-5 w-5" />
                APROBAR
              </Button>
              <Button
                onClick={handleSubsanar}
                className="bg-[#FFC107] hover:bg-[#FFB300] text-[#002060] h-14 text-base"
              >
                <AlertTriangle className="mr-2 h-5 w-5" />
                SUBSANAR
              </Button>
              <Button
                onClick={handleReject}
                disabled={!motivoRechazo}
                className="bg-red-500 hover:bg-red-600 text-white h-14 text-base"
              >
                <XCircle className="mr-2 h-5 w-5" />
                RECHAZAR
              </Button>
            </div>
          </div>

          {/* Smart Feedback */}
          <div className="space-y-3">
            <label className="flex items-center gap-2 text-sm font-semibold text-[#002060]">
              <MessageSquare className="h-4 w-4" />
              Motivo de Observación
            </label>
            <Select value={motivoRechazo} onValueChange={setMotivoRechazo}>
              <SelectTrigger className="text-base">
                <SelectValue placeholder="Seleccione un motivo (requerido para rechazar)" />
              </SelectTrigger>
              <SelectContent>
                {motivosRechazo.map((motivo) => (
                  <SelectItem key={motivo} value={motivo}>
                    {motivo}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-3">
            <label className="text-sm font-semibold text-[#002060]">Observaciones Adicionales</label>
            <Textarea
              value={observaciones}
              onChange={(e) => setObservaciones(e.target.value)}
              placeholder="Escriba comentarios adicionales para el profesor..."
              rows={4}
              className="text-base"
            />
          </div>
        </div>

        {/* Navigation Footer */}
        <div className="p-4 border-t bg-gray-50">
          <div className="flex items-center justify-between gap-3">
            <Button
              variant="outline"
              onClick={goToPreviousDocument}
              disabled={currentIndex === 0 && currentDocIndex === 0}
            >
              <ChevronLeft className="mr-2 h-4 w-4" />
              Anterior
            </Button>
            <Button onClick={goToNextDocument} className="bg-[#002060] hover:bg-[#003399]">
              Guardar y Siguiente
              <ChevronRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
