"use client"

import React from "react"

import type { ReactNode } from "react"
import {
  LayoutDashboard,
  UserCircle,
  BookOpen,
  Users,
  ChevronRight,
  Bell,
  Building2,
  FileClock,
  Microscope,
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarProvider,
  SidebarTrigger,
  SidebarGroup,
  SidebarGroupLabel,
} from "@/components/ui/sidebar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Collapsible, CollapsibleTrigger, CollapsibleContent } from "@/components/ui/collapsible"

export function DashboardLayout({ children }: { children: ReactNode }) {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-[#f3f4f6]">
        <AppSidebar />
        <main className="flex-1 flex flex-col">
          <header className="h-16 border-b bg-white flex items-center justify-between px-6 sticky top-0 z-10">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="lg:hidden" />
              <div className="flex flex-col">
                <h1 className="text-sm font-semibold text-primary">Bienvenido, Dr. Juan Pérez</h1>
                <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">PTC Titular C</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <Badge
                variant="outline"
                className="border-secondary text-secondary-foreground bg-secondary/10 hidden md:flex animate-pulse"
              >
                Convocatoria 2025: ABIERTA (Cierra en 15 días)
              </Badge>
              <div className="flex items-center gap-2">
                <Button variant="ghost" size="icon" className="text-muted-foreground">
                  <Bell className="h-5 w-5" />
                </Button>
                <Avatar className="h-9 w-9 border-2 border-secondary/20">
                  <AvatarImage src="/diverse-professor-lecturing.png" />
                  <AvatarFallback className="bg-primary text-primary-foreground">JP</AvatarFallback>
                </Avatar>
              </div>
            </div>
          </header>

          <div className="p-6">{children}</div>
        </main>
      </div>
    </SidebarProvider>
  )
}

export default DashboardLayout

function AppSidebar() {
  const [openSections, setOpenSections] = React.useState({
    docencia: true,
    investigacion: false,
    tutorias: false,
    gestion: false,
  })

  const toggleSection = (section: string) => {
    setOpenSections((prev) => ({
      ...prev,
      [section]: !prev[section],
    }))
  }

  return (
    <Sidebar collapsible="icon" className="border-r-0">
      <SidebarHeader className="h-16 flex items-center px-6 border-b border-sidebar-border bg-sidebar">
        <div className="flex items-center gap-3">
          <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-sidebar-primary text-sidebar-primary-foreground font-bold text-xl">
            S
          </div>
          <div className="flex flex-col gap-0.5 leading-none group-data-[collapsible=icon]:hidden">
            <span className="font-bold text-lg tracking-tight text-white">SIGEP</span>
            <span className="text-[10px] text-sidebar-primary font-semibold uppercase tracking-widest">UABJO</span>
          </div>
        </div>
      </SidebarHeader>

      <SidebarContent className="bg-sidebar">
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground/40 font-bold uppercase tracking-widest text-[10px] px-6 py-4">
            Navegación
          </SidebarGroupLabel>
          <SidebarMenu className="px-3 space-y-1">
            {/* INICIO */}
            <SidebarMenuItem>
              <SidebarMenuButton
                tooltip="Inicio / Semáforo"
                isActive
                className="bg-sidebar-accent text-sidebar-accent-foreground"
              >
                <LayoutDashboard className="h-5 w-5" />
                <span className="font-medium">Inicio / Semáforo</span>
              </SidebarMenuButton>
            </SidebarMenuItem>

            {/* MIS DATOS */}
            <SidebarMenuItem>
              <SidebarMenuButton tooltip="Mis Datos" asChild>
                <a href="/profile">
                  <UserCircle className="h-5 w-5" />
                  <span className="font-medium">Mis Datos</span>
                </a>
              </SidebarMenuButton>
            </SidebarMenuItem>

            {/* DOCENCIA */}
            <SidebarMenuItem>
              <Collapsible open={openSections.docencia} onOpenChange={() => toggleSection("docencia")}>
                <CollapsibleTrigger asChild>
                  <SidebarMenuButton tooltip="Docencia" className="px-2">
                    <div className="flex items-center gap-3 flex-1">
                      <BookOpen className="h-5 w-5" />
                      <span className="font-medium">Docencia</span>
                    </div>
                    <ChevronRight
                      className={`h-4 w-4 transition-transform duration-200 ${
                        openSections.docencia ? "rotate-90" : ""
                      }`}
                    />
                  </SidebarMenuButton>
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-1">
                  <SidebarMenuSub>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/teaching/classes">Clases frente a Grupo</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/teaching/materials">Material Didáctico</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/teaching/evaluation">Evaluación Docente</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/teaching/courses">Cursos y Diplomados</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                  </SidebarMenuSub>
                </CollapsibleContent>
              </Collapsible>
            </SidebarMenuItem>

            {/* INVESTIGACIÓN */}
            <SidebarMenuItem>
              <Collapsible open={openSections.investigacion} onOpenChange={() => toggleSection("investigacion")}>
                <CollapsibleTrigger asChild>
                  <SidebarMenuButton tooltip="Investigación" className="px-2">
                    <div className="flex items-center gap-3 flex-1">
                      <Microscope className="h-5 w-5" />
                      <span className="font-medium">Investigación</span>
                    </div>
                    <ChevronRight
                      className={`h-4 w-4 transition-transform duration-200 ${
                        openSections.investigacion ? "rotate-90" : ""
                      }`}
                    />
                  </SidebarMenuButton>
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-1">
                  <SidebarMenuSub>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/research/articles">Artículos Científicos</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/research/books">Libros y Capítulos</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/research/projects">Proyectos de Investigación</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/research/congresses">Congresos y Ponencias</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/research/patents">Patentes y Prototipos</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/research/sni">SNI (Sistema Nacional de Investigadores)</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                  </SidebarMenuSub>
                </CollapsibleContent>
              </Collapsible>
            </SidebarMenuItem>

            {/* TUTORÍAS */}
            <SidebarMenuItem>
              <Collapsible open={openSections.tutorias} onOpenChange={() => toggleSection("tutorias")}>
                <CollapsibleTrigger asChild>
                  <SidebarMenuButton tooltip="Tutorías" className="px-2">
                    <div className="flex items-center gap-3 flex-1">
                      <Users className="h-5 w-5" />
                      <span className="font-medium">Tutorías</span>
                    </div>
                    <ChevronRight
                      className={`h-4 w-4 transition-transform duration-200 ${
                        openSections.tutorias ? "rotate-90" : ""
                      }`}
                    />
                  </SidebarMenuButton>
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-1">
                  <SidebarMenuSub>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/tutoring/permanent">Tutoría Permanente (Individual/Grupal)</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/tutoring/thesis">Dirección de Tesis</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/tutoring/jury">Jurado de Exámenes</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/tutoring/social-service">Asesoría Servicio Social</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                  </SidebarMenuSub>
                </CollapsibleContent>
              </Collapsible>
            </SidebarMenuItem>

            {/* GESTIÓN */}
            <SidebarMenuItem>
              <Collapsible open={openSections.gestion} onOpenChange={() => toggleSection("gestion")}>
                <CollapsibleTrigger asChild>
                  <SidebarMenuButton tooltip="Gestión" className="px-2">
                    <div className="flex items-center gap-3 flex-1">
                      <Building2 className="h-5 w-5" />
                      <span className="font-medium">Gestión</span>
                    </div>
                    <ChevronRight
                      className={`h-4 w-4 transition-transform duration-200 ${openSections.gestion ? "rotate-90" : ""}`}
                    />
                  </SidebarMenuButton>
                </CollapsibleTrigger>
                <CollapsibleContent className="mt-1">
                  <SidebarMenuSub>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/management/boards">Cuerpos Colegiados</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/management/commissions">Comisiones Académicas</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                    <SidebarMenuSubItem>
                      <SidebarMenuSubButton asChild>
                        <a href="/management/academic-bodies">Cuerpos Académicos (PRODEP)</a>
                      </SidebarMenuSubButton>
                    </SidebarMenuSubItem>
                  </SidebarMenuSub>
                </CollapsibleContent>
              </Collapsible>
            </SidebarMenuItem>

            {/* MIS EXPEDIENTES */}
            <SidebarMenuItem>
              <SidebarMenuButton tooltip="Mis Expedientes" asChild>
                <a href="/expedients">
                  <FileClock className="h-5 w-5" />
                  <span className="font-medium">Mis Expedientes</span>
                </a>
              </SidebarMenuButton>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="bg-sidebar border-t border-sidebar-border p-4">
        <div className="flex items-center gap-3 group-data-[collapsible=icon]:justify-center">
          <div className="flex flex-col group-data-[collapsible=icon]:hidden">
            <span className="text-[10px] text-sidebar-foreground/50 font-medium">Versión</span>
            <span className="text-xs text-sidebar-primary font-bold tracking-tighter">2.4.0-STABLE</span>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  )
}
