"use client"
import { useState, useEffect, useMemo } from "react"
import { Menu, X, PanelLeftOpen } from "lucide-react"
import { SidebarExplorer, MENU_DATA } from "@/components/sidebar-explorer"
import { SectionContent } from "@/components/section-content"
import { ProfileView } from "@/components/profile-view"
import { AdminDashboardView } from "@/components/admin-dashboard-view"
import { AdminReviewView } from "@/components/admin-review-view"
import { AdminUsersView } from "@/components/admin-users-view"
import { EvaluadorDashboard } from "@/components/evaluador-dashboard"
import { DashboardView } from "@/components/dashboard-view"
import { GeneralesView } from "@/components/generales-view"
import { WelcomeView } from "@/components/welcome-view"
import { cn } from "@/lib/utils"

interface Convocatoria {
  id: string
  nombre: string
  periodo: string
  estado: "activa" | "cerrada"
}

interface AppLayoutProps {
  onLogout: () => void
  userType: "profesor" | "admin" | "evaluador"
  selectedConvocatoria?: Convocatoria | null
  onBackToConvocatorias?: () => void
}

function getAllLeafItems(items: any[]): any[] {
  const result: any[] = []
  for (const item of items) {
    if (item.items && item.items.length > 0) {
      result.push(...getAllLeafItems(item.items))
    } else if (!item.isSeparator && item.id !== "inicio" && item.id !== "perfil" && item.id !== "ayuda") {
      result.push(item)
    }
  }
  return result
}

function getItemPath(items: any[], targetId: string, path: string[] = []): string[] | null {
  for (const item of items) {
    if (item.id === targetId) {
      return [...path, item.title]
    }
    if (item.items && item.items.length > 0) {
      const found = getItemPath(item.items, targetId, [...path, item.title])
      if (found) return found
    }
  }
  return null
}

function isGeneralesItem(itemId: string): boolean {
  const generalesIds = [
    "solicitud-ingreso",
    "carta-exclusividad",
    "constancia-antiguedad",
    "informe-evaluacion",
    "documentos-grado",
  ]
  return generalesIds.includes(itemId)
}

function getFirstRubroItem(items: any[]): any | null {
  const calidadSection = items.find((item) => item.id === "calidad")
  if (calidadSection?.items) {
    const docenciaSection = calidadSection.items.find((item: any) => item.id === "docencia")
    if (docenciaSection?.items) {
      const calidadDesempeno = docenciaSection.items.find((item: any) => item.id === "calidad-desempeno")
      if (calidadDesempeno?.items) {
        return calidadDesempeno.items[0]
      }
      return docenciaSection.items.find((item: any) => !item.items)
    }
  }
  return null
}

export function AppLayout({ onLogout, userType, selectedConvocatoria, onBackToConvocatorias }: AppLayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [selectedItem, setSelectedItem] = useState<any>({ id: "inicio", title: "Inicio" })
  const [showWelcome, setShowWelcome] = useState(true)

  const allLeafItems = useMemo(() => getAllLeafItems(MENU_DATA), [])

  const currentIndex = allLeafItems.findIndex((item) => item.id === selectedItem.id)
  const hasPrev = currentIndex > 0
  const hasNext = currentIndex < allLeafItems.length - 1 && currentIndex !== -1
  const prevItem = hasPrev ? allLeafItems[currentIndex - 1] : null
  const nextItem = hasNext ? allLeafItems[currentIndex + 1] : null

  const itemPath = useMemo(() => {
    return getItemPath(MENU_DATA, selectedItem.id) || [selectedItem.title]
  }, [selectedItem])

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileMenuOpen(false)
      }
    }
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const handleSelectItem = (item: any) => {
    setSelectedItem(item)
    setIsMobileMenuOpen(false)
    setShowWelcome(false)
  }

  const handleNavigateNext = () => {
    if (nextItem) {
      setSelectedItem(nextItem)
    }
  }

  const handleNavigatePrev = () => {
    if (prevItem) {
      setSelectedItem(prevItem)
    }
  }

  const handleWelcomeContinue = () => {
    setShowWelcome(false)
    const generalesItem = MENU_DATA.find((item) => item.id === "generales")
    if (generalesItem) {
      setSelectedItem(generalesItem)
    }
  }

  const handleGeneralesNext = () => {
    const firstRubro = getFirstRubroItem(MENU_DATA)
    if (firstRubro) {
      setSelectedItem(firstRubro)
    }
  }

  const renderContent = () => {
    if (userType === "profesor" && showWelcome && selectedConvocatoria) {
      return <WelcomeView onContinue={handleWelcomeContinue} convocatoriaName={selectedConvocatoria.nombre} />
    }

    if (userType === "admin") {
      if (selectedItem.id === "inicio") return <AdminDashboardView onNavigate={() => {}} />
      if (selectedItem.id === "admin-review") return <AdminReviewView />
      if (selectedItem.id === "admin-users") return <AdminUsersView />
      if (selectedItem.id === "perfil") return <ProfileView />
    }

    if (userType === "evaluador") {
      if (selectedItem.id === "inicio") return <EvaluadorDashboard onNavigate={() => {}} />
      if (selectedItem.id === "perfil") return <ProfileView />
    }

    if (selectedItem.id === "generales" || isGeneralesItem(selectedItem.id)) {
      return <GeneralesView onNavigateNext={handleGeneralesNext} />
    }

    if (selectedItem.id === "inicio") {
      return (
        <DashboardView
          onNavigate={(view: string) => {
            if (view === "evaluacion" || view === "generales") {
              const generalesItem = MENU_DATA.find((item) => item.id === "generales")
              if (generalesItem) {
                setSelectedItem(generalesItem)
              }
              return
            }
            const findItem = (items: any[], targetId: string): any => {
              for (const item of items) {
                if (item.id === targetId) return item
                if (item.items) {
                  const found = findItem(item.items, targetId)
                  if (found) return found
                }
              }
              return null
            }
            const item = findItem(MENU_DATA, view)
            if (item) setSelectedItem(item)
          }}
          onOpenEvaluation={() => {
            setShowWelcome(true)
          }}
        />
      )
    }

    if (selectedItem.id === "perfil") return <ProfileView />

    if (selectedItem.id === "ayuda") {
      return (
        <div className="h-full overflow-y-auto p-4 md:p-6">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-xl md:text-2xl font-bold text-gray-800 mb-6">Centro de Ayuda</h1>
            <div className="grid gap-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h3 className="font-semibold text-blue-800 mb-1">Soporte Técnico</h3>
                <p className="text-blue-700 text-sm mb-2">Para problemas con el sistema.</p>
                <p className="text-blue-800 font-medium text-sm">951-123-4567</p>
                <p className="text-blue-600 text-xs">soporte@uabjo.mx</p>
              </div>
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg">
                <h3 className="font-semibold text-emerald-800 mb-1">Dudas Académicas</h3>
                <p className="text-emerald-700 text-sm mb-2">Consultas sobre rubros y evaluaciones.</p>
                <p className="text-emerald-800 font-medium text-sm">951-987-6543</p>
                <p className="text-emerald-600 text-xs">academico@uabjo.mx</p>
              </div>
              <div className="p-4 bg-gray-50 border rounded-lg">
                <h3 className="font-semibold text-gray-800 mb-2">Horario de Atención</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500 text-xs">Lunes a Viernes</p>
                    <p className="font-medium text-gray-800">9:00 - 18:00</p>
                  </div>
                  <div>
                    <p className="text-gray-500 text-xs">Sábados</p>
                    <p className="font-medium text-gray-800">9:00 - 14:00</p>
                  </div>
                </div>
              </div>
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                <h3 className="font-semibold text-amber-800 mb-1">Manuales</h3>
                <p className="text-amber-700 text-sm mb-3">Descarga guías y documentación.</p>
                <button className="px-4 py-2 bg-amber-500 text-white rounded-lg hover:bg-amber-600 transition-colors text-sm font-medium">
                  Descargar Manual PDF
                </button>
              </div>
            </div>
          </div>
        </div>
      )
    }

    return (
      <SectionContent
        item={selectedItem}
        onNavigateNext={handleNavigateNext}
        onNavigatePrev={handleNavigatePrev}
        hasNext={hasNext}
        hasPrev={hasPrev}
        nextTitle={nextItem?.title}
        prevTitle={prevItem?.title}
        breadcrumbPath={itemPath}
      />
    )
  }

  return (
    <div className="flex h-screen overflow-hidden bg-white">
      {isMobileMenuOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setIsMobileMenuOpen(false)} />
      )}

      <div
        className={cn(
          "hidden lg:block flex-shrink-0 h-screen transition-all duration-300 ease-in-out",
          isSidebarOpen ? "w-80" : "w-0",
        )}
      >
        <SidebarExplorer
          onSelectItem={handleSelectItem}
          activeItemId={selectedItem.id}
          onLogout={onLogout}
          isOpen={isSidebarOpen}
          onToggle={() => setIsSidebarOpen(false)}
          selectedConvocatoria={selectedConvocatoria}
          onBackToConvocatorias={onBackToConvocatorias}
          userType={userType}
        />
      </div>

      <div
        className={cn(
          "fixed inset-y-0 left-0 z-50 lg:hidden transform transition-transform duration-300 ease-in-out",
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <SidebarExplorer
          onSelectItem={handleSelectItem}
          activeItemId={selectedItem.id}
          onLogout={onLogout}
          isOpen={true}
          selectedConvocatoria={selectedConvocatoria}
          onBackToConvocatorias={onBackToConvocatorias}
          userType={userType}
        />
      </div>

      <div className="flex-1 flex flex-col overflow-hidden min-w-0 relative">
        {!isSidebarOpen && (
          <div className="hidden lg:block absolute left-4 top-4 z-30">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="flex items-center gap-2 px-3 py-2 bg-[#0a1628] text-white rounded-lg shadow-lg hover:bg-[#0a1628]/90 transition-all"
              aria-label="Abrir panel lateral"
            >
              <PanelLeftOpen className="h-5 w-5" />
              <span className="text-sm font-medium">Menú</span>
            </button>
          </div>
        )}

        <header className="lg:hidden bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-3 flex-shrink-0">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 hover:bg-gray-100 rounded-lg"
            aria-label={isMobileMenuOpen ? "Cerrar menú" : "Abrir menú"}
          >
            {isMobileMenuOpen ? <X className="h-5 w-5 text-gray-700" /> : <Menu className="h-5 w-5 text-gray-700" />}
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-amber-400 rounded flex items-center justify-center">
              <span className="font-bold text-[#0a1628] text-xs">S</span>
            </div>
            <span className="font-bold text-gray-800 text-sm">SIGEP</span>
          </div>
        </header>

        <main className="flex-1 overflow-hidden bg-white">{renderContent()}</main>
      </div>
    </div>
  )
}
