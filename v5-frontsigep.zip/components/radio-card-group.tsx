"use client"
import { Card } from "@/components/ui/card"
import { cn } from "@/lib/utils"

export interface RadioCardOption {
  id: string
  label: string
  description?: string
}

interface RadioCardGroupProps {
  options: RadioCardOption[]
  value?: string
  onValueChange?: (value: string) => void
  className?: string
}

export function RadioCardGroup({ options, value, onValueChange, className }: RadioCardGroupProps) {
  return (
    <div className={cn("grid grid-cols-1 gap-4 md:grid-cols-2", className)}>
      {options.map((option) => (
        <Card
          key={option.id}
          onClick={() => onValueChange?.(option.id)}
          className={cn(
            "cursor-pointer p-6 transition-all border-2",
            value === option.id
              ? "border-primary bg-primary/5 ring-2 ring-primary"
              : "border-muted hover:border-primary/50",
          )}
        >
          <div className="flex items-start gap-4">
            <div
              className={cn(
                "mt-1 h-6 w-6 rounded-full border-2 flex items-center justify-center flex-shrink-0",
                value === option.id ? "border-primary bg-primary" : "border-muted-foreground",
              )}
            >
              {value === option.id && <div className="h-2 w-2 rounded-full bg-white" />}
            </div>
            <div>
              <p className="text-lg font-semibold">{option.label}</p>
              {option.description && <p className="text-sm text-muted-foreground mt-2">{option.description}</p>}
            </div>
          </div>
        </Card>
      ))}
    </div>
  )
}
