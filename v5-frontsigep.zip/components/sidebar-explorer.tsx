"use client"

import { useState, useEffect } from "react"
import {
  LayoutDashboard,
  BookOpen,
  FlaskConical,
  Users,
  Building2,
  User,
  HelpCircle,
  ChevronRight,
  ChevronDown,
  FileText,
  Clock,
  Award,
  PanelLeftClose,
  RefreshCw,
  ClipboardList,
} from "lucide-react"
import { cn } from "@/lib/utils"

const RUBRO_COLORS: Record<string, { bg: string; border: string; icon: string; indicator: string; hoverBg: string }> = {
  generales: {
    bg: "bg-violet-500/10",
    border: "border-l-4 border-violet-500",
    icon: "text-violet-400",
    indicator: "bg-violet-500",
    hoverBg: "hover:bg-violet-500/20",
  },
  calidad: {
    bg: "bg-emerald-500/10",
    border: "border-l-4 border-emerald-500",
    icon: "text-emerald-400",
    indicator: "bg-emerald-500",
    hoverBg: "hover:bg-emerald-500/20",
  },
  dedicacion: {
    bg: "bg-blue-500/10",
    border: "border-l-4 border-blue-500",
    icon: "text-blue-400",
    indicator: "bg-blue-500",
    hoverBg: "hover:bg-blue-500/20",
  },
  permanencia: {
    bg: "bg-amber-500/10",
    border: "border-l-4 border-amber-500",
    icon: "text-amber-400",
    indicator: "bg-amber-500",
    hoverBg: "hover:bg-amber-500/20",
  },
}

const MENU_DATA = [
  {
    id: "inicio",
    title: "Inicio",
    icon: LayoutDashboard,
    isFolder: false,
    url: "#",
  },
  {
    id: "generales",
    title: "0. GENERALES",
    icon: ClipboardList,
    isFolder: true,
    items: [
      {
        id: "solicitud-ingreso",
        title: "Solicitud de Ingreso",
        url: "#",
        description: "Formato oficial de solicitud de ingreso al programa de estímulos.",
      },
      {
        id: "carta-exclusividad",
        title: "Carta de Exclusividad",
        url: "#",
        description: "Documento que acredita dedicación exclusiva a la institución.",
      },
      {
        id: "constancia-antiguedad",
        title: "Constancia de Antigüedad",
        url: "#",
        description: "Documento oficial que avala los años de servicio en la institución.",
      },
      {
        id: "informe-evaluacion",
        title: "Informe de Evaluación",
        url: "#",
        description: "Informe del periodo de evaluación anterior.",
      },
      {
        id: "documentos-grado",
        title: "Documentos de Grado",
        url: "#",
        description: "Títulos y cédulas profesionales. Incluye opción Nacional/Extranjero.",
      },
    ],
  },
  {
    id: "calidad",
    title: "I. CALIDAD (700 Pts)",
    icon: Award,
    isFolder: true,
    items: [
      {
        id: "docencia",
        title: "I.1. DOCENCIA (100-300 Pts)",
        icon: BookOpen,
        isFolder: true,
        items: [
          {
            id: "calidad-desempeno",
            title: "Calidad al desempeño docente",
            isFolder: true,
            items: [
              {
                id: "programas",
                title: "Programas de asignatura",
                url: "#",
                description: "Copia de los programas de las materias impartidas al inicio del ciclo escolar.",
              },
              {
                id: "evaluacion",
                title: "Constancia de evaluación docente",
                url: "#",
                description: "Documento expedido por el Sistema Institucional de Control Escolar o equivalente.",
              },
              {
                id: "calificaciones",
                title: "Calificaciones finales",
                url: "#",
                description: "Copias de las actas o registros de calificaciones entregadas.",
              },
              {
                id: "material",
                title: "Uso de material didáctico",
                url: "#",
                description: "Apuntes, cuadernillos, material audiovisual o contenido multimedia de autoría propia.",
              },
              {
                id: "asistencia",
                title: "Asistencia y puntualidad",
                url: "#",
                description: "Registro o constancia que avale el cumplimiento de horarios.",
              },
            ],
          },
          {
            id: "libros-isbn",
            title: "Autor de libros con ISBN",
            url: "#",
            description: "Ejemplar o copia de la portada, página legal con ISBN y distribución nacional/internacional.",
          },
          {
            id: "capitulos-libros",
            title: "Publicación de capítulos en libros",
            url: "#",
            description: "Copia del capítulo, portada del libro con ISBN y página legal.",
          },
          {
            id: "antologias",
            title: "Elaboración de antologías",
            url: "#",
            description: "Documento de la antología elaborada para cursos curriculares.",
          },
          {
            id: "exposiciones",
            title: "Obra en exposiciones artísticas",
            url: "#",
            description: "Constancias de participación en exposiciones, muestras artísticas de la UABJO.",
          },
          {
            id: "conciertos",
            title: "Concierto o recital musical",
            url: "#",
            description: "Constancias de participación en conciertos o recitales de la UABJO.",
          },
          {
            id: "patentes",
            title: "Patentes, modelos y prototipos",
            url: "#",
            description: "Título de la patente, registro de modelo o prototipo ante IMPI/INDAUTOR.",
          },
          {
            id: "cursos-disciplinarios",
            title: "Cursos actualización disciplinaria",
            url: "#",
            description: "Constancias con número de horas (mínimo 0.5 pts por hora).",
          },
          {
            id: "cursos-formacion",
            title: "Cursos de formación docente",
            url: "#",
            description: "Constancias con número de horas (mínimo 0.5 pts por hora).",
          },
          {
            id: "diplomados",
            title: "Diplomados (mín. 80 horas)",
            url: "#",
            description: "Diploma o constancia que acredite un mínimo de 80 horas.",
          },
          {
            id: "org-cursos",
            title: "Organizar cursos actualización",
            url: "#",
            description: "Oficio o constancia de haber organizado cursos de actualización.",
          },
          {
            id: "ponente-cursos",
            title: "Ponente en cursos/talleres",
            url: "#",
            description: "Constancias de participación como ponente en eventos académicos.",
          },
          {
            id: "premios-labor",
            title: "Premios labor o trayectoria",
            url: "#",
            description: "Título o documento que avale premios de prestigio estatal, nacional o internacional.",
          },
          {
            id: "perfil-prodep",
            title: "Perfil Deseable PRODEP",
            url: "#",
            description: "Oficio de reconocimiento vigente de Perfil Deseable.",
          },
          {
            id: "cursos-ciees",
            title: "Cursos Licenciatura CIEES/Acred.",
            url: "#",
            description: "Constancia de impartir clases en programas acreditados (CIEES nivel I).",
          },
          {
            id: "cursos-snp",
            title: "Cursos en Posgrados SNP",
            url: "#",
            description: "Constancia de impartir clases en Posgrados del SNP.",
          },
          {
            id: "vinculacion",
            title: "Proyectos de vinculación",
            url: "#",
            description: "Oficio de participación o responsabilidad en proyectos con sectores sociales o productivos.",
          },
          {
            id: "formacion-rsu",
            title: "Formación modelo RSU",
            url: "#",
            description: "Constancia de formación en el modelo de Responsabilidad Social Universitaria.",
          },
          {
            id: "acciones-int",
            title: "Acciones internacionales",
            url: "#",
            description:
              "Documentos que acrediten estancias, sabáticos, docencia en el extranjero o ponencias internacionales.",
          },
        ],
      },
      {
        id: "investigacion",
        title: "I.2. INVESTIGACIÓN (25-150 Pts)",
        icon: FlaskConical,
        isFolder: true,
        items: [
          {
            id: "asistente-congresos",
            title: "Asistente en congresos",
            url: "#",
            description: "Constancias de asistente en eventos de investigación.",
          },
          {
            id: "ponente-congresos",
            title: "Ponente en congresos/foros",
            url: "#",
            description: "Constancias de ponente en eventos de investigación.",
          },
          {
            id: "ponencia-magistral",
            title: "Ponencia magistral",
            url: "#",
            description: "Constancia que especifique el carácter de 'Magistral'.",
          },
          {
            id: "articulos-difusion",
            title: "Artículos en revistas difusión",
            url: "#",
            description: "Copia del artículo donde conste la revista.",
          },
          {
            id: "articulos-indexados",
            title: "Artículos revistas indexadas",
            url: "#",
            description: "Copia del artículo con evidencia de arbitraje/indexación.",
          },
          {
            id: "articulos-scopus",
            title: "Artículos SCOPUS/JCR",
            url: "#",
            description: "Copia del artículo con evidencia de pertenencia a SCOPUS/JCR.",
          },
          {
            id: "capitulos-especializados",
            title: "Capítulos libros especializados",
            url: "#",
            description: "Copia del capítulo y página legal del libro especializado con ISBN.",
          },
          {
            id: "coord-libros-locales",
            title: "Coord/Editor libros locales",
            url: "#",
            description: "Ejemplar o copia legal que acredite el cargo en libros (ISBN).",
          },
          {
            id: "coord-libros-nac",
            title: "Coord/Editor nac. e int.",
            url: "#",
            description: "Ejemplar o copia legal que acredite el cargo en revistas (ISSN).",
          },
          {
            id: "publicacion-memorias",
            title: "Publicación en memorias",
            url: "#",
            description: "Copia de la publicación en memorias de eventos con arbitraje.",
          },
          {
            id: "proyectos-internos",
            title: "Proyectos financiamiento interno",
            url: "#",
            description: "Oficio de aprobación/financiamiento interno y oficio de conclusión.",
          },
          {
            id: "proyectos-externos",
            title: "Proyectos financiamiento externo",
            url: "#",
            description: "Oficio de aprobación/financiamiento externo y oficio de conclusión.",
          },
          {
            id: "evaluador-proyectos",
            title: "Evaluador de proyectos",
            url: "#",
            description: "Oficio de designación o constancia como evaluador de proyectos.",
          },
          {
            id: "evaluador-publicaciones",
            title: "Evaluador de publicaciones",
            url: "#",
            description: "Oficio de designación o constancia como evaluador de artículos.",
          },
          {
            id: "estancias",
            title: "Estancias de investigación",
            url: "#",
            description: "Constancia de estancia de investigación (mínimo 15 días).",
          },
          {
            id: "sni",
            title: "Investigador Nacional SNI",
            url: "#",
            description: "Nombramiento vigente como Investigador Nacional y carga horaria mínima de 4 hrs.",
          },
        ],
      },
      {
        id: "tutorias",
        title: "I.3. TUTORÍAS (30-150 Pts)",
        icon: Users,
        isFolder: true,
        items: [
          {
            id: "tutorias-perm",
            title: "Tutorías permanentes",
            url: "#",
            description: "Certificación de la dirección o coordinación (10, 20 o 30 horas anuales).",
          },
          {
            id: "revisor-tesis",
            title: "Revisor tesis/Jurado examen",
            url: "#",
            description: "Actas de examen profesional, oficios de designación como jurado.",
          },
          {
            id: "olimpiadas",
            title: "Preparación de grupos olimpiadas",
            url: "#",
            description: "Constancia de preparación de estudiantes para olimpiadas académicas.",
          },
          {
            id: "dir-tesis-lic",
            title: "Director de tesis licenciatura",
            url: "#",
            description: "Actas de examen profesional, oficios de designación como director.",
          },
          {
            id: "dir-tesis-mae",
            title: "Dirección de tesis maestría",
            url: "#",
            description: "Actas de examen profesional, oficios de designación como director.",
          },
          {
            id: "dir-tesis-doc",
            title: "Dirección de tesis doctorado",
            url: "#",
            description: "Actas de examen profesional, oficios de designación como director.",
          },
          {
            id: "lector-posgrado",
            title: "Lector/Revisor tesis posgrado",
            url: "#",
            description: "Oficio de designación o constancia de lectura de tesis de posgrado.",
          },
          {
            id: "serv-social-anual",
            title: "Asesoría serv. social anual",
            url: "#",
            description: "Oficio de asesoría y reporte de conclusiones del trabajo del estudiante.",
          },
          {
            id: "serv-social-sem",
            title: "Asesoría serv. social semestral",
            url: "#",
            description: "Oficio de asesoría y reporte de conclusiones del trabajo del estudiante.",
          },
          {
            id: "premios-supervisada",
            title: "Premios labor supervisada",
            url: "#",
            description: "Documento que avale el premio del estudiante y la supervisión del profesor.",
          },
          {
            id: "premios-concursos",
            title: "Premios concursos académicos",
            url: "#",
            description: "Documento que avale el premio del estudiante y la supervisión del profesor.",
          },
          {
            id: "lineas-inv",
            title: "Formación en líneas de inv.",
            url: "#",
            description: "Constancia de formación de estudiantes en el Cuerpo Académico.",
          },
          {
            id: "tutoria-movilidad",
            title: "Tutoría movilidad/verano",
            url: "#",
            description: "Oficio de tutoría a estudiantes de movilidad.",
          },
          {
            id: "tutoria-postdoc",
            title: "Tutoría postdoctorales",
            url: "#",
            description: "Oficio de tutoría a investigadores postdoctorales.",
          },
          {
            id: "registro-patentes",
            title: "Registro patentes/prototipos",
            url: "#",
            description: "Registro de patentes o prototipos desarrollados con estudiantes.",
          },
          {
            id: "asesoria-titulacion",
            title: "Asesoría titulación (no tesis)",
            url: "#",
            description: "Constancia de asesoría para titulación por modalidad diferente a tesis.",
          },
          {
            id: "impacto-rsu",
            title: "Actividades impacto RSU",
            url: "#",
            description: "Constancia de actividades con impacto en Responsabilidad Social Universitaria.",
          },
        ],
      },
      {
        id: "cuerpos-colegiados",
        title: "I.4. CUERPOS COLEGIADOS (30-100 Pts)",
        icon: Building2,
        isFolder: true,
        items: [
          {
            id: "revision-planes",
            title: "Revisión planes estudio",
            url: "#",
            description: "Acta de aprobación del H. Consejo Técnico y Universitario.",
          },
          {
            id: "comisiones-acad",
            title: "Comisiones académicas",
            url: "#",
            description: "Oficios de designación y presentación de resultados/informe.",
          },
          {
            id: "gestion-consejos",
            title: "Gestión Académica (Consejos)",
            url: "#",
            description: "Oficios de designación y presentación de resultados/informe.",
          },
          {
            id: "org-extension",
            title: "Organización actos extensión",
            url: "#",
            description: "Constancias de organización como parte del colectivo.",
          },
          {
            id: "actos-internacionales",
            title: "Actos prestigio internacional",
            url: "#",
            description: "Constancias de organización como parte del colectivo.",
          },
          {
            id: "muestras-nacionales",
            title: "Muestras prestigio nacional",
            url: "#",
            description: "Constancias de organización como parte del colectivo.",
          },
          {
            id: "evaluador-posgrado",
            title: "Evaluador programas posgrado",
            url: "#",
            description: "Constancia de participación como evaluador de programas de posgrado.",
          },
          {
            id: "cuerpos-prodep",
            title: "Cuerpos Académicos PRODEP",
            url: "#",
            description: "Oficio de reconocimiento del Cuerpo Académico (En formación, consolidación o consolidado).",
          },
        ],
      },
    ],
  },
  {
    id: "dedicacion",
    title: "II. DEDICACIÓN (200 Pts)",
    icon: Clock,
    isFolder: true,
    items: [
      {
        id: "carga-horaria",
        title: "Carga Horaria Docente",
        url: "#",
        description: "Evidencia de carga horaria (mínimo 4h/semana) y actas de control escolar o equivalente.",
      },
    ],
  },
  {
    id: "permanencia",
    title: "III. PERMANENCIA (100 Pts)",
    icon: Users,
    isFolder: true,
    items: [
      {
        id: "antiguedad",
        title: "Antigüedad",
        url: "#",
        description:
          "Constancia de servicios o documento oficial que acredite los años de labor docente en la institución.",
      },
    ],
  },
  {
    id: "perfil",
    title: "Mi Perfil",
    icon: User,
    isFolder: false,
    url: "#",
  },
  {
    id: "ayuda",
    title: "Centro de Ayuda",
    icon: HelpCircle,
    isFolder: false,
    url: "#",
  },
]

export { MENU_DATA }

interface MenuItemProps {
  item: any
  level?: number
  expandedItems: Set<string>
  toggleExpand: (id: string) => void
  activeItem: string | null
  setActiveItem: (id: string) => void
  parentRubroId?: string | null
}

function MenuItem({
  item,
  level = 0,
  expandedItems,
  toggleExpand,
  activeItem,
  setActiveItem,
  parentRubroId,
}: MenuItemProps) {
  const hasChildren = item.items && item.items.length > 0
  const isExpanded = expandedItems.has(item.id)
  const isActive = activeItem === item.id
  const paddingLeft = 16 + level * 12

  const currentRubroId = level === 0 && RUBRO_COLORS[item.id] ? item.id : parentRubroId
  const rubroColor = currentRubroId ? RUBRO_COLORS[currentRubroId] : null

  const isMainRubro = level === 0 && RUBRO_COLORS[item.id]
  const isSpecialItem = item.id === "perfil" || item.id === "ayuda"

  const handleClick = () => {
    if (hasChildren || item.isFolder) {
      toggleExpand(item.id)
    } else {
      setActiveItem(item.id)
    }
  }

  return (
    <div className="select-none">
      <button
        onClick={handleClick}
        className={cn(
          "w-full flex items-center gap-2 py-2 px-3 text-left transition-all duration-150 text-sm",
          "hover:bg-white/10",
          isActive && !hasChildren && "bg-white/15 text-white",
          !isActive && "text-white/80",
          isMainRubro && rubroColor?.bg,
          isMainRubro && rubroColor?.border,
          isMainRubro && rubroColor?.hoverBg,
          isSpecialItem && "mt-1 bg-white/5",
        )}
        style={{ paddingLeft: `${paddingLeft}px` }}
      >
        {/* Chevron para expandir */}
        {hasChildren || item.isFolder ? (
          <span className="w-4 h-4 flex items-center justify-center flex-shrink-0">
            {isExpanded ? (
              <ChevronDown className="h-3.5 w-3.5 text-white/50" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 text-white/50" />
            )}
          </span>
        ) : (
          <span className="w-4" />
        )}

        {/* Icono */}
        {item.icon ? (
          <item.icon
            className={cn(
              "h-4 w-4 flex-shrink-0",
              isMainRubro && rubroColor ? rubroColor.icon : isSpecialItem ? "text-amber-400" : "text-white/60",
            )}
          />
        ) : (
          <FileText className="h-3.5 w-3.5 text-white/40 flex-shrink-0" />
        )}

        {/* Titulo */}
        <span className={cn("truncate flex-1", level === 0 ? "font-medium" : "font-normal")}>{item.title}</span>

        {/* Indicador de color para rubros principales */}
        {isMainRubro && rubroColor && (
          <span className={cn("w-2 h-2 rounded-full flex-shrink-0", rubroColor.indicator)} />
        )}
      </button>

      {/* Sub-items */}
      {hasChildren && (
        <div
          className={cn(
            "overflow-hidden transition-all duration-200 ease-in-out",
            isExpanded ? "max-h-[2000px] opacity-100" : "max-h-0 opacity-0",
          )}
        >
          {item.items.map((subItem: any) => (
            <MenuItem
              key={subItem.id}
              item={subItem}
              level={level + 1}
              expandedItems={expandedItems}
              toggleExpand={toggleExpand}
              activeItem={activeItem}
              setActiveItem={setActiveItem}
              parentRubroId={currentRubroId}
            />
          ))}
        </div>
      )}
    </div>
  )
}

interface Convocatoria {
  id: string
  nombre: string
  periodo: string
  estado: "activa" | "cerrada"
}

interface SidebarExplorerProps {
  onSelectItem?: (item: any) => void
  activeItemId?: string
  onLogout?: () => void
  isOpen?: boolean
  onToggle?: () => void
  selectedConvocatoria?: { id: string; nombre: string; periodo: string; estado: string } | null
  onBackToConvocatorias?: () => void
  userType?: "profesor" | "admin" | "evaluador"
}

export function SidebarExplorer({
  onSelectItem,
  activeItemId,
  onLogout,
  isOpen = true,
  onToggle,
  selectedConvocatoria,
  onBackToConvocatorias,
  userType = "profesor",
}: SidebarExplorerProps) {
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set(["generales", "calidad"]))
  const [activeItem, setActiveItem] = useState<string | null>(activeItemId || "inicio")

  useEffect(() => {
    if (activeItemId) {
      setActiveItem(activeItemId)
    }
  }, [activeItemId])

  const toggleExpand = (id: string) => {
    setExpandedItems((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(id)) {
        newSet.delete(id)
      } else {
        newSet.add(id)
      }
      return newSet
    })
  }

  const handleSetActiveItem = (id: string) => {
    setActiveItem(id)
    const findItem = (items: any[], targetId: string): any => {
      for (const item of items) {
        if (item.id === targetId) return item
        if (item.items) {
          const found = findItem(item.items, targetId)
          if (found) return found
        }
      }
      return null
    }
    const selectedItem = findItem(MENU_DATA, id)
    if (onSelectItem && selectedItem) {
      onSelectItem(selectedItem)
    }
  }

  return (
    <aside
      className={cn(
        "h-full bg-[#0a1628] flex flex-col transition-all duration-300",
        isOpen ? "w-80" : "w-0 overflow-hidden",
      )}
    >
      <div className="flex-shrink-0 px-3 py-2 flex items-center justify-between bg-[#0a1628] border-b border-white/10">
        {userType === "profesor" && selectedConvocatoria ? (
          <button
            onClick={onBackToConvocatorias}
            className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-white bg-amber-500 hover:bg-amber-600 rounded-lg transition-colors"
          >
            <RefreshCw className="h-4 w-4" />
            Cambiar convocatoria
          </button>
        ) : (
          <div />
        )}
        {onToggle && (
          <button
            onClick={onToggle}
            className="p-1.5 hover:bg-white/10 rounded-lg transition-colors"
            aria-label="Ocultar panel"
          >
            <PanelLeftClose className="h-5 w-5 text-white/60" />
          </button>
        )}
      </div>

      <div className="flex-shrink-0 px-4 py-2 bg-[#0a1628]/50 flex items-center gap-3 text-[10px] border-b border-white/5 flex-wrap">
        <div className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-violet-500" />
          <span className="text-white/50">Generales</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          <span className="text-white/50">Calidad</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-blue-500" />
          <span className="text-white/50">Dedicación</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-2 h-2 rounded-full bg-amber-500" />
          <span className="text-white/50">Permanencia</span>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto overflow-x-hidden py-1 sidebar-scroll">
        {MENU_DATA.map((item) => (
          <MenuItem
            key={item.id}
            item={item}
            expandedItems={expandedItems}
            toggleExpand={toggleExpand}
            activeItem={activeItem}
            setActiveItem={handleSetActiveItem}
            parentRubroId={null}
          />
        ))}
      </nav>
    </aside>
  )
}
