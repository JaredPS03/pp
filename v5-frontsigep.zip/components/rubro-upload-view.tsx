"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Upload, Plus, Trash2, FileText, CheckCircle2, AlertCircle, Info, Send } from "lucide-react"

interface UploadedFile {
  id: string
  name: string
  size: string
  isAdditional?: boolean
}

interface RubroUploadViewProps {
  rubroId: string
  title: string
  description: string
  category: string
}

export function RubroUploadView({ rubroId, title, description, category }: RubroUploadViewProps) {
  const [files, setFiles] = useState<UploadedFile[]>([])
  const [additionalFiles, setAdditionalFiles] = useState<UploadedFile[]>([])
  const [comments, setComments] = useState("")
  const [expectedScore, setExpectedScore] = useState("")
  const [acceptTerms, setAcceptTerms] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitSuccess, setSubmitSuccess] = useState(false)

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, isAdditional = false) => {
    const uploadedFiles = e.target.files
    if (uploadedFiles && uploadedFiles.length > 0) {
      const newFiles: UploadedFile[] = Array.from(uploadedFiles).map((file, index) => ({
        id: `${Date.now()}-${index}`,
        name: file.name,
        size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
        isAdditional,
      }))

      if (isAdditional) {
        setAdditionalFiles((prev) => [...prev, ...newFiles])
      } else {
        setFiles((prev) => [...prev, ...newFiles])
      }
    }
    // Reset input
    e.target.value = ""
  }

  const handleRemoveFile = (id: string, isAdditional = false) => {
    if (isAdditional) {
      setAdditionalFiles((prev) => prev.filter((f) => f.id !== id))
    } else {
      setFiles((prev) => prev.filter((f) => f.id !== id))
    }
  }

  const handleSubmit = async () => {
    if (!acceptTerms || files.length === 0) return

    setIsSubmitting(true)
    // Simular envío
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsSubmitting(false)
    setSubmitSuccess(true)
  }

  const canSubmit = files.length > 0 && acceptTerms

  if (submitSuccess) {
    return (
      <div className="space-y-6">
        <Card className="border-2 border-green-200 bg-green-50">
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                <CheckCircle2 className="h-8 w-8 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-green-800 mb-2">Evidencia Enviada Exitosamente</h2>
              <p className="text-green-700 mb-6">
                Su documentación para "{title}" ha sido recibida y está pendiente de revisión.
              </p>
              <Button
                onClick={() => {
                  setSubmitSuccess(false)
                  setFiles([])
                  setAdditionalFiles([])
                  setComments("")
                  setExpectedScore("")
                  setAcceptTerms(false)
                }}
                className="bg-[#002060] hover:bg-[#003399]"
              >
                Cargar Nueva Evidencia
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Badge className="bg-[#002060]/10 text-[#002060]">{category}</Badge>
        </div>
        <h1 className="text-2xl lg:text-3xl font-bold text-[#002060] mb-2">{title}</h1>
        <p className="text-muted-foreground text-base lg:text-lg">{description}</p>
      </div>

      {/* Main Upload Card */}
      <Card className="border-2 border-dashed border-[#002060]/30 hover:border-[#002060]/50 transition-colors">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Upload className="h-5 w-5 text-[#002060]" />
            Subir Archivo Principal
          </CardTitle>
          <CardDescription>Arrastre y suelte su archivo aquí o haga clic para seleccionar</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Upload Area */}
            <label className="block">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-[#002060] hover:bg-[#002060]/5 transition-all">
                <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-base font-medium text-muted-foreground mb-2">Haga clic para seleccionar archivo</p>
                <p className="text-sm text-muted-foreground">PDF, DOC, DOCX hasta 10MB</p>
                <input
                  type="file"
                  className="hidden"
                  accept=".pdf,.doc,.docx"
                  onChange={(e) => handleFileUpload(e, false)}
                  multiple
                />
              </div>
            </label>

            {/* Uploaded Files List */}
            {files.length > 0 && (
              <div className="space-y-2">
                <p className="font-medium text-sm text-muted-foreground">Archivos cargados:</p>
                {files.map((file) => (
                  <div key={file.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="bg-red-500/10 p-2 rounded">
                        <FileText className="h-5 w-5 text-red-500" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">{file.name}</p>
                        <p className="text-xs text-muted-foreground">{file.size}</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveFile(file.id, false)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Additional Files Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Plus className="h-5 w-5 text-[#FFC107]" />
            Agregar Elementos Adicionales
          </CardTitle>
          <CardDescription>Si necesita agregar documentos complementarios, utilice esta sección</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <label className="block">
              <Button variant="outline" className="w-full border-dashed bg-transparent" asChild>
                <span className="cursor-pointer">
                  <Plus className="h-4 w-4 mr-2" />
                  Agregar Archivo Adicional
                  <input
                    type="file"
                    className="hidden"
                    accept=".pdf,.doc,.docx"
                    onChange={(e) => handleFileUpload(e, true)}
                    multiple
                  />
                </span>
              </Button>
            </label>

            {/* Additional Files List */}
            {additionalFiles.length > 0 && (
              <div className="space-y-2 mt-4">
                <p className="font-medium text-sm text-muted-foreground">Archivos adicionales:</p>
                {additionalFiles.map((file) => (
                  <div
                    key={file.id}
                    className="flex items-center justify-between p-3 bg-amber-50 border border-amber-200 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="bg-amber-100 text-amber-700 border-amber-300">
                        Adicional
                      </Badge>
                      <div className="bg-amber-500/10 p-2 rounded">
                        <FileText className="h-5 w-5 text-amber-600" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">{file.name}</p>
                        <p className="text-xs text-muted-foreground">{file.size}</p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveFile(file.id, true)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Comments and Score Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Información Adicional</CardTitle>
        </CardHeader>
        <CardContent>
          {/* Comments and Expected Score now are side by side */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Comments */}
            <div className="space-y-2">
              <Label htmlFor="comments" className="text-base font-medium">
                Comentarios (opcional)
              </Label>
              <Textarea
                id="comments"
                placeholder="Agregue cualquier comentario o aclaración sobre la evidencia..."
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                className="min-h-[120px] resize-none"
              />
            </div>

            {/* Expected Score */}
            <div className="space-y-2">
              <Label htmlFor="expectedScore" className="text-base font-medium">
                Puntaje Esperado
              </Label>
              <p className="text-xs text-muted-foreground">El puntaje que el profesor espera obtener</p>
              <div className="flex items-center gap-3 mt-2">
                <Input
                  id="expectedScore"
                  type="number"
                  min="0"
                  max="100"
                  placeholder="Ej: 85"
                  value={expectedScore}
                  onChange={(e) => setExpectedScore(e.target.value)}
                  className="w-full max-w-[150px]"
                />
                <span className="text-sm text-muted-foreground">puntos</span>
              </div>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-2">
                <Info className="h-3 w-3" />
                Será validado por el comité evaluador
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Terms and Submit Card */}
      <Card className="border-[#002060]/20">
        <CardContent className="pt-6">
          <div className="space-y-6">
            {/* Terms Checkbox */}
            <div className="flex items-start gap-3 p-4 bg-muted/50 rounded-lg">
              <Checkbox
                id="terms"
                checked={acceptTerms}
                onCheckedChange={(checked) => setAcceptTerms(checked === true)}
                className="mt-1"
              />
              <div className="space-y-1">
                <Label htmlFor="terms" className="text-base font-medium cursor-pointer">
                  Acepto los Avisos y Términos Legales
                </Label>
                <p className="text-sm text-muted-foreground">
                  Declaro bajo protesta de decir verdad que la información y documentos proporcionados son verídicos y
                  pueden ser verificados por las autoridades correspondientes. Entiendo que cualquier falsedad puede
                  resultar en la anulación de mi participación.
                </p>
              </div>
            </div>

            {/* Validation Messages */}
            {!canSubmit && (
              <div className="flex items-center gap-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <AlertCircle className="h-5 w-5 text-amber-600 flex-shrink-0" />
                <p className="text-sm text-amber-800">
                  {files.length === 0
                    ? "Debe cargar al menos un archivo principal"
                    : "Debe aceptar los términos y condiciones"}
                </p>
              </div>
            )}

            {/* Submit Button */}
            <Button
              onClick={handleSubmit}
              disabled={!canSubmit || isSubmitting}
              size="lg"
              className="w-full bg-[#002060] hover:bg-[#003399] text-lg py-6"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2" />
                  Enviando...
                </>
              ) : (
                <>
                  <Send className="h-5 w-5 mr-2" />
                  Enviar Evidencia
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
