"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileText, Upload, Eye, Trash2, CheckCircle2, Clock, Info } from "lucide-react"
import { UploadModal } from "@/components/upload-modal"
import { Badge } from "@/components/ui/badge"

interface Document {
  id: string
  name: string
  date: string
  status: "validado" | "pendiente" | "rechazado"
  subcategory: string
}

const subcategories = [
  { id: "colegiados", label: "4.1 Cuerpos Colegiados", description: "Participación en consejos y comités" },
  { id: "comisiones", label: "4.2 Comisiones Dictaminadoras", description: "Constancias de participación" },
  { id: "academicos", label: "4.3 Cuerpos Académicos", description: "Registro PRODEP y constancias CA" },
  { id: "eventos", label: "4.4 Organización de Eventos", description: "Constancias de organización" },
]

const mockDocuments: Document[] = [
  { id: "1", name: "Acta_Consejo_Tecnico.pdf", date: "2024-01-16", status: "validado", subcategory: "colegiados" },
  {
    id: "2",
    name: "Constancia_Comision_ESDEPED.pdf",
    date: "2024-01-11",
    status: "validado",
    subcategory: "comisiones",
  },
  { id: "3", name: "Registro_CA_PRODEP.pdf", date: "2024-01-08", status: "pendiente", subcategory: "academicos" },
]

export function GestionView() {
  const [documents, setDocuments] = useState<Document[]>(mockDocuments)
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("colegiados")
  const [uploadSubcategory, setUploadSubcategory] = useState("")

  const handleDelete = (id: string) => {
    setDocuments(documents.filter((doc) => doc.id !== id))
  }

  const handleUploadClick = (subcategory: string) => {
    setUploadSubcategory(subcategory)
    setIsUploadModalOpen(true)
  }

  const getSubcategoryDocuments = (subcategoryId: string) => {
    return documents.filter((doc) => doc.subcategory === subcategoryId)
  }

  const getSubcategoryProgress = (subcategoryId: string) => {
    const docs = getSubcategoryDocuments(subcategoryId)
    const validated = docs.filter((d) => d.status === "validado").length
    return { total: docs.length, validated }
  }

  const getStatusBadge = (status: Document["status"]) => {
    switch (status) {
      case "validado":
        return (
          <Badge className="bg-[#10B981]/10 text-[#10B981]">
            <CheckCircle2 className="h-3 w-3 mr-1" />
            Validado
          </Badge>
        )
      case "pendiente":
        return (
          <Badge className="bg-[#FFC107]/10 text-[#FFC107]">
            <Clock className="h-3 w-3 mr-1" />
            Pendiente
          </Badge>
        )
      case "rechazado":
        return (
          <Badge className="bg-red-500/10 text-red-500">
            <Info className="h-3 w-3 mr-1" />
            Rechazado
          </Badge>
        )
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold text-[#002060] mb-2">4. Gestión</h1>
        <p className="text-muted-foreground text-base lg:text-lg">
          Actividades administrativas, comisiones y servicios institucionales
        </p>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="flex flex-wrap h-auto gap-2 bg-white p-2 rounded-lg shadow-sm">
          {subcategories.map((sub) => {
            const progress = getSubcategoryProgress(sub.id)
            return (
              <TabsTrigger
                key={sub.id}
                value={sub.id}
                className="flex-1 min-w-[160px] data-[state=active]:bg-[#002060] data-[state=active]:text-white py-3 px-4"
              >
                <span className="text-sm font-medium">
                  {sub.label.split(" ")[0]} {sub.label.split(" ")[1]}
                </span>
                {progress.total > 0 && (
                  <span className="ml-2 text-xs opacity-70">
                    ({progress.validated}/{progress.total})
                  </span>
                )}
              </TabsTrigger>
            )
          })}
        </TabsList>

        {subcategories.map((sub) => (
          <TabsContent key={sub.id} value={sub.id} className="space-y-6">
            {/* Subcategory Info Card */}
            <Card className="border-l-4 border-l-[#FFC107]">
              <CardContent className="pt-6">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <h2 className="text-xl font-bold text-[#002060]">{sub.label}</h2>
                    <p className="text-muted-foreground">{sub.description}</p>
                  </div>
                  <Button
                    onClick={() => handleUploadClick(sub.id)}
                    size="lg"
                    className="bg-[#002060] hover:bg-[#003399]"
                  >
                    <Upload className="mr-2 h-5 w-5" />
                    Subir Evidencia
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Documents Table */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Documentos Cargados</CardTitle>
              </CardHeader>
              <CardContent>
                {getSubcategoryDocuments(sub.id).length === 0 ? (
                  <div className="text-center py-12 bg-muted/30 rounded-lg">
                    <Upload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                    <p className="text-lg font-medium text-muted-foreground">No hay documentos cargados</p>
                    <p className="text-sm text-muted-foreground mb-4">Suba su primera evidencia para este rubro</p>
                    <Button onClick={() => handleUploadClick(sub.id)} variant="outline">
                      <Upload className="mr-2 h-4 w-4" />
                      Subir Documento
                    </Button>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b-2 border-border">
                          <th className="text-left py-4 px-4 font-semibold">Archivo</th>
                          <th className="text-left py-4 px-4 font-semibold">Fecha</th>
                          <th className="text-left py-4 px-4 font-semibold">Estado</th>
                          <th className="text-right py-4 px-4 font-semibold">Acciones</th>
                        </tr>
                      </thead>
                      <tbody>
                        {getSubcategoryDocuments(sub.id).map((doc) => (
                          <tr key={doc.id} className="border-b last:border-0 hover:bg-muted/50">
                            <td className="py-4 px-4">
                              <div className="flex items-center gap-3">
                                <div className="bg-red-500/10 p-2 rounded">
                                  <FileText className="h-5 w-5 text-red-500" />
                                </div>
                                <span className="font-medium">{doc.name}</span>
                              </div>
                            </td>
                            <td className="py-4 px-4 text-muted-foreground">{doc.date}</td>
                            <td className="py-4 px-4">{getStatusBadge(doc.status)}</td>
                            <td className="py-4 px-4">
                              <div className="flex items-center justify-end gap-2">
                                <Button variant="outline" size="sm">
                                  <Eye className="h-4 w-4 mr-1" />
                                  Ver
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleDelete(doc.id)}
                                  className="text-destructive hover:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>

      {/* Upload Modal */}
      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        category={`Gestión - ${subcategories.find((s) => s.id === uploadSubcategory)?.label || ""}`}
        onUpload={(file) => {
          const newDoc: Document = {
            id: String(documents.length + 1),
            name: file.name,
            date: new Date().toISOString().split("T")[0],
            status: "pendiente",
            subcategory: uploadSubcategory,
          }
          setDocuments([...documents, newDoc])
          setIsUploadModalOpen(false)
        }}
      />
    </div>
  )
}
