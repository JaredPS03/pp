"use client"

import type React from "react"
import { useState, useRef } from "react"
import { FileText, Upload, Trash2, CheckCircle2, Plus, File, Globe, Flag } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import type { RequirementItem } from "@/types/evaluation"

interface DocumentUploaderCardProps {
  requirement: RequirementItem
  onMainFileUpload: (id: string, file: File) => void
  onComplementaryUpload: (id: string, file: File) => void
  onRemoveFile: (requirementId: string, fileId: string, type: "main" | "complementary") => void
  onToggleNational?: (id: string, isNational: boolean) => void
  onForeignFieldChange?: (id: string, field: "country" | "validationNumber", value: string) => void
}

function DocumentUploaderCard({
  requirement,
  onMainFileUpload,
  onComplementaryUpload,
  onRemoveFile,
  onToggleNational,
  onForeignFieldChange,
}: DocumentUploaderCardProps) {
  const mainInputRef = useRef<HTMLInputElement>(null)
  const complementaryInputRef = useRef<HTMLInputElement>(null)
  const [isDragging, setIsDragging] = useState(false)

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) {
      onMainFileUpload(requirement.id, file)
    }
  }

  const handleMainFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      onMainFileUpload(requirement.id, file)
    }
    e.target.value = ""
  }

  const handleComplementaryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      onComplementaryUpload(requirement.id, file)
    }
    e.target.value = ""
  }

  return (
    <Card
      className={cn(
        "border-2 transition-all duration-200",
        requirement.mainFile ? "border-emerald-300 bg-emerald-50/30" : "border-gray-200 hover:border-violet-300",
        isDragging && "border-violet-500 bg-violet-50",
      )}
    >
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between text-base">
          <span className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-violet-600" />
            {requirement.title}
            {requirement.isRequired && <span className="text-red-500 text-sm">*</span>}
          </span>
          {requirement.mainFile && <CheckCircle2 className="h-5 w-5 text-emerald-500" />}
        </CardTitle>
        <p className="text-sm text-gray-500">{requirement.description}</p>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* National/Foreign Toggle */}
        {requirement.hasNationalForeignToggle && (
          <div className="space-y-3">
            <div className="flex items-center gap-4">
              <button
                onClick={() => onToggleNational?.(requirement.id, true)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg border-2 transition-all",
                  requirement.isNational
                    ? "border-violet-500 bg-violet-50 text-violet-700"
                    : "border-gray-200 text-gray-500 hover:border-gray-300",
                )}
              >
                <Flag className="h-4 w-4" />
                Nacional
              </button>
              <button
                onClick={() => onToggleNational?.(requirement.id, false)}
                className={cn(
                  "flex items-center gap-2 px-4 py-2 rounded-lg border-2 transition-all",
                  !requirement.isNational
                    ? "border-violet-500 bg-violet-50 text-violet-700"
                    : "border-gray-200 text-gray-500 hover:border-gray-300",
                )}
              >
                <Globe className="h-4 w-4" />
                Extranjero
              </button>
            </div>

            {!requirement.isNational && (
              <div className="grid grid-cols-2 gap-3 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <div>
                  <Label className="text-xs text-amber-700">País de origen</Label>
                  <Input
                    placeholder="Ej: Estados Unidos"
                    value={requirement.foreignFields?.country || ""}
                    onChange={(e) => onForeignFieldChange?.(requirement.id, "country", e.target.value)}
                    className="mt-1 h-9 text-sm"
                  />
                </div>
                <div>
                  <Label className="text-xs text-amber-700">No. de Validación SEP</Label>
                  <Input
                    placeholder="Ej: 12345678"
                    value={requirement.foreignFields?.validationNumber || ""}
                    onChange={(e) => onForeignFieldChange?.(requirement.id, "validationNumber", e.target.value)}
                    className="mt-1 h-9 text-sm"
                  />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Main file upload area */}
        <div
          className={cn(
            "border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all",
            isDragging
              ? "border-violet-500 bg-violet-50"
              : requirement.mainFile
                ? "border-emerald-300 bg-emerald-50"
                : "border-gray-300 hover:border-violet-300 hover:bg-violet-50/50",
          )}
          onClick={() => mainInputRef.current?.click()}
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
        >
          <input
            ref={mainInputRef}
            type="file"
            className="hidden"
            accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
            onChange={handleMainFileChange}
          />

          {requirement.mainFile ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                  <File className="h-5 w-5 text-emerald-600" />
                </div>
                <div className="text-left">
                  <p className="font-medium text-gray-800 text-sm">{requirement.mainFile.name}</p>
                  <p className="text-xs text-gray-500">{requirement.mainFile.size}</p>
                </div>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  onRemoveFile(requirement.id, requirement.mainFile!.id, "main")
                }}
                className="p-2 hover:bg-red-50 rounded-lg transition-colors"
              >
                <Trash2 className="h-4 w-4 text-red-500" />
              </button>
            </div>
          ) : (
            <>
              <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
              <p className="text-sm font-medium text-gray-700">Arrastre o haga clic para subir</p>
              <p className="text-xs text-gray-500 mt-1">PDF, Word, JPG o PNG (máx. 10MB)</p>
            </>
          )}
        </div>

        {/* Complementary files section */}
        <div className="space-y-2">
          <button
            onClick={() => complementaryInputRef.current?.click()}
            className="flex items-center gap-2 text-sm text-violet-600 hover:text-violet-700 transition-colors"
          >
            <Plus className="h-4 w-4" />
            Agregar archivo complementario
          </button>
          <input
            ref={complementaryInputRef}
            type="file"
            className="hidden"
            accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
            onChange={handleComplementaryChange}
          />

          {requirement.complementaryFiles.length > 0 && (
            <div className="space-y-1 mt-2">
              {requirement.complementaryFiles.map((file) => (
                <div key={file.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg border">
                  <div className="flex items-center gap-2">
                    <File className="h-4 w-4 text-gray-400" />
                    <span className="text-sm text-gray-700 truncate max-w-[150px]">{file.name}</span>
                    <Badge variant="secondary" className="text-xs">
                      Complementario
                    </Badge>
                  </div>
                  <button
                    onClick={() => onRemoveFile(requirement.id, file.id, "complementary")}
                    className="p-1 hover:bg-red-50 rounded transition-colors"
                  >
                    <Trash2 className="h-3 w-3 text-red-500" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

interface RubricUploadGridProps {
  requirements: RequirementItem[]
  onMainFileUpload: (id: string, file: File) => void
  onComplementaryUpload: (id: string, file: File) => void
  onRemoveFile: (requirementId: string, fileId: string, type: "main" | "complementary") => void
  onToggleNational?: (id: string, isNational: boolean) => void
  onForeignFieldChange?: (id: string, field: "country" | "validationNumber", value: string) => void
}

export function RubricUploadGrid({
  requirements,
  onMainFileUpload,
  onComplementaryUpload,
  onRemoveFile,
  onToggleNational,
  onForeignFieldChange,
}: RubricUploadGridProps) {
  return (
    <div>
      <h2 className="text-lg font-semibold text-gray-800 mb-4">Documentos Requeridos</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {requirements.map((req) => (
          <DocumentUploaderCard
            key={req.id}
            requirement={req}
            onMainFileUpload={onMainFileUpload}
            onComplementaryUpload={onComplementaryUpload}
            onRemoveFile={onRemoveFile}
            onToggleNational={onToggleNational}
            onForeignFieldChange={onForeignFieldChange}
          />
        ))}
      </div>
    </div>
  )
}
