"use client"

import { CheckCircle2, AlertCircle, Eye, Trash2, ChevronRight, ChevronLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { File } from "lucide-react"
import type { RequirementItem, ConfirmationChecklist, EvaluationRubric } from "@/types/evaluation"

interface RubricSummaryFooterProps {
  rubric: EvaluationRubric
  requirements: RequirementItem[]
  confirmations: ConfirmationChecklist
  onConfirmationChange: (key: keyof ConfirmationChecklist, value: boolean) => void
  onRemoveFile: (requirementId: string, fileId: string, type: "main" | "complementary") => void
  onNavigateNext?: () => void
  onNavigatePrev?: () => void
  canProceed: boolean
  // Optional scoring fields
  expectedScore?: string
  onExpectedScoreChange?: (value: string) => void
  comments?: string
  onCommentsChange?: (value: string) => void
}

export function RubricSummaryFooter({
  rubric,
  requirements,
  confirmations,
  onConfirmationChange,
  onRemoveFile,
  onNavigateNext,
  onNavigatePrev,
  canProceed,
  expectedScore = "",
  onExpectedScoreChange,
  comments = "",
  onCommentsChange,
}: RubricSummaryFooterProps) {
  const showScoring = rubric.sectionType === "rubric" && rubric.scoring

  return (
    <div className="space-y-6">
      {/* Comments section - only for rubric type */}
      {showScoring && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gray-200 text-gray-600 flex items-center justify-center font-bold text-lg">
              1
            </div>
            <h2 className="text-xl font-semibold text-gray-800">
              Comentarios <span className="text-gray-400 font-normal">(opcional)</span>
            </h2>
          </div>
          <Textarea
            placeholder="Si desea agregar alguna nota sobre sus documentos, escríbala aquí..."
            value={comments}
            onChange={(e) => onCommentsChange?.(e.target.value)}
            className="min-h-[100px] resize-none"
          />
        </div>
      )}

      {/* Expected score - only for rubric type */}
      {showScoring && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gray-200 text-gray-600 flex items-center justify-center font-bold text-lg">
              2
            </div>
            <h2 className="text-xl font-semibold text-gray-800">Puntaje Auto-Evaluado Esperado</h2>
          </div>
          <div className="bg-gray-50 border border-gray-200 rounded-xl p-4">
            <Input
              type="number"
              placeholder={`Ingrese su puntaje esperado (${rubric.scoring!.minScore} - ${rubric.scoring!.maxScore})`}
              value={expectedScore}
              onChange={(e) => onExpectedScoreChange?.(e.target.value)}
              className="h-12 text-lg font-semibold bg-white"
              min={rubric.scoring!.minScore}
              max={rubric.scoring!.maxScore}
            />
            <p className="text-xs text-gray-500 mt-2">Este valor será validado por el comité evaluador.</p>
          </div>
        </div>
      )}

      {/* Summary Table */}
      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
        <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-gray-800">Resumen de Documentos</h2>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[200px]">Requisito</TableHead>
              <TableHead>Archivo Principal</TableHead>
              <TableHead>Archivos Complementarios</TableHead>
              <TableHead className="w-[100px]">Estado</TableHead>
              <TableHead className="w-[100px] text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {requirements.map((req) => (
              <TableRow key={req.id}>
                <TableCell className="font-medium">{req.title}</TableCell>
                <TableCell>
                  {req.mainFile ? (
                    <div className="flex items-center gap-2">
                      <File className="h-4 w-4 text-emerald-500" />
                      <span className="text-sm truncate max-w-[150px]">{req.mainFile.name}</span>
                    </div>
                  ) : (
                    <span className="text-gray-400 text-sm">Sin archivo</span>
                  )}
                </TableCell>
                <TableCell>
                  {req.complementaryFiles.length > 0 ? (
                    <div className="flex flex-wrap gap-1">
                      {req.complementaryFiles.map((f) => (
                        <Badge key={f.id} variant="secondary" className="text-xs">
                          {f.name.length > 15 ? f.name.substring(0, 15) + "..." : f.name}
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <span className="text-gray-400 text-sm">—</span>
                  )}
                </TableCell>
                <TableCell>
                  {req.mainFile ? (
                    <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
                      <CheckCircle2 className="h-3 w-3 mr-1" />
                      Cargado
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-amber-600 border-amber-300">
                      <AlertCircle className="h-3 w-3 mr-1" />
                      Pendiente
                    </Badge>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex items-center justify-end gap-1">
                    {req.mainFile && (
                      <>
                        <button className="p-1.5 hover:bg-gray-100 rounded transition-colors">
                          <Eye className="h-4 w-4 text-gray-500" />
                        </button>
                        <button
                          onClick={() => onRemoveFile(req.id, req.mainFile!.id, "main")}
                          className="p-1.5 hover:bg-red-50 rounded transition-colors"
                        >
                          <Trash2 className="h-4 w-4 text-red-500" />
                        </button>
                      </>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Confirmation Checklist */}
      <div className="bg-amber-50 border-2 border-amber-200 rounded-xl p-6 space-y-4">
        <h3 className="font-semibold text-amber-800 flex items-center gap-2">
          <CheckCircle2 className="h-5 w-5" />
          Confirmación de Carga
        </h3>
        <div className="space-y-3">
          <div className="flex items-start gap-3 bg-white p-4 rounded-lg border-2 border-amber-300">
            <Checkbox
              id="documentsComplete"
              checked={confirmations.documentsComplete}
              onCheckedChange={(checked) => onConfirmationChange("documentsComplete", checked as boolean)}
              className="mt-0.5 h-5 w-5 border-2 border-amber-500 data-[state=checked]:bg-amber-500 data-[state=checked]:border-amber-500"
            />
            <Label htmlFor="documentsComplete" className="text-sm text-gray-700 cursor-pointer leading-relaxed">
              Confirmo que he adjuntado todos los documentos requeridos y que están completos.
            </Label>
          </div>

          <div className="flex items-start gap-3 bg-white p-4 rounded-lg border-2 border-amber-300">
            <Checkbox
              id="infoAccurate"
              checked={confirmations.infoAccurate}
              onCheckedChange={(checked) => onConfirmationChange("infoAccurate", checked as boolean)}
              className="mt-0.5 h-5 w-5 border-2 border-amber-500 data-[state=checked]:bg-amber-500 data-[state=checked]:border-amber-500"
            />
            <Label htmlFor="infoAccurate" className="text-sm text-gray-700 cursor-pointer leading-relaxed">
              Confirmo que la información proporcionada es veraz y corresponde a mi expediente académico.
            </Label>
          </div>

          <div className="flex items-start gap-3 bg-white p-4 rounded-lg border-2 border-amber-300">
            <Checkbox
              id="acceptTerms"
              checked={confirmations.acceptTerms}
              onCheckedChange={(checked) => onConfirmationChange("acceptTerms", checked as boolean)}
              className="mt-0.5 h-5 w-5 border-2 border-amber-500 data-[state=checked]:bg-amber-500 data-[state=checked]:border-amber-500"
            />
            <Label htmlFor="acceptTerms" className="text-sm text-gray-700 cursor-pointer leading-relaxed">
              Entiendo que cualquier falsedad en la documentación puede resultar en la anulación de mi participación.
            </Label>
          </div>
        </div>
      </div>

      {/* Navigation buttons */}
      <div className="flex items-center justify-between pt-4">
        {rubric.prevRubricId ? (
          <Button variant="outline" onClick={onNavigatePrev} className="gap-2 bg-transparent">
            <ChevronLeft className="h-4 w-4" />
            {rubric.prevRubricTitle || "Anterior"}
          </Button>
        ) : (
          <div />
        )}

        {rubric.nextRubricId && (
          <Button
            onClick={onNavigateNext}
            disabled={!canProceed}
            className="bg-[#002060] hover:bg-[#003399] text-white gap-2 px-6 py-3 h-auto"
          >
            Siguiente Paso
            <ChevronRight className="h-5 w-5" />
          </Button>
        )}
      </div>
    </div>
  )
}
