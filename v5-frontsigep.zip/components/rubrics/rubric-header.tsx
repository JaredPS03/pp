"use client"

import { Badge } from "@/components/ui/badge"
import { CircleHelp } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import type { EvaluationRubric } from "@/types/evaluation"

interface RubricHeaderProps {
  rubric: EvaluationRubric
  expectedScore?: string
  onExpectedScoreChange?: (value: string) => void
  comments?: string
  onCommentsChange?: (value: string) => void
}

export function RubricHeader({
  rubric,
  expectedScore = "",
  onExpectedScoreChange,
  comments = "",
  onCommentsChange,
}: RubricHeaderProps) {
  const showScoring = rubric.sectionType === "rubric" && rubric.scoring

  return (
    <div className="sticky top-0 z-10 bg-white border-b border-gray-200">
      {/* Title row */}
      <div className="px-6 py-4 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3">
            {rubric.code !== "0" && (
              <Badge variant="outline" className="bg-violet-50 text-violet-700 border-violet-200 font-mono">
                {rubric.code}
              </Badge>
            )}
            <h1 className="text-2xl font-bold text-[#002060]">{rubric.title}</h1>
          </div>
          {rubric.description && <p className="text-sm text-gray-500 mt-1">{rubric.description}</p>}
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
              <CircleHelp className="h-6 w-6 text-gray-400 hover:text-violet-600" />
            </button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Ayuda - {rubric.title}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 text-sm text-gray-600">
              <p>Suba los documentos requeridos para esta sección de evaluación.</p>
              <div className="space-y-2">
                <h4 className="font-semibold text-gray-800">Instrucciones:</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Suba cada documento en formato PDF, Word o imagen.</li>
                  <li>Puede agregar archivos complementarios si es necesario.</li>
                  <li>Confirme que la información es correcta antes de continuar.</li>
                  {showScoring && <li>Ingrese su puntaje auto-evaluado esperado.</li>}
                </ul>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Score badges row - only for rubric sections */}
      {showScoring && (
        <div className="px-6 py-3 bg-gradient-to-r from-violet-50 to-indigo-50 border-t border-violet-100 flex items-center gap-6">
          <div className="flex items-center gap-3">
            <Badge
              variant="outline"
              className="bg-gray-100 text-gray-700 border-gray-300 px-4 py-2 text-sm font-semibold"
            >
              Min: {rubric.scoring!.minScore}
            </Badge>
            <Badge
              variant="outline"
              className="bg-gray-100 text-gray-700 border-gray-300 px-4 py-2 text-sm font-semibold"
            >
              Max: {rubric.scoring!.maxScore}
            </Badge>
          </div>
        </div>
      )}
    </div>
  )
}
