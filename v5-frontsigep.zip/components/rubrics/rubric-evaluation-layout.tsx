"use client"

import { useState, useEffect, useRef } from "react"
import { RubricHeader } from "./rubric-header"
import { RubricUploadGrid } from "./rubric-upload-grid"
import { RubricSummaryFooter } from "./rubric-summary-footer"
import type { EvaluationRubric, RequirementItem, ConfirmationChecklist, UploadedFile } from "@/types/evaluation"

interface RubricEvaluationLayoutProps {
  rubricData: EvaluationRubric
  onNavigateNext?: () => void
  onNavigatePrev?: () => void
}

export function RubricEvaluationLayout({ rubricData, onNavigateNext, onNavigatePrev }: RubricEvaluationLayoutProps) {
  const containerRef = useRef<HTMLDivElement>(null)

  // State management
  const [requirements, setRequirements] = useState<RequirementItem[]>(rubricData.requirements)
  const [confirmations, setConfirmations] = useState<ConfirmationChecklist>({
    documentsComplete: false,
    infoAccurate: false,
    acceptTerms: false,
  })
  const [expectedScore, setExpectedScore] = useState("")
  const [comments, setComments] = useState("")

  // Reset state when rubricData changes
  useEffect(() => {
    setRequirements(rubricData.requirements)
    setConfirmations({ documentsComplete: false, infoAccurate: false, acceptTerms: false })
    setExpectedScore("")
    setComments("")

    // Scroll to top
    if (containerRef.current) {
      containerRef.current.scrollTo({ top: 0, behavior: "smooth" })
    }
  }, [rubricData.id])

  // File handlers
  const handleMainFileUpload = (requirementId: string, file: File) => {
    const newFile: UploadedFile = {
      id: `${Date.now()}`,
      name: file.name,
      size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
      type: "main",
    }
    setRequirements((prev) => prev.map((req) => (req.id === requirementId ? { ...req, mainFile: newFile } : req)))
  }

  const handleComplementaryUpload = (requirementId: string, file: File) => {
    const newFile: UploadedFile = {
      id: `${Date.now()}`,
      name: file.name,
      size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
      type: "complementary",
    }
    setRequirements((prev) =>
      prev.map((req) =>
        req.id === requirementId ? { ...req, complementaryFiles: [...req.complementaryFiles, newFile] } : req,
      ),
    )
  }

  const handleRemoveFile = (requirementId: string, fileId: string, type: "main" | "complementary") => {
    setRequirements((prev) =>
      prev.map((req) => {
        if (req.id !== requirementId) return req
        if (type === "main") {
          return { ...req, mainFile: null }
        }
        return { ...req, complementaryFiles: req.complementaryFiles.filter((f) => f.id !== fileId) }
      }),
    )
  }

  const handleToggleNational = (id: string, isNational: boolean) => {
    setRequirements((prev) => prev.map((req) => (req.id === id ? { ...req, isNational } : req)))
  }

  const handleForeignFieldChange = (id: string, field: "country" | "validationNumber", value: string) => {
    setRequirements((prev) =>
      prev.map((req) => (req.id === id ? { ...req, foreignFields: { ...req.foreignFields!, [field]: value } } : req)),
    )
  }

  const handleConfirmationChange = (key: keyof ConfirmationChecklist, value: boolean) => {
    setConfirmations((prev) => ({ ...prev, [key]: value }))
  }

  // Validation
  const allConfirmed = confirmations.documentsComplete && confirmations.infoAccurate && confirmations.acceptTerms
  const requiredFilesUploaded = requirements.filter((r) => r.isRequired).every((r) => r.mainFile)
  const canProceed = allConfirmed

  return (
    <div ref={containerRef} className="h-full overflow-y-auto">
      <RubricHeader rubric={rubricData} expectedScore={expectedScore} onExpectedScoreChange={setExpectedScore} />

      <div className="p-6 space-y-8">
        <RubricUploadGrid
          requirements={requirements}
          onMainFileUpload={handleMainFileUpload}
          onComplementaryUpload={handleComplementaryUpload}
          onRemoveFile={handleRemoveFile}
          onToggleNational={handleToggleNational}
          onForeignFieldChange={handleForeignFieldChange}
        />

        <RubricSummaryFooter
          rubric={rubricData}
          requirements={requirements}
          confirmations={confirmations}
          onConfirmationChange={handleConfirmationChange}
          onRemoveFile={handleRemoveFile}
          onNavigateNext={onNavigateNext}
          onNavigatePrev={onNavigatePrev}
          canProceed={canProceed}
          expectedScore={expectedScore}
          onExpectedScoreChange={setExpectedScore}
          comments={comments}
          onCommentsChange={setComments}
        />
      </div>
    </div>
  )
}
