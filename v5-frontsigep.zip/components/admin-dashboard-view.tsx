"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileCheck, Users, Clock, CheckCircle2, TrendingUp } from "lucide-react"

interface AdminDashboardViewProps {
  onNavigate: (view: string) => void
}

export function AdminDashboardView({ onNavigate }: AdminDashboardViewProps) {
  const stats = [
    {
      title: "Evidencias Pendientes",
      value: "47",
      icon: Clock,
      color: "text-[#FFC107]",
      bgColor: "bg-[#FFC107]/10",
      description: "Requieren revisión",
      action: () => onNavigate("admin-review"),
    },
    {
      title: "Evidencias Revisadas Hoy",
      value: "23",
      icon: CheckCircle2,
      color: "text-[#10B981]",
      bgColor: "bg-[#10B981]/10",
      description: "Aprobadas y rechazadas",
    },
    {
      title: "Total de Profesores",
      value: "156",
      icon: Users,
      color: "text-[#002060]",
      bgColor: "bg-[#002060]/10",
      description: "Usuarios activos",
      action: () => onNavigate("admin-users"),
    },
    {
      title: "Promedio de Completitud",
      value: "67%",
      icon: TrendingUp,
      color: "text-[#3B82F6]",
      bgColor: "bg-[#3B82F6]/10",
      description: "De todos los expedientes",
    },
  ]

  const recentSubmissions = [
    { profesor: "Dr. Juan Pérez", categoria: "Docencia", documento: "Programa_Matematicas.pdf", fecha: "Hace 5 min" },
    {
      profesor: "Dra. Ana López",
      categoria: "Investigación",
      documento: "Articulo_Publicado.pdf",
      fecha: "Hace 12 min",
    },
    { profesor: "Dr. Carlos Ruiz", categoria: "Tutorías", documento: "Lista_Tutorados.pdf", fecha: "Hace 25 min" },
    { profesor: "Dra. Laura Sánchez", categoria: "Gestión", documento: "Informe_Comision.pdf", fecha: "Hace 1 hora" },
  ]

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold text-[#002060] mb-2">Panel de Administración</h1>
        <p className="text-sm lg:text-base text-muted-foreground">Gestión y supervisión del sistema SIGEP</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon
          return (
            <Card
              key={index}
              className={`hover:shadow-lg transition-shadow ${stat.action ? "cursor-pointer" : ""}`}
              onClick={stat.action}
            >
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-xs lg:text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
                <div className={`${stat.bgColor} p-2 rounded-lg`}>
                  <Icon className={`h-4 lg:h-5 w-4 lg:w-5 ${stat.color}`} />
                </div>
              </CardHeader>
              <CardContent>
                <div className={`text-2xl lg:text-3xl font-bold ${stat.color} mb-1`}>{stat.value}</div>
                <p className="text-xs text-muted-foreground">{stat.description}</p>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Recent Submissions */}
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <CardTitle className="text-lg lg:text-xl">Envíos Recientes</CardTitle>
          <Button onClick={() => onNavigate("admin-review")} size="sm" className="bg-[#002060] hover:bg-[#003399]">
            Ver Todos
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentSubmissions.map((submission, index) => (
              <div
                key={index}
                className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 p-4 border rounded-lg hover:bg-muted/50"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-[#002060]/10 flex items-center justify-center flex-shrink-0">
                    <FileCheck className="h-5 w-5 text-[#002060]" />
                  </div>
                  <div className="min-w-0">
                    <p className="font-semibold text-sm lg:text-base">{submission.profesor}</p>
                    <p className="text-xs lg:text-sm text-muted-foreground truncate">
                      {submission.categoria} - {submission.documento}
                    </p>
                  </div>
                </div>
                <div className="flex items-center justify-between sm:flex-col sm:items-end gap-2">
                  <p className="text-xs lg:text-sm text-muted-foreground">{submission.fecha}</p>
                  <Button variant="outline" size="sm">
                    Revisar
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 lg:gap-6">
        <Card
          className="bg-gradient-to-br from-[#002060] to-[#003399] text-white cursor-pointer hover:shadow-lg transition-shadow"
          onClick={() => onNavigate("admin-review")}
        >
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-white text-lg lg:text-xl">
              <FileCheck className="h-5 lg:h-6 w-5 lg:w-6" />
              Revisar Evidencias
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm lg:text-base text-white/90">
              Revisa, aprueba o rechaza las evidencias enviadas por los profesores
            </p>
          </CardContent>
        </Card>

        <Card
          className="bg-gradient-to-br from-[#10B981] to-[#059669] text-white cursor-pointer hover:shadow-lg transition-shadow"
          onClick={() => onNavigate("admin-users")}
        >
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-white text-lg lg:text-xl">
              <Users className="h-5 lg:h-6 w-5 lg:w-6" />
              Gestionar Usuarios
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm lg:text-base text-white/90">
              Crea nuevos usuarios, asigna permisos y gestiona el acceso al sistema
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
