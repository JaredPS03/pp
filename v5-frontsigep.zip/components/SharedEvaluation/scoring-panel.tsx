"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import {
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  FileText,
  AlertCircle,
  Save,
  TrendingUp,
  TrendingDown,
  Target,
  Edit3,
  Check,
} from "lucide-react"
import { documentosProfesor } from "@/mocks/newRolesData"

interface ScoringPanelProps {
  selectedRubroId: string | null
  onNavigateNext: () => void
  onNavigatePrev: () => void
  hasNext: boolean
  hasPrev: boolean
  currentIndex: number
  totalItems: number
}

export function ScoringPanel({
  selectedRubroId,
  onNavigateNext,
  onNavigatePrev,
  hasNext,
  hasPrev,
  currentIndex,
  totalItems,
}: ScoringPanelProps) {
  const [scores, setScores] = useState<Record<string, number | "">>({})
  const [savedScores, setSavedScores] = useState<Record<string, number>>({})
  const [feedback, setFeedback] = useState("")
  const [savedFeedback, setSavedFeedback] = useState<Record<string, string>>({})
  const [showSaved, setShowSaved] = useState(false)
  const [isEditing, setIsEditing] = useState(false)

  const currentDocument = documentosProfesor.find((doc) => doc.rubroId === selectedRubroId)
  const currentScore = currentDocument ? (scores[currentDocument.id] ?? "") : ""
  const hasSavedScore = currentDocument && savedScores[currentDocument.id] !== undefined

  useEffect(() => {
    if (currentDocument) {
      if (savedScores[currentDocument.id] !== undefined) {
        setScores((prev) => ({ ...prev, [currentDocument.id]: savedScores[currentDocument.id] }))
      }
      if (savedFeedback[currentDocument.id]) {
        setFeedback(savedFeedback[currentDocument.id])
      } else {
        setFeedback("")
      }
    }
    setIsEditing(false)
    setShowSaved(false)
  }, [selectedRubroId]) // Updated dependency to selectedRubroId

  const handleScoreChange = (value: string) => {
    if (currentDocument) {
      if (value === "") {
        setScores((prev) => ({ ...prev, [currentDocument.id]: "" }))
      } else {
        const numValue = Number.parseInt(value) || 0
        setScores((prev) => ({ ...prev, [currentDocument.id]: numValue }))
      }
    }
  }

  const handleSave = useCallback(() => {
    if (currentDocument && currentScore !== "") {
      const min = currentDocument.puntosMin || 0
      const max = currentDocument.puntosMax || 100
      const clampedValue = Math.min(Math.max(Number(currentScore), min), max)

      setSavedScores((prev) => ({ ...prev, [currentDocument.id]: clampedValue }))
      setScores((prev) => ({ ...prev, [currentDocument.id]: clampedValue }))
      setSavedFeedback((prev) => ({ ...prev, [currentDocument.id]: feedback }))
      setShowSaved(true)
      setIsEditing(false)
      setTimeout(() => setShowSaved(false), 2000)
    }
  }, [currentDocument, currentScore, feedback])

  const handleEdit = () => {
    setIsEditing(true)
    setShowSaved(false)
  }

  return (
    <div className="h-full flex">
      {/* PDF Viewer */}
      <div className="flex-1 flex flex-col bg-gray-50 min-w-0">
        {/* Document header */}
        <div className="flex-shrink-0 bg-white border-b px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="h-9 w-9 rounded-lg bg-[#002060]/10 flex items-center justify-center flex-shrink-0">
              <FileText className="h-5 w-5 text-[#002060]" />
            </div>
            <div className="min-w-0">
              <h3 className="font-semibold text-[#002060] text-sm truncate">
                {currentDocument?.rubroNombre || "Seleccione un documento"}
              </h3>
              {currentDocument && <p className="text-xs text-muted-foreground truncate">{currentDocument.nombre}</p>}
            </div>
          </div>
          {hasSavedScore && !isEditing && (
            <Badge className="text-xs px-2 py-1 bg-emerald-100 text-emerald-700 border border-emerald-300 flex-shrink-0 font-medium">
              <CheckCircle2 className="h-3 w-3 mr-1" />
              Calificado
            </Badge>
          )}
        </div>

        {/* PDF Preview */}
        <div className="flex-1 flex items-center justify-center p-4">
          {currentDocument ? (
            <div className="w-full h-full bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col items-center justify-center">
              <FileText className="h-20 w-20 text-gray-300 mb-4" />
              <p className="text-gray-700 font-medium text-lg text-center px-4">{currentDocument.nombre}</p>
              <p className="text-gray-400 text-sm mt-2">Vista previa del documento</p>
              {currentDocument.fechaSubida && (
                <p className="text-xs text-gray-400 mt-3">Subido: {currentDocument.fechaSubida}</p>
              )}
            </div>
          ) : (
            <div className="text-center text-gray-400">
              <AlertCircle className="h-16 w-16 mx-auto mb-3 opacity-50" />
              <p className="text-lg font-medium">Seleccione un documento del menú</p>
            </div>
          )}
        </div>

        {/* Navigation footer */}
        <div className="flex-shrink-0 bg-white border-t px-4 py-2 flex items-center justify-between">
          <Button
            variant="outline"
            size="sm"
            onClick={onNavigatePrev}
            disabled={!hasPrev}
            className="gap-1 bg-transparent"
          >
            <ChevronLeft className="h-4 w-4" />
            Anterior
          </Button>
          <span className="text-xs text-muted-foreground">
            {currentIndex + 1} de {totalItems}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={onNavigateNext}
            disabled={!hasNext}
            className="gap-1 bg-transparent"
          >
            Siguiente
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="w-72 flex-shrink-0 bg-white border-l flex flex-col">
        {/* Header */}
        <div className="flex-shrink-0 px-4 py-3 bg-gradient-to-r from-[#002060] to-[#003380]">
          <h3 className="font-semibold text-white text-sm">Asignar Puntuación</h3>
        </div>

        {currentDocument ? (
          <div className="flex-1 p-3 flex flex-col gap-3">
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-2 text-center">
                <TrendingUp className="h-4 w-4 text-emerald-500 mx-auto" />
                <p className="text-[10px] text-emerald-600 font-medium">Máximo</p>
                <p className="text-lg font-bold text-emerald-700">{currentDocument.puntosMax || "N/A"}</p>
              </div>
              <div className="bg-red-50 border border-red-200 rounded-lg p-2 text-center">
                <TrendingDown className="h-4 w-4 text-red-500 mx-auto" />
                <p className="text-[10px] text-red-600 font-medium">Mínimo</p>
                <p className="text-lg font-bold text-red-700">{currentDocument.puntosMin || 0}</p>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-2 text-center">
                <Target className="h-4 w-4 text-blue-500 mx-auto" />
                <p className="text-[10px] text-blue-600 font-medium">Auto</p>
                <p className="text-lg font-bold text-blue-700">{currentDocument.puntosAutoevaluacion || "N/A"}</p>
              </div>
            </div>

            {hasSavedScore && !isEditing ? (
              <div className="bg-emerald-50 border-2 border-emerald-300 rounded-xl p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-emerald-700">Puntaje Asignado</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleEdit}
                    className="h-7 px-2 text-xs hover:bg-emerald-100"
                  >
                    <Edit3 className="h-3 w-3 mr-1" />
                    Editar
                  </Button>
                </div>
                <p className="text-4xl font-bold text-emerald-700 text-center">
                  {savedScores[currentDocument.id]}
                  <span className="text-lg font-normal text-emerald-600 ml-1">pts</span>
                </p>
                {savedFeedback[currentDocument.id] && (
                  <p className="text-xs text-gray-600 mt-2 italic text-center">"{savedFeedback[currentDocument.id]}"</p>
                )}
              </div>
            ) : (
              <>
                {/* Score input */}
                <div className="bg-[#FFC107]/10 border-2 border-[#FFC107] rounded-xl p-3">
                  <label className="text-sm font-bold text-[#002060] mb-2 block">Puntaje Final</label>
                  <Input
                    type="number"
                    min={currentDocument.puntosMin || 0}
                    max={currentDocument.puntosMax || 100}
                    value={currentScore}
                    onChange={(e) => handleScoreChange(e.target.value)}
                    placeholder="Ingrese puntos"
                    className="h-14 text-2xl font-bold text-center text-[#002060] border-2 focus:border-[#002060]"
                    aria-label={`Puntaje para ${currentDocument.rubroNombre}`}
                  />
                  <p className="text-xs text-gray-500 mt-2 text-center">
                    Rango permitido: {currentDocument.puntosMin || 0} - {currentDocument.puntosMax || 100}
                  </p>
                </div>

                <Button
                  onClick={handleSave}
                  className="w-full h-12 text-base font-bold bg-[#002060] hover:bg-[#003399] gap-2 shadow-md transition-all hover:scale-[1.02]"
                  disabled={currentScore === ""}
                >
                  <Save className="h-5 w-5" />
                  GUARDAR CALIFICACIÓN
                </Button>

                {/* Comments - compact */}
                <div className="flex-1 flex flex-col">
                  <label className="text-xs font-semibold text-gray-600 mb-1">Observaciones (opcional)</label>
                  <Textarea
                    placeholder="Escriba sus observaciones..."
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    className="flex-1 min-h-[60px] resize-none text-sm border-2 focus:border-[#002060]"
                  />
                </div>

                {isEditing && (
                  <Button variant="outline" size="sm" onClick={() => setIsEditing(false)} className="w-full">
                    Cancelar edición
                  </Button>
                )}
              </>
            )}

            {showSaved && (
              <div className="bg-emerald-100 border border-emerald-300 rounded-lg p-2 flex items-center gap-2 animate-in fade-in slide-in-from-top-2 duration-200">
                <Check className="h-4 w-4 text-emerald-600" />
                <span className="text-xs font-medium text-emerald-700">Calificación guardada</span>
              </div>
            )}
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center text-center text-gray-400 p-4">
            <div>
              <FileText className="h-12 w-12 mx-auto mb-2 opacity-30" />
              <p className="text-sm">Seleccione un documento</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
