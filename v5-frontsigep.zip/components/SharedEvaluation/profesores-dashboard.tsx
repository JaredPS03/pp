"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Search,
  ChevronLeft,
  ChevronRight,
  Eye,
  ArrowLeft,
  Users,
  CheckCircle2,
  Clock,
  AlertCircle,
  FileText,
} from "lucide-react"
import type { ProfesorEvaluacion, Convocatoria } from "@/mocks/newRolesData"

interface ProfesoresDashboardProps {
  convocatoria: Convocatoria
  profesores: ProfesorEvaluacion[]
  onSelectProfesor: (profesor: ProfesorEvaluacion) => void
  onBack: () => void
  userType: "ev_fac" | "ev_com"
}

export function ProfesoresDashboard({
  convocatoria,
  profesores,
  onSelectProfesor,
  onBack,
  userType,
}: ProfesoresDashboardProps) {
  const [searchTerm, setSearchTerm] = useState("")
  const [currentPage, setCurrentPage] = useState(1)
  const [filterStatus, setFilterStatus] = useState<"todos" | "pendiente" | "en_revision" | "revisado">("todos")
  const itemsPerPage = 5

  const filteredProfesores = profesores.filter((p) => {
    const matchesSearch =
      p.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.facultad.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.rfc.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter = filterStatus === "todos" || p.status === filterStatus
    return matchesSearch && matchesFilter
  })

  const totalPages = Math.ceil(filteredProfesores.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const paginatedProfesores = filteredProfesores.slice(startIndex, startIndex + itemsPerPage)

  const statusCounts = {
    pendiente: profesores.filter((p) => p.status === "pendiente").length,
    en_revision: profesores.filter((p) => p.status === "en_revision").length,
    revisado: profesores.filter((p) => p.status === "revisado").length,
  }

  const getStatusBadge = (status: ProfesorEvaluacion["status"]) => {
    switch (status) {
      case "revisado":
        return (
          <Badge className="bg-emerald-100 text-emerald-700 border-emerald-300 gap-1 text-sm px-3 py-1 font-semibold">
            <CheckCircle2 className="h-4 w-4" />
            Revisado
          </Badge>
        )
      case "en_revision":
        return (
          <Badge className="bg-blue-100 text-blue-700 border-blue-300 gap-1 text-sm px-3 py-1 font-semibold">
            <Clock className="h-4 w-4" />
            En Revisión
          </Badge>
        )
      default:
        return (
          <Badge className="bg-amber-100 text-amber-700 border-amber-300 gap-1 text-sm px-3 py-1 font-semibold">
            <AlertCircle className="h-4 w-4" />
            Pendiente
          </Badge>
        )
    }
  }

  return (
    <div className="h-full flex flex-col bg-[#F3F4F6]">
      <div className="bg-white border-b-2 border-gray-200 px-6 py-5 shadow-sm">
        <div className="flex items-center gap-4 mb-4">
          <Button
            variant="outline"
            size="lg"
            onClick={onBack}
            className="gap-2 text-[#002060] border-2 border-[#002060]/20 hover:bg-[#002060]/5 font-semibold bg-transparent"
          >
            <ArrowLeft className="h-5 w-5" />
            Volver a Convocatorias
          </Button>
        </div>
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold text-[#002060]">{convocatoria.nombre}</h1>
            <p className="text-lg text-muted-foreground mt-1">{convocatoria.periodo}</p>
          </div>
          <div className="flex items-center gap-2 bg-[#002060]/5 px-4 py-3 rounded-lg">
            <Users className="h-6 w-6 text-[#002060]" />
            <span className="text-xl font-bold text-[#002060]">{profesores.length}</span>
            <span className="text-base text-muted-foreground">Profesores asignados</span>
          </div>
        </div>
      </div>

      <div className="px-6 py-5 bg-white border-b-2 border-gray-200">
        <div className="flex flex-col gap-4">
          {/* Search - más grande */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-6 w-6 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Buscar por nombre, facultad o RFC..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value)
                setCurrentPage(1)
              }}
              className="pl-12 h-14 text-lg rounded-xl border-2 focus:border-[#FFC107] focus:ring-[#FFC107]"
              aria-label="Buscar profesores"
            />
          </div>
          {/* Filter buttons - más grandes */}
          <div className="flex flex-wrap gap-3">
            <Button
              variant={filterStatus === "todos" ? "default" : "outline"}
              size="lg"
              onClick={() => {
                setFilterStatus("todos")
                setCurrentPage(1)
              }}
              className={`text-base font-semibold h-12 px-5 ${filterStatus === "todos" ? "bg-[#002060]" : "border-2"}`}
            >
              Todos ({profesores.length})
            </Button>
            <Button
              variant={filterStatus === "pendiente" ? "default" : "outline"}
              size="lg"
              onClick={() => {
                setFilterStatus("pendiente")
                setCurrentPage(1)
              }}
              className={`text-base font-semibold h-12 px-5 ${filterStatus === "pendiente" ? "bg-amber-500 hover:bg-amber-600" : "border-2 border-amber-300 text-amber-700 hover:bg-amber-50"}`}
            >
              <AlertCircle className="h-5 w-5 mr-2" />
              Pendientes ({statusCounts.pendiente})
            </Button>
            <Button
              variant={filterStatus === "en_revision" ? "default" : "outline"}
              size="lg"
              onClick={() => {
                setFilterStatus("en_revision")
                setCurrentPage(1)
              }}
              className={`text-base font-semibold h-12 px-5 ${filterStatus === "en_revision" ? "bg-blue-500 hover:bg-blue-600" : "border-2 border-blue-300 text-blue-700 hover:bg-blue-50"}`}
            >
              <Clock className="h-5 w-5 mr-2" />
              En Revisión ({statusCounts.en_revision})
            </Button>
            <Button
              variant={filterStatus === "revisado" ? "default" : "outline"}
              size="lg"
              onClick={() => {
                setFilterStatus("revisado")
                setCurrentPage(1)
              }}
              className={`text-base font-semibold h-12 px-5 ${filterStatus === "revisado" ? "bg-emerald-500 hover:bg-emerald-600" : "border-2 border-emerald-300 text-emerald-700 hover:bg-emerald-50"}`}
            >
              <CheckCircle2 className="h-5 w-5 mr-2" />
              Revisados ({statusCounts.revisado})
            </Button>
          </div>
        </div>
      </div>

      {/* Professor List - cards más grandes */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="grid gap-5">
          {paginatedProfesores.map((profesor, index) => (
            <div
              key={profesor.id}
              className="bg-white border-2 border-gray-200 rounded-2xl p-6 shadow-sm hover:shadow-lg hover:border-[#FFC107] transition-all duration-200"
              role="article"
              aria-label={`Profesor ${profesor.nombre}`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-4 mb-3">
                    <span className="text-base font-bold text-white bg-[#002060] px-3 py-1.5 rounded-lg">
                      #{startIndex + index + 1}
                    </span>
                    <h3 className="font-bold text-[#002060] text-xl truncate">{profesor.nombre}</h3>
                    {getStatusBadge(profesor.status)}
                  </div>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-base text-muted-foreground mb-4">
                    <span>
                      <strong className="text-gray-700">RFC:</strong> {profesor.rfc}
                    </span>
                    <span className="hidden sm:inline">|</span>
                    <span>
                      <strong className="text-gray-700">Facultad:</strong> {profesor.facultad}
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-6">
                    {/* Progress bar más grande */}
                    <div className="flex-1 min-w-[200px] max-w-sm">
                      <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
                        <span className="flex items-center gap-2">
                          <FileText className="h-4 w-4" />
                          <strong className="text-gray-700">{profesor.documentosValidados}</strong> de{" "}
                          <strong className="text-gray-700">{profesor.documentosTotal}</strong> documentos
                        </span>
                        <span className="font-bold text-[#002060]">{profesor.progress}%</span>
                      </div>
                      <Progress value={profesor.progress} className="h-3" />
                    </div>
                    {userType === "ev_com" && profesor.puntajeAutoevaluacion && (
                      <div className="text-base bg-gray-50 px-4 py-2 rounded-lg">
                        <span className="text-muted-foreground">Autoevaluación:</span>{" "}
                        <span className="font-bold text-[#002060] text-lg">{profesor.puntajeAutoevaluacion} pts</span>
                        {profesor.puntajeAsignado && (
                          <>
                            {" | "}
                            <span className="text-muted-foreground">Asignado:</span>{" "}
                            <span className="font-bold text-emerald-600 text-lg">{profesor.puntajeAsignado} pts</span>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                </div>
                <Button
                  onClick={() => onSelectProfesor(profesor)}
                  className="gap-3 bg-[#002060] hover:bg-[#003399] min-w-[180px] h-14 text-lg font-bold"
                  size="lg"
                >
                  <Eye className="h-6 w-6" />
                  {userType === "ev_fac" ? "Validar" : "Evaluar"}
                </Button>
              </div>
            </div>
          ))}

          {paginatedProfesores.length === 0 && (
            <div className="text-center py-16 text-muted-foreground bg-white rounded-2xl border-2 border-dashed border-gray-300">
              <Search className="h-16 w-16 mx-auto mb-4 opacity-30" />
              <p className="text-xl font-medium">No se encontraron profesores</p>
              <p className="text-base mt-2">Intente con otro criterio de búsqueda</p>
            </div>
          )}
        </div>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-6 p-5 bg-white border-t-2 border-gray-200">
          <Button
            variant="outline"
            size="lg"
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="h-12 px-6 text-base font-semibold border-2"
          >
            <ChevronLeft className="h-6 w-6 mr-2" />
            Anterior
          </Button>
          <span className="text-lg font-semibold text-[#002060]">
            Página {currentPage} de {totalPages}
          </span>
          <Button
            variant="outline"
            size="lg"
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="h-12 px-6 text-base font-semibold border-2"
          >
            Siguiente
            <ChevronRight className="h-6 w-6 ml-2" />
          </Button>
        </div>
      )}
    </div>
  )
}
