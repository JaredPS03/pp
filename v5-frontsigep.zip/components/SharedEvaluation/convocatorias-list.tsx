"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { GraduationCap, Calendar, FileText, CheckCircle2, Clock, LogOut, Users, Info } from "lucide-react"
import type { Convocatoria } from "@/mocks/newRolesData"

interface ConvocatoriasListProps {
  convocatorias: Convocatoria[]
  onSelect: (convocatoria: Convocatoria) => void
  onLogout: () => void
  userType: "ev_fac" | "ev_com"
  userName: string
}

export function ConvocatoriasList({ convocatorias, onSelect, onLogout, userType, userName }: ConvocatoriasListProps) {
  const roleLabel = userType === "ev_fac" ? "Evaluador de Facultad" : "Evaluador de Comisión"

  return (
    <div className="min-h-screen bg-[#F3F4F6]">
      <header className="bg-[#002060] text-white px-6 py-5 shadow-lg">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="bg-[#FFC107] rounded-lg p-3">
              <GraduationCap className="h-10 w-10 text-[#002060]" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold">SIGEP-UABJO</h1>
              <p className="text-white/80 text-base">Sistema de Gestión de Expedientes</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="font-semibold text-lg">{userName}</p>
              <p className="text-base text-white/80">{roleLabel}</p>
            </div>
            <Button
              onClick={onLogout}
              variant="outline"
              size="lg"
              className="bg-transparent border-2 border-white/40 text-white hover:bg-white/10 text-base font-semibold px-6"
            >
              <LogOut className="mr-2 h-5 w-5" />
              Salir
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto p-6 lg:p-8">
        <div className="mb-8">
          <h2 className="text-3xl md:text-4xl font-bold text-[#002060] mb-3">Convocatorias Asignadas</h2>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
            Seleccione una convocatoria para {userType === "ev_fac" ? "validar documentos" : "evaluar puntos"}
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {convocatorias.map((conv) => (
            <Card
              key={conv.id}
              className={`cursor-pointer transition-all duration-200 hover:shadow-xl border-2 ${
                conv.estado === "activa"
                  ? "hover:border-[#FFC107] border-transparent bg-white"
                  : "opacity-60 cursor-not-allowed border-gray-200 bg-gray-50"
              }`}
              onClick={() => conv.estado === "activa" && onSelect(conv)}
              role="button"
              tabIndex={conv.estado === "activa" ? 0 : -1}
              aria-label={`${conv.nombre} - ${conv.estado === "activa" ? "Activa" : "Cerrada"}`}
              onKeyDown={(e) => e.key === "Enter" && conv.estado === "activa" && onSelect(conv)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-lg ${conv.estado === "activa" ? "bg-[#002060]/10" : "bg-gray-100"}`}>
                      <FileText
                        className={`h-7 w-7 ${conv.estado === "activa" ? "text-[#002060]" : "text-gray-400"}`}
                      />
                    </div>
                    <div>
                      <CardTitle className="text-lg md:text-xl leading-tight">{conv.nombre}</CardTitle>
                    </div>
                  </div>
                  <Badge
                    className={`text-sm px-3 py-1 ${
                      conv.estado === "activa"
                        ? "bg-[#10B981]/15 text-[#059669] font-semibold"
                        : "bg-gray-100 text-gray-500"
                    }`}
                  >
                    {conv.estado === "activa" ? (
                      <>
                        <CheckCircle2 className="h-4 w-4 mr-1" />
                        Activa
                      </>
                    ) : (
                      <>
                        <Clock className="h-4 w-4 mr-1" />
                        Cerrada
                      </>
                    )}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-muted-foreground mb-3">
                  <Calendar className="h-5 w-5" />
                  <span className="text-base font-medium">{conv.periodo}</span>
                </div>
                <div className="flex items-center gap-2 text-muted-foreground mb-4">
                  <Users className="h-5 w-5" />
                  <span className="text-base">
                    <strong className="text-[#002060]">{conv.profesoresRevisados}</strong> de{" "}
                    <strong className="text-[#002060]">{conv.profesoresAsignados}</strong> profesores revisados
                  </span>
                </div>
                {/* Progress bar más grande */}
                <div className="w-full bg-gray-200 rounded-full h-3 mb-5">
                  <div
                    className="bg-[#FFC107] h-3 rounded-full transition-all duration-300"
                    style={{ width: `${(conv.profesoresRevisados / conv.profesoresAsignados) * 100}%` }}
                    role="progressbar"
                    aria-valuenow={conv.profesoresRevisados}
                    aria-valuemin={0}
                    aria-valuemax={conv.profesoresAsignados}
                  />
                </div>
                {conv.estado === "activa" && (
                  <Button className="w-full bg-[#002060] hover:bg-[#003399] text-lg font-bold h-14" size="lg">
                    {userType === "ev_fac" ? "Validar Documentos" : "Evaluar Puntos"}
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Info Card con mejor contraste */}
        <Card className="mt-8 bg-blue-50 border-2 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="bg-blue-100 p-3 rounded-lg flex-shrink-0">
                <Info className="h-7 w-7 text-blue-700" />
              </div>
              <div>
                <h3 className="font-bold text-blue-900 text-lg mb-2">Información para Evaluadores</h3>
                <p className="text-blue-800 text-base leading-relaxed">
                  {userType === "ev_fac"
                    ? "Como Evaluador de Facultad, su tarea es validar que los documentos subidos por los profesores cumplan con los requisitos establecidos. Puede aprobar o rechazar cada documento con un solo clic."
                    : "Como Evaluador de Comisión, su tarea es asignar los puntos correspondientes a cada rubro según la normativa vigente. Los puntos deben estar dentro del rango establecido para cada categoría."}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
