"use client"

import type React from "react"
import { useState, useEffect } from "react"
import {
  LayoutDashboard,
  BookOpen,
  FlaskConical,
  Users,
  Building2,
  User,
  HelpCircle,
  ChevronRight,
  ChevronDown,
  Clock,
  Award,
  ClipboardList,
  ArrowLeft,
  PanelLeftOpen,
  FileText,
  X,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import type { ProfesorEvaluacion } from "@/mocks/newRolesData"

const RUBRO_COLORS: Record<string, { bg: string; border: string; icon: string; indicator: string; hoverBg: string }> = {
  generales: {
    bg: "bg-violet-500/10",
    border: "border-l-4 border-violet-500",
    icon: "text-violet-400",
    indicator: "bg-violet-500",
    hoverBg: "hover:bg-violet-500/20",
  },
  calidad: {
    bg: "bg-emerald-500/10",
    border: "border-l-4 border-emerald-500",
    icon: "text-emerald-400",
    indicator: "bg-emerald-500",
    hoverBg: "hover:bg-emerald-500/20",
  },
  dedicacion: {
    bg: "bg-blue-500/10",
    border: "border-l-4 border-blue-500",
    icon: "text-blue-400",
    indicator: "bg-blue-500",
    hoverBg: "hover:bg-blue-500/20",
  },
  permanencia: {
    bg: "bg-amber-500/10",
    border: "border-l-4 border-amber-500",
    icon: "text-amber-400",
    indicator: "bg-amber-500",
    hoverBg: "hover:bg-amber-500/20",
  },
}

const MENU_DATA = [
  {
    id: "inicio",
    title: "Inicio",
    icon: LayoutDashboard,
    isFolder: false,
    url: "#",
  },
  {
    id: "generales",
    title: "0. GENERALES",
    icon: ClipboardList,
    isFolder: true,
    items: [
      { id: "solicitud-ingreso", title: "Solicitud de Ingreso", url: "#" },
      { id: "carta-exclusividad", title: "Carta de Exclusividad", url: "#" },
      { id: "constancia-antiguedad", title: "Constancia de Antigüedad", url: "#" },
      { id: "informe-evaluacion", title: "Informe de Evaluación", url: "#" },
      { id: "documentos-grado", title: "Documentos de Grado", url: "#" },
    ],
  },
  {
    id: "calidad",
    title: "I. CALIDAD (700 Pts)",
    icon: Award,
    isFolder: true,
    items: [
      {
        id: "docencia",
        title: "I.1. DOCENCIA (100-300 Pts)",
        icon: BookOpen,
        isFolder: true,
        items: [
          {
            id: "calidad-desempeno",
            title: "Calidad al desempeño docente",
            isFolder: true,
            items: [
              { id: "programas", title: "Programas de asignatura", url: "#" },
              { id: "evaluacion", title: "Constancia de evaluación docente", url: "#" },
              { id: "calificaciones", title: "Calificaciones finales", url: "#" },
              { id: "material", title: "Uso de material didáctico", url: "#" },
              { id: "asistencia", title: "Asistencia y puntualidad", url: "#" },
            ],
          },
          { id: "libros-isbn", title: "Autor de libros con ISBN", url: "#" },
          { id: "capitulos-libros", title: "Publicación de capítulos en libros", url: "#" },
          { id: "antologias", title: "Elaboración de antologías", url: "#" },
          { id: "exposiciones", title: "Obra en exposiciones artísticas", url: "#" },
          { id: "conciertos", title: "Concierto o recital musical", url: "#" },
          { id: "patentes", title: "Patentes, modelos y prototipos", url: "#" },
          { id: "cursos-disciplinarios", title: "Cursos actualización disciplinaria", url: "#" },
          { id: "cursos-formacion", title: "Cursos de formación docente", url: "#" },
          { id: "diplomados", title: "Diplomados (mín. 80 horas)", url: "#" },
          { id: "org-cursos", title: "Organizar cursos actualización", url: "#" },
          { id: "ponente-cursos", title: "Ponente en cursos/talleres", url: "#" },
          { id: "premios-labor", title: "Premios labor o trayectoria", url: "#" },
          { id: "perfil-prodep", title: "Perfil Deseable PRODEP", url: "#" },
          { id: "cursos-ciees", title: "Cursos Licenciatura CIEES/Acred.", url: "#" },
          { id: "cursos-snp", title: "Cursos en Posgrados SNP", url: "#" },
          { id: "vinculacion", title: "Proyectos de vinculación", url: "#" },
          { id: "formacion-rsu", title: "Formación modelo RSU", url: "#" },
          { id: "acciones-int", title: "Acciones internacionales", url: "#" },
        ],
      },
      {
        id: "investigacion",
        title: "I.2. INVESTIGACIÓN (25-150 Pts)",
        icon: FlaskConical,
        isFolder: true,
        items: [
          { id: "asistente-congresos", title: "Asistente en congresos", url: "#" },
          { id: "ponente-congresos", title: "Ponente en congresos/foros", url: "#" },
          { id: "ponencia-magistral", title: "Ponencia magistral", url: "#" },
          { id: "articulos-difusion", title: "Artículos en revistas difusión", url: "#" },
          { id: "articulos-indexados", title: "Artículos revistas indexadas", url: "#" },
          { id: "articulos-scopus", title: "Artículos SCOPUS/JCR", url: "#" },
          { id: "capitulos-especializados", title: "Capítulos libros especializados", url: "#" },
          { id: "coord-libros-locales", title: "Coord/Editor libros locales", url: "#" },
          { id: "coord-libros-nac", title: "Coord/Editor nac. e int.", url: "#" },
          { id: "publicacion-memorias", title: "Publicación en memorias", url: "#" },
          { id: "proyectos-internos", title: "Proyectos financiamiento interno", url: "#" },
          { id: "proyectos-externos", title: "Proyectos financiamiento externo", url: "#" },
          { id: "evaluador-proyectos", title: "Evaluador de proyectos", url: "#" },
          { id: "evaluador-publicaciones", title: "Evaluador de publicaciones", url: "#" },
          { id: "estancias", title: "Estancias de investigación", url: "#" },
          { id: "sni", title: "Investigador Nacional SNI", url: "#" },
        ],
      },
      {
        id: "tutorias",
        title: "I.3. TUTORÍAS (30-150 Pts)",
        icon: Users,
        isFolder: true,
        items: [
          { id: "tutorias-perm", title: "Tutorías permanentes", url: "#" },
          { id: "revisor-tesis", title: "Revisor tesis/Jurado examen", url: "#" },
          { id: "olimpiadas", title: "Preparación de grupos olimpiadas", url: "#" },
          { id: "dir-tesis-lic", title: "Director de tesis licenciatura", url: "#" },
          { id: "dir-tesis-mae", title: "Dirección de tesis maestría", url: "#" },
          { id: "dir-tesis-doc", title: "Dirección de tesis doctorado", url: "#" },
          { id: "lector-posgrado", title: "Lector/Revisor tesis posgrado", url: "#" },
          { id: "serv-social-anual", title: "Asesoría serv. social anual", url: "#" },
          { id: "serv-social-sem", title: "Asesoría serv. social semestral", url: "#" },
          { id: "premios-supervisada", title: "Premios labor supervisada", url: "#" },
          { id: "premios-concursos", title: "Premios concursos académicos", url: "#" },
          { id: "lineas-inv", title: "Formación en líneas de inv.", url: "#" },
          { id: "tutoria-movilidad", title: "Tutoría movilidad/verano", url: "#" },
          { id: "tutoria-postdoc", title: "Tutoría postdoctorales", url: "#" },
          { id: "registro-patentes", title: "Registro patentes/prototipos", url: "#" },
          { id: "asesoria-titulacion", title: "Asesoría titulación (no tesis)", url: "#" },
          { id: "impacto-rsu", title: "Actividades impacto RSU", url: "#" },
        ],
      },
      {
        id: "cuerpos-colegiados",
        title: "I.4. CUERPOS COLEGIADOS (30-100 Pts)",
        icon: Building2,
        isFolder: true,
        items: [
          { id: "revision-planes", title: "Revisión planes estudio", url: "#" },
          { id: "comisiones-acad", title: "Comisiones académicas", url: "#" },
          { id: "gestion-consejos", title: "Gestión Académica (Consejos)", url: "#" },
          { id: "org-extension", title: "Organización actos extensión", url: "#" },
          { id: "actos-internacionales", title: "Actos prestigio internacional", url: "#" },
          { id: "muestras-nacionales", title: "Muestras prestigio nacional", url: "#" },
          { id: "evaluador-posgrado", title: "Evaluador programas posgrado", url: "#" },
          { id: "cuerpos-prodep", title: "Cuerpos Académicos PRODEP", url: "#" },
        ],
      },
    ],
  },
  {
    id: "dedicacion",
    title: "II. DEDICACIÓN (200 Pts)",
    icon: Clock,
    isFolder: true,
    items: [{ id: "carga-horaria", title: "Carga Horaria Docente", url: "#" }],
  },
  {
    id: "permanencia",
    title: "III. PERMANENCIA (100 Pts)",
    icon: Users,
    isFolder: true,
    items: [{ id: "antiguedad", title: "Antigüedad", url: "#" }],
  },
  {
    id: "perfil",
    title: "Mi Perfil",
    icon: User,
    isFolder: false,
    url: "#",
  },
  {
    id: "ayuda",
    title: "Centro de Ayuda",
    icon: HelpCircle,
    isFolder: false,
    url: "#",
  },
]

// Helper para obtener todos los items hoja
function getAllLeafItems(items: any[]): any[] {
  const result: any[] = []
  for (const item of items) {
    if (item.items && item.items.length > 0) {
      result.push(...getAllLeafItems(item.items))
    } else if (!item.isSeparator && item.id !== "inicio" && item.id !== "perfil" && item.id !== "ayuda") {
      result.push(item)
    }
  }
  return result
}

interface MenuItemProps {
  item: any
  level?: number
  expandedItems: Set<string>
  toggleExpand: (id: string) => void
  activeItem: string | null
  setActiveItem: (id: string) => void
  parentRubroId?: string | null
}

function MenuItem({
  item,
  level = 0,
  expandedItems,
  toggleExpand,
  activeItem,
  setActiveItem,
  parentRubroId,
}: MenuItemProps) {
  const hasChildren = item.items && item.items.length > 0
  const isExpanded = expandedItems.has(item.id)
  const isActive = activeItem === item.id
  const paddingLeft = 16 + level * 12

  const currentRubroId = level === 0 && RUBRO_COLORS[item.id] ? item.id : parentRubroId
  const rubroColor = currentRubroId ? RUBRO_COLORS[currentRubroId] : null

  const isMainRubro = level === 0 && RUBRO_COLORS[item.id]
  const isSpecialItem = item.id === "perfil" || item.id === "ayuda"

  const handleClick = () => {
    if (hasChildren || item.isFolder) {
      toggleExpand(item.id)
    } else {
      setActiveItem(item.id)
    }
  }

  return (
    <div className="select-none">
      <button
        onClick={handleClick}
        className={cn(
          "w-full flex items-center gap-2 py-2.5 px-3 text-left transition-all duration-150 text-sm",
          "hover:bg-white/10",
          isActive && !hasChildren && "bg-white/15 text-white font-semibold",
          !isActive && "text-white/80",
          isMainRubro && rubroColor?.bg,
          isMainRubro && rubroColor?.border,
          isMainRubro && rubroColor?.hoverBg,
          isSpecialItem && "mt-1 bg-white/5",
        )}
        style={{ paddingLeft: `${paddingLeft}px` }}
        aria-expanded={hasChildren ? isExpanded : undefined}
        aria-current={isActive ? "page" : undefined}
      >
        {/* Chevron para expandir */}
        {hasChildren || item.isFolder ? (
          <span className="w-4 h-4 flex items-center justify-center flex-shrink-0">
            {isExpanded ? (
              <ChevronDown className="h-4 w-4 text-white/50" />
            ) : (
              <ChevronRight className="h-4 w-4 text-white/50" />
            )}
          </span>
        ) : (
          <span className="w-4" />
        )}

        {/* Icono */}
        {item.icon ? (
          <item.icon
            className={cn(
              "h-4 w-4 flex-shrink-0",
              isMainRubro && rubroColor ? rubroColor.icon : isSpecialItem ? "text-amber-400" : "text-white/60",
            )}
          />
        ) : (
          <FileText className="h-4 w-4 text-white/40 flex-shrink-0" />
        )}

        {/* Titulo */}
        <span className={cn("truncate flex-1", level === 0 ? "font-medium" : "font-normal")}>{item.title}</span>

        {/* Indicador de color para rubros principales */}
        {isMainRubro && rubroColor && (
          <span className={cn("w-2 h-2 rounded-full flex-shrink-0", rubroColor.indicator)} />
        )}
      </button>

      {/* Sub-items */}
      {hasChildren && (
        <div
          className={cn(
            "overflow-hidden transition-all duration-200 ease-in-out",
            isExpanded ? "max-h-[2000px] opacity-100" : "max-h-0 opacity-0",
          )}
        >
          {item.items.map((subItem: any) => (
            <MenuItem
              key={subItem.id}
              item={subItem}
              level={level + 1}
              expandedItems={expandedItems}
              toggleExpand={toggleExpand}
              activeItem={activeItem}
              setActiveItem={setActiveItem}
              parentRubroId={currentRubroId}
            />
          ))}
        </div>
      )}
    </div>
  )
}

interface FocusModeLayoutProps {
  profesor: ProfesorEvaluacion
  onBack: () => void
  userType: "ev_fac" | "ev_com"
  children: (props: {
    selectedRubroId: string | null
    onNavigateNext: () => void
    onNavigatePrev: () => void
    hasNext: boolean
    hasPrev: boolean
    currentIndex: number
    totalItems: number
  }) => React.ReactNode
}

export function FocusModeLayout({ profesor, onBack, userType, children }: FocusModeLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set(["generales", "calidad"]))
  const [activeItem, setActiveItem] = useState<string | null>("solicitud-ingreso")

  const allLeafItems = getAllLeafItems(MENU_DATA)
  const currentIndex = allLeafItems.findIndex((item) => item.id === activeItem)
  const hasPrev = currentIndex > 0
  const hasNext = currentIndex < allLeafItems.length - 1 && currentIndex !== -1

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft" && hasPrev) {
        handleNavigatePrev()
      } else if (e.key === "ArrowRight" && hasNext) {
        handleNavigateNext()
      } else if (e.key === "Escape" && sidebarOpen) {
        setSidebarOpen(false)
      }
    }
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [hasPrev, hasNext, sidebarOpen, currentIndex])

  const toggleExpand = (id: string) => {
    setExpandedItems((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(id)) {
        newSet.delete(id)
      } else {
        newSet.add(id)
      }
      return newSet
    })
  }

  const handleSetActiveItem = (id: string) => {
    setActiveItem(id)
    expandParents(id)
    setSidebarOpen(false)
  }

  const expandParents = (itemId: string) => {
    const findParents = (items: any[], targetId: string, parents: string[] = []): string[] | null => {
      for (const item of items) {
        if (item.id === targetId) {
          return parents
        }
        if (item.items) {
          const found = findParents(item.items, targetId, [...parents, item.id])
          if (found) return found
        }
      }
      return null
    }
    const parents = findParents(MENU_DATA, itemId)
    if (parents) {
      setExpandedItems((prev) => new Set([...prev, ...parents]))
    }
  }

  const handleNavigateNext = () => {
    if (hasNext) {
      const nextItem = allLeafItems[currentIndex + 1]
      setActiveItem(nextItem.id)
      expandParents(nextItem.id)
    }
  }

  const handleNavigatePrev = () => {
    if (hasPrev) {
      const prevItem = allLeafItems[currentIndex - 1]
      setActiveItem(prevItem.id)
      expandParents(prevItem.id)
    }
  }

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50">
      {sidebarOpen && (
        <>
          {/* Backdrop */}
          <div
            className="fixed inset-0 bg-black/50 z-40 transition-opacity"
            onClick={() => setSidebarOpen(false)}
            aria-hidden="true"
          />

          {/* Sidebar overlay */}
          <aside className="fixed left-0 top-0 h-full w-80 bg-[#0a1628] flex flex-col z-50 shadow-2xl">
            {/* Header */}
            <div className="flex-shrink-0 px-3 py-3 flex items-center justify-between border-b border-white/10">
              <span className="text-white font-semibold text-lg">Navegación</span>
              <button
                onClick={() => setSidebarOpen(false)}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                aria-label="Cerrar menú"
              >
                <X className="h-5 w-5 text-white" />
              </button>
            </div>

            {/* Info del profesor */}
            <div className="flex-shrink-0 px-3 py-3 bg-white/5 border-b border-white/10">
              <p className="text-white font-semibold truncate">{profesor.nombre}</p>
              <p className="text-white/60 text-sm truncate">{profesor.facultad}</p>
            </div>

            {/* Leyenda */}
            <div className="flex-shrink-0 px-3 py-2 flex items-center gap-2 text-[10px] border-b border-white/5 flex-wrap">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-violet-500" />
                <span className="text-white/50">Generales</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                <span className="text-white/50">Calidad</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-blue-500" />
                <span className="text-white/50">Dedicación</span>
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-amber-500" />
                <span className="text-white/50">Permanencia</span>
              </span>
            </div>

            {/* Menu */}
            <nav className="flex-1 overflow-y-auto py-1 sidebar-scroll">
              {MENU_DATA.map((item) => (
                <MenuItem
                  key={item.id}
                  item={item}
                  expandedItems={expandedItems}
                  toggleExpand={toggleExpand}
                  activeItem={activeItem}
                  setActiveItem={handleSetActiveItem}
                  parentRubroId={null}
                />
              ))}
            </nav>
          </aside>
        </>
      )}

      <main className="flex-1 flex flex-col h-full overflow-hidden">
        <header className="flex-shrink-0 bg-[#002060] px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={onBack} className="text-white hover:bg-white/10 gap-2">
              <ArrowLeft className="h-4 w-4" />
              <span className="hidden sm:inline">Volver</span>
            </Button>
            <div className="h-6 w-px bg-white/20" />
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(true)}
              className="text-white hover:bg-white/10 gap-2"
            >
              <PanelLeftOpen className="h-4 w-4" />
              <span>Menú</span>
            </Button>
          </div>

          <div className="flex items-center gap-2 text-white text-sm">
            <span className="hidden md:inline text-white/70">{profesor.nombre}</span>
            <span className="bg-white/20 px-2 py-1 rounded text-xs font-medium">
              {currentIndex + 1} / {allLeafItems.length}
            </span>
          </div>
        </header>

        {/* Content area */}
        <div className="flex-1 overflow-hidden">
          {children({
            selectedRubroId: activeItem,
            onNavigateNext: handleNavigateNext,
            onNavigatePrev: handleNavigatePrev,
            hasNext,
            hasPrev,
            currentIndex: currentIndex + 1,
            totalItems: allLeafItems.length,
          })}
        </div>
      </main>
    </div>
  )
}
