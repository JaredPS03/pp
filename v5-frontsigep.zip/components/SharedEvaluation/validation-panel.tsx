"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import {
  CheckCircle2,
  XCircle,
  ChevronLeft,
  ChevronRight,
  FileText,
  AlertCircle,
  ThumbsUp,
  ThumbsDown,
  Edit3,
  Check,
} from "lucide-react"
import { documentosProfesor } from "@/mocks/newRolesData"

interface ValidationPanelProps {
  selectedRubroId: string | null
  onNavigateNext: () => void
  onNavigatePrev: () => void
  hasNext: boolean
  hasPrev: boolean
  currentIndex: number
  totalItems: number
}

export function ValidationPanel({
  selectedRubroId,
  onNavigateNext,
  onNavigatePrev,
  hasNext,
  hasPrev,
  currentIndex,
  totalItems,
}: ValidationPanelProps) {
  const [feedback, setFeedback] = useState("")
  const [documentStatus, setDocumentStatus] = useState<Record<string, "aprobado" | "rechazado" | "pendiente">>({})
  const [savedFeedback, setSavedFeedback] = useState<Record<string, string>>({})
  const [showSaved, setShowSaved] = useState(false)
  const [isEditing, setIsEditing] = useState(false)

  const currentDocument = documentosProfesor.find((doc) => doc.rubroId === selectedRubroId)
  const currentStatus = currentDocument ? documentStatus[currentDocument.id] || currentDocument.estado : "pendiente"
  const hasBeenEvaluated = currentDocument && currentStatus !== "pendiente"

  useEffect(() => {
    if (currentDocument && savedFeedback[currentDocument.id]) {
      setFeedback(savedFeedback[currentDocument.id])
    } else {
      setFeedback("")
    }
    setIsEditing(false)
    setShowSaved(false)
  }, [selectedRubroId]) // Updated to use selectedRubroId instead of currentDocument?.id

  const handleSave = useCallback(
    (status: "aprobado" | "rechazado") => {
      if (currentDocument) {
        setDocumentStatus((prev) => ({ ...prev, [currentDocument.id]: status }))
        setSavedFeedback((prev) => ({ ...prev, [currentDocument.id]: feedback }))
        setShowSaved(true)
        setIsEditing(false)
        setTimeout(() => setShowSaved(false), 2000)
      }
    },
    [currentDocument, feedback],
  )

  const handleEdit = () => {
    setIsEditing(true)
    setShowSaved(false)
  }

  const handleCancelEdit = () => {
    if (currentDocument && savedFeedback[currentDocument.id]) {
      setFeedback(savedFeedback[currentDocument.id])
    }
    setIsEditing(false)
  }

  return (
    <div className="h-full flex">
      {/* PDF Viewer - takes most space */}
      <div className="flex-1 flex flex-col bg-gray-50 min-w-0">
        {/* Document header - compact */}
        <div className="flex-shrink-0 bg-white border-b px-4 py-2 flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="h-9 w-9 rounded-lg bg-[#002060]/10 flex items-center justify-center flex-shrink-0">
              <FileText className="h-5 w-5 text-[#002060]" />
            </div>
            <div className="min-w-0">
              <h3 className="font-semibold text-[#002060] text-sm truncate">
                {currentDocument?.rubroNombre || "Seleccione un documento"}
              </h3>
              {currentDocument && <p className="text-xs text-muted-foreground truncate">{currentDocument.nombre}</p>}
            </div>
          </div>
          <Badge
            className={`text-xs px-2 py-1 flex-shrink-0 font-medium ${
              currentStatus === "aprobado"
                ? "bg-emerald-100 text-emerald-700 border border-emerald-300"
                : currentStatus === "rechazado"
                  ? "bg-red-100 text-red-700 border border-red-300"
                  : "bg-amber-100 text-amber-700 border border-amber-300"
            }`}
          >
            {currentStatus === "aprobado" ? "Aprobado" : currentStatus === "rechazado" ? "Rechazado" : "Pendiente"}
          </Badge>
        </div>

        {/* PDF Preview area */}
        <div className="flex-1 flex items-center justify-center p-4">
          {currentDocument ? (
            <div className="w-full h-full bg-white rounded-xl shadow-sm border border-gray-200 flex flex-col items-center justify-center">
              <FileText className="h-20 w-20 text-gray-300 mb-4" />
              <p className="text-gray-700 font-medium text-lg text-center px-4">{currentDocument.nombre}</p>
              <p className="text-gray-400 text-sm mt-2">Vista previa del documento</p>
              {currentDocument.fechaSubida && (
                <p className="text-xs text-gray-400 mt-3">Subido: {currentDocument.fechaSubida}</p>
              )}
            </div>
          ) : (
            <div className="text-center text-gray-400">
              <AlertCircle className="h-16 w-16 mx-auto mb-3 opacity-50" />
              <p className="text-lg font-medium">Seleccione un documento del menú</p>
            </div>
          )}
        </div>

        {/* Navigation footer */}
        <div className="flex-shrink-0 bg-white border-t px-4 py-2 flex items-center justify-between">
          <Button
            variant="outline"
            size="sm"
            onClick={onNavigatePrev}
            disabled={!hasPrev}
            className="gap-1 bg-transparent"
          >
            <ChevronLeft className="h-4 w-4" />
            Anterior
          </Button>
          <span className="text-xs text-muted-foreground">
            {currentIndex + 1} de {totalItems}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={onNavigateNext}
            disabled={!hasNext}
            className="gap-1 bg-transparent"
          >
            Siguiente
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="w-64 flex-shrink-0 bg-white border-l flex flex-col">
        {/* Header */}
        <div className="flex-shrink-0 px-4 py-3 bg-gradient-to-r from-[#002060] to-[#003380]">
          <h3 className="font-semibold text-white text-sm">Validar Documento</h3>
        </div>

        {currentDocument ? (
          <div className="flex-1 p-3 flex flex-col gap-3">
            {hasBeenEvaluated && !isEditing ? (
              <div
                className={`rounded-lg p-3 border-2 ${
                  currentStatus === "aprobado" ? "bg-emerald-50 border-emerald-300" : "bg-red-50 border-red-300"
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {currentStatus === "aprobado" ? (
                      <CheckCircle2 className="h-5 w-5 text-emerald-500" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500" />
                    )}
                    <span
                      className={`font-bold text-sm ${
                        currentStatus === "aprobado" ? "text-emerald-700" : "text-red-700"
                      }`}
                    >
                      {currentStatus === "aprobado" ? "Aprobado" : "Rechazado"}
                    </span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={handleEdit} className="h-7 px-2 text-xs hover:bg-white/50">
                    <Edit3 className="h-3 w-3 mr-1" />
                    Editar
                  </Button>
                </div>
                {savedFeedback[currentDocument.id] && (
                  <p className="text-xs text-gray-600 mt-2 italic">"{savedFeedback[currentDocument.id]}"</p>
                )}
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <Button
                    onClick={() => handleSave("aprobado")}
                    className="w-full h-12 text-sm font-bold bg-emerald-500 hover:bg-emerald-600 gap-2 shadow-md transition-all hover:scale-[1.02]"
                  >
                    <ThumbsUp className="h-5 w-5" />
                    APROBAR
                  </Button>
                  <Button
                    onClick={() => handleSave("rechazado")}
                    variant="destructive"
                    className="w-full h-12 text-sm font-bold gap-2 shadow-md transition-all hover:scale-[1.02]"
                  >
                    <ThumbsDown className="h-5 w-5" />
                    RECHAZAR
                  </Button>
                </div>

                {/* Comments */}
                <div className="flex-1 flex flex-col">
                  <label className="text-xs font-semibold text-gray-600 mb-1">Observaciones (opcional)</label>
                  <Textarea
                    placeholder="Escriba sus comentarios aquí..."
                    value={feedback}
                    onChange={(e) => setFeedback(e.target.value)}
                    className="flex-1 min-h-[80px] resize-none text-sm border-2 focus:border-[#002060]"
                  />
                </div>

                {isEditing && (
                  <Button variant="outline" size="sm" onClick={handleCancelEdit} className="w-full bg-transparent">
                    Cancelar edición
                  </Button>
                )}
              </>
            )}

            {showSaved && (
              <div className="bg-emerald-100 border border-emerald-300 rounded-lg p-2 flex items-center gap-2 animate-in fade-in slide-in-from-top-2 duration-200">
                <Check className="h-4 w-4 text-emerald-600" />
                <span className="text-xs font-medium text-emerald-700">Guardado correctamente</span>
              </div>
            )}
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center text-center text-gray-400 p-4">
            <div>
              <FileText className="h-12 w-12 mx-auto mb-2 opacity-30" />
              <p className="text-sm">Seleccione un documento</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
