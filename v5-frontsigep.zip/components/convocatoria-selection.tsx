"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { GraduationCap, Calendar, FileText, CheckCircle2, Clock, LogOut } from "lucide-react"

interface Convocatoria {
  id: string
  nombre: string
  periodo: string
  estado: "activa" | "cerrada"
}

interface ConvocatoriaSelectionProps {
  onSelect: (convocatoria: Convocatoria) => void
  onLogout: () => void
}

const convocatorias: Convocatoria[] = [
  { id: "1", nombre: "Estímulos al Desempeño Docente 2025", periodo: "Ene 2025 - Dic 2025", estado: "activa" },
  { id: "2", nombre: "PRODEP 2024", periodo: "Jul 2024 - Jun 2025", estado: "activa" },
  { id: "3", nombre: "Reconocimiento Académico 2024", periodo: "Ene 2024 - Dic 2024", estado: "cerrada" },
  { id: "4", nombre: "SNI - Perfil Deseable 2025", periodo: "Feb 2025 - Nov 2025", estado: "activa" },
]

export function ConvocatoriaSelection({ onSelect, onLogout }: ConvocatoriaSelectionProps) {
  return (
    <div className="min-h-screen bg-[#F3F4F6]">
      {/* Header */}
      <header className="bg-[#002060] text-white px-6 py-4 shadow-lg">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="bg-[#FFC107] rounded-lg p-2">
              <GraduationCap className="h-8 w-8 text-[#002060]" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">SIGEP-UABJO</h1>
              <p className="text-white/80 text-sm">Sistema de Gestión de Expedientes</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="font-semibold">Dr. Juan Pérez García</p>
              <p className="text-sm text-white/80">Profesor Titular</p>
            </div>
            <Button
              onClick={onLogout}
              variant="outline"
              className="bg-transparent border-white/30 text-white hover:bg-white/10"
            >
              <LogOut className="mr-2 h-4 w-4" />
              Salir
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto p-6 lg:p-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-[#002060] mb-2">Mis Convocatorias</h2>
          <p className="text-lg text-muted-foreground">
            Seleccione una convocatoria para gestionar su expediente académico
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {convocatorias.map((conv) => (
            <Card
              key={conv.id}
              className={`cursor-pointer transition-all hover:shadow-xl border-2 ${
                conv.estado === "activa"
                  ? "hover:border-[#FFC107] border-transparent"
                  : "opacity-60 cursor-not-allowed border-gray-200"
              }`}
              onClick={() => conv.estado === "activa" && onSelect(conv)}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-3 rounded-lg ${conv.estado === "activa" ? "bg-[#002060]/10" : "bg-gray-100"}`}>
                      <FileText
                        className={`h-6 w-6 ${conv.estado === "activa" ? "text-[#002060]" : "text-gray-400"}`}
                      />
                    </div>
                    <div>
                      <CardTitle className="text-lg leading-tight">{conv.nombre}</CardTitle>
                    </div>
                  </div>
                  <Badge
                    className={
                      conv.estado === "activa" ? "bg-[#10B981]/10 text-[#10B981]" : "bg-gray-100 text-gray-500"
                    }
                  >
                    {conv.estado === "activa" ? (
                      <>
                        <CheckCircle2 className="h-3 w-3 mr-1" />
                        Activa
                      </>
                    ) : (
                      <>
                        <Clock className="h-3 w-3 mr-1" />
                        Cerrada
                      </>
                    )}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-muted-foreground mb-4">
                  <Calendar className="h-4 w-4" />
                  <span className="text-sm">{conv.periodo}</span>
                </div>
                {conv.estado === "activa" && (
                  <Button className="w-full" size="lg">
                    Acceder al Expediente
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Info Card */}
        <Card className="mt-8 bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <div className="bg-blue-100 p-3 rounded-lg flex-shrink-0">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h3 className="font-semibold text-blue-900 mb-1">Información Importante</h3>
                <p className="text-blue-800 text-sm leading-relaxed">
                  Asegúrese de completar todos los rubros requeridos antes de la fecha límite de cada convocatoria. Los
                  documentos subidos serán revisados por el comité evaluador correspondiente.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
