"use client"

import { useState } from "react"
import { Play, FileText, ChevronRight, CheckCircle2, Clock, Upload, BookOpen, HelpCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface WelcomeViewProps {
  onContinue: () => void
  convocatoriaName?: string
}

export function WelcomeView({ onContinue, convocatoriaName }: WelcomeViewProps) {
  const [videoPlaying, setVideoPlaying] = useState(false)

  const steps = [
    {
      number: 1,
      title: "Documentos Generales",
      description:
        "Sube los documentos obligatorios: solicitud, carta de exclusividad, constancias y documentos de grado.",
      icon: FileText,
      current: true,
    },
    {
      number: 2,
      title: "Rubros de Evaluación",
      description: "Completa cada rubro: Calidad, Dedicación y Permanencia con sus respectivas evidencias.",
      icon: Upload,
      current: false,
    },
    {
      number: 3,
      title: "Revisión y Envío",
      description: "Revisa tu expediente completo y envíalo para evaluación antes de la fecha límite.",
      icon: CheckCircle2,
      current: false,
    },
  ]

  return (
    <div className="h-full overflow-y-auto bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-4xl mx-auto px-6 py-10">
        {/* Header institucional */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-[#002060] rounded-2xl mb-6 shadow-lg">
            <span className="text-2xl font-bold text-amber-400">S</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-[#002060] mb-3">Bienvenido a SIGEP</h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Sistema Integral de Gestión de Estímulos al Personal Docente
          </p>
          {convocatoriaName && (
            <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-amber-50 border border-amber-200 rounded-full">
              <Clock className="h-4 w-4 text-amber-600" />
              <span className="text-sm font-medium text-amber-700">{convocatoriaName}</span>
            </div>
          )}
        </div>

        {/* Video Tutorial Section */}
        <Card className="mb-10 overflow-hidden border-2 border-gray-200 shadow-lg">
          <CardContent className="p-0">
            <div className="bg-[#002060] px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Play className="h-5 w-5 text-amber-400" />
                <h2 className="text-lg font-semibold text-white">Video Tutorial de Bienvenida</h2>
              </div>
              <span className="text-xs text-slate-300 bg-slate-700 px-3 py-1 rounded-full">3:45 min</span>
            </div>
            <div className="relative bg-slate-900 aspect-video">
              {/* YouTube Video Embed Placeholder */}
              {!videoPlaying ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-br from-slate-800 to-slate-900">
                  <div className="text-center">
                    <button
                      onClick={() => setVideoPlaying(true)}
                      className="group w-20 h-20 bg-amber-500 hover:bg-amber-400 rounded-full flex items-center justify-center transition-all shadow-xl hover:scale-105 mb-4"
                    >
                      <Play className="h-8 w-8 text-white ml-1 group-hover:scale-110 transition-transform" />
                    </button>
                    <p className="text-white font-medium mb-1">Clic para reproducir</p>
                    <p className="text-slate-400 text-sm">Aprende cómo funciona el sistema</p>
                  </div>
                  {/* Decorative elements */}
                  <div className="absolute bottom-6 left-6 flex items-center gap-2 text-slate-400">
                    <HelpCircle className="h-4 w-4" />
                    <span className="text-xs">Tutorial introductorio</span>
                  </div>
                </div>
              ) : (
                <iframe
                  className="w-full h-full"
                  src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1"
                  title="Tutorial SIGEP"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              )}
            </div>
          </CardContent>
        </Card>

        {/* Step 1 Indicator */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-[#002060] text-white rounded-full flex items-center justify-center font-bold shadow-md">
              1
            </div>
            <div>
              <h2 className="text-xl font-bold text-[#002060]">Paso 1: Carga tus Archivos Generales</h2>
              <p className="text-sm text-gray-500">El primer paso para completar tu evaluación</p>
            </div>
          </div>
        </div>

        {/* Process Steps */}
        <div className="grid md:grid-cols-3 gap-4 mb-10">
          {steps.map((step) => (
            <Card
              key={step.number}
              className={`border-2 transition-all ${
                step.current ? "border-[#002060] bg-blue-50/50 shadow-md" : "border-gray-200 bg-white"
              }`}
            >
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                      step.current ? "bg-[#002060] text-white" : "bg-gray-100 text-gray-400"
                    }`}
                  >
                    <step.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span
                        className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                          step.current ? "bg-amber-100 text-amber-700" : "bg-gray-100 text-gray-500"
                        }`}
                      >
                        Paso {step.number}
                      </span>
                      {step.current && <span className="text-xs text-[#002060] font-medium">Actual</span>}
                    </div>
                    <h3 className={`font-semibold mb-1 ${step.current ? "text-[#002060]" : "text-gray-600"}`}>
                      {step.title}
                    </h3>
                    <p className="text-sm text-gray-500 leading-relaxed">{step.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Required Documents Preview */}
        <Card className="mb-10 border-2 border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <BookOpen className="h-5 w-5 text-[#002060]" />
              <h3 className="font-semibold text-gray-800">Documentos que necesitarás subir:</h3>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {[
                "Solicitud de Ingreso",
                "Carta de Exclusividad",
                "Constancia de Antigüedad",
                "Informe de Evaluación",
                "Documentos de Grado",
              ].map((doc, index) => (
                <div key={index} className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <FileText className="h-4 w-4 text-violet-500 flex-shrink-0" />
                  <span className="text-xs text-gray-700 font-medium leading-tight">{doc}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Action Button */}
        <div className="flex justify-center">
          <Button
            onClick={onContinue}
            size="lg"
            className="bg-[#002060] hover:bg-[#001040] text-white px-10 py-6 text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all group"
          >
            Comenzar a Subir Documentos
            <ChevronRight className="h-5 w-5 ml-2 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>

        {/* Footer info */}
        <p className="text-center text-sm text-gray-400 mt-8">
          Si tienes dudas, puedes acceder al Centro de Ayuda desde el menú lateral
        </p>
      </div>
    </div>
  )
}
