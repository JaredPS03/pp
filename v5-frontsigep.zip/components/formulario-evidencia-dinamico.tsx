"use client"

import type React from "react"
import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { CONFIGURACION_RUBROS, type ConfiguracionRubro, type CampoFormulario } from "@/config/sistema.config"

// === CONFIGURACIÓN ===

interface DatosFormulario {
  tipoProducto: string | null
  archivo: File | null
  campos: Record<string, string>
}

// === COMPONENTES ===

/**
 * Renderiza un campo del formulario dinámicamente según su tipo
 */
function CampoDinamico({
  campo,
  valor,
  onChange,
}: { campo: CampoFormulario; valor: string; onChange: (valor: string) => void }) {
  const esRequerido = campo.requerido ?? true

  switch (campo.tipo) {
    case "select":
      return (
        <div>
          <Label htmlFor={campo.id} className="text-base font-semibold mb-2 block">
            {campo.etiqueta}
            {esRequerido && <span className="text-destructive ml-1">*</span>}
          </Label>
          <Select value={valor} onValueChange={onChange}>
            <SelectTrigger id={campo.id} className="text-base h-12">
              <SelectValue placeholder={`Seleccione ${campo.etiqueta.toLowerCase()}`} />
            </SelectTrigger>
            <SelectContent>
              {campo.opciones?.map((opcion) => (
                <SelectItem key={opcion} value={opcion} className="text-base">
                  {opcion}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {campo.ayuda && <p className="text-sm text-muted-foreground mt-2">{campo.ayuda}</p>}
        </div>
      )

    case "numero":
      return (
        <div>
          <Label htmlFor={campo.id} className="text-base font-semibold mb-2 block">
            {campo.etiqueta}
            {esRequerido && <span className="text-destructive ml-1">*</span>}
          </Label>
          <Input
            id={campo.id}
            type="number"
            placeholder={campo.placeholder}
            value={valor}
            onChange={(e) => onChange(e.target.value)}
            className="text-base h-12"
          />
          {campo.ayuda && <p className="text-sm text-muted-foreground mt-2">{campo.ayuda}</p>}
        </div>
      )

    case "textarea":
      return (
        <div>
          <Label htmlFor={campo.id} className="text-base font-semibold mb-2 block">
            {campo.etiqueta}
            {esRequerido && <span className="text-destructive ml-1">*</span>}
          </Label>
          <textarea
            id={campo.id}
            placeholder={campo.placeholder}
            value={valor}
            onChange={(e) => onChange(e.target.value)}
            className="w-full min-h-[100px] px-3 py-2 text-base border rounded-md"
          />
          {campo.ayuda && <p className="text-sm text-muted-foreground mt-2">{campo.ayuda}</p>}
        </div>
      )

    default: // texto
      return (
        <div>
          <Label htmlFor={campo.id} className="text-base font-semibold mb-2 block">
            {campo.etiqueta}
            {esRequerido && <span className="text-destructive ml-1">*</span>}
          </Label>
          <Input
            id={campo.id}
            type="text"
            placeholder={campo.placeholder}
            value={valor}
            onChange={(e) => onChange(e.target.value)}
            className="text-base h-12"
          />
          {campo.ayuda && <p className="text-sm text-muted-foreground mt-2">{campo.ayuda}</p>}
        </div>
      )
  }
}

/**
 * Zona de carga de archivos
 */
function ZonaCargaArchivo({ onArchivoSeleccionado }: { onArchivoSeleccionado: (archivo: File) => void }) {
  const [archivoCargado, setArchivoCargado] = useState<File | null>(null)

  const manejarCarga = (e: React.ChangeEvent<HTMLInputElement>) => {
    const archivo = e.target.files?.[0]
    if (archivo) {
      setArchivoCargado(archivo)
      onArchivoSeleccionado(archivo)
    }
  }

  return (
    <div className="border-2 border-dashed rounded-lg p-8 text-center bg-muted/20">
      {!archivoCargado ? (
        <div className="space-y-4">
          <div className="text-6xl">📄</div>
          <div>
            <p className="text-lg font-semibold mb-2">Arrastre su archivo PDF aquí</p>
            <p className="text-sm text-muted-foreground mb-4">o haga clic para seleccionar</p>
          </div>
          <input type="file" accept=".pdf" onChange={manejarCarga} className="hidden" id="archivo-input" />
          <Button
            type="button"
            variant="secondary"
            size="lg"
            onClick={() => document.getElementById("archivo-input")?.click()}
          >
            Seleccionar Archivo
          </Button>
        </div>
      ) : (
        <div className="space-y-4 bg-green-50 border-2 border-green-500 rounded-lg p-6">
          <div className="text-6xl">✅</div>
          <div>
            <p className="text-lg font-semibold text-green-700">Archivo Cargado</p>
            <p className="text-sm text-muted-foreground mt-1">{archivoCargado.name}</p>
          </div>
          <Button
            type="button"
            variant="secondary"
            size="lg"
            onClick={() => document.getElementById("archivo-input")?.click()}
          >
            Cambiar Archivo
          </Button>
          <input type="file" accept=".pdf" onChange={manejarCarga} className="hidden" id="archivo-input" />
        </div>
      )}
    </div>
  )
}

// === FORMULARIO PRINCIPAL ===

export function FormularioEvidenciaDinamico() {
  const [datosFormulario, setDatosFormulario] = useState<DatosFormulario>({
    tipoProducto: null,
    archivo: null,
    campos: {},
  })

  // Busca la configuración del rubro seleccionado
  const configuracionActual: ConfiguracionRubro | undefined = CONFIGURACION_RUBROS.find(
    (config) => config.tipo === datosFormulario.tipoProducto,
  )

  const manejarSeleccionTipo = (tipo: string) => {
    setDatosFormulario({
      tipoProducto: tipo,
      archivo: null,
      campos: {},
    })
  }

  const manejarCambioCampo = (idCampo: string, valor: string) => {
    setDatosFormulario({
      ...datosFormulario,
      campos: {
        ...datosFormulario.campos,
        [idCampo]: valor,
      },
    })
  }

  const manejarArchivoSeleccionado = (archivo: File) => {
    setDatosFormulario({
      ...datosFormulario,
      archivo,
    })
  }

  const manejarEnvio = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Datos del formulario:", datosFormulario)
    // TODO: Conectar con Server Action para guardar en base de datos
    alert("Evidencia guardada (simulación). Ver consola para datos.")
  }

  const manejarCancelar = () => {
    setDatosFormulario({
      tipoProducto: null,
      archivo: null,
      campos: {},
    })
  }

  return (
    <div className="space-y-8">
      {/* Encabezado */}
      <div>
        <h1 className="text-4xl font-bold mb-2">Nueva Evidencia de Investigación</h1>
        <p className="text-lg text-muted-foreground">Complete los datos y adjunte su comprobante PDF</p>
      </div>

      <form onSubmit={manejarEnvio} className="space-y-8">
        {/* Selección de Tipo de Producto */}
        <Card className="p-6">
          <h2 className="text-2xl font-semibold mb-6">Tipo de Producto</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {CONFIGURACION_RUBROS.map((config) => (
              <button
                key={config.tipo}
                type="button"
                onClick={() => manejarSeleccionTipo(config.tipo)}
                className={`p-6 border-2 rounded-lg text-left transition-all ${
                  datosFormulario.tipoProducto === config.tipo
                    ? "border-primary bg-primary/5 shadow-md"
                    : "border-border hover:border-primary/50"
                }`}
              >
                <h3 className="text-xl font-bold mb-2">{config.etiqueta}</h3>
                <p className="text-sm text-muted-foreground">{config.descripcion}</p>
              </button>
            ))}
          </div>
        </Card>

        {/* Formulario Dinámico (Generado desde configuración) */}
        {configuracionActual && (
          <Card className="p-6">
            <h2 className="text-2xl font-semibold mb-6">Información del {configuracionActual.etiqueta}</h2>
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              {configuracionActual.campos.map((campo) => (
                <div key={campo.id} className={campo.tipo === "textarea" ? "md:col-span-2" : ""}>
                  <CampoDinamico
                    campo={campo}
                    valor={datosFormulario.campos[campo.id] || ""}
                    onChange={(valor) => manejarCambioCampo(campo.id, valor)}
                  />
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Zona de Carga de Archivo */}
        {configuracionActual && (
          <div>
            <h2 className="text-2xl font-semibold mb-6">Archivo de Evidencia (PDF)</h2>
            <ZonaCargaArchivo onArchivoSeleccionado={manejarArchivoSeleccionado} />
          </div>
        )}

        {/* Botones de Acción */}
        {configuracionActual && (
          <div className="flex gap-4 justify-end pt-6 border-t">
            <Button
              type="button"
              variant="outline"
              size="lg"
              onClick={manejarCancelar}
              className="text-base font-semibold px-8 bg-transparent"
            >
              Cancelar
            </Button>
            <Button type="submit" size="lg" className="text-base font-semibold px-8 bg-primary hover:bg-primary/90">
              Guardar Evidencia
            </Button>
          </div>
        )}
      </form>
    </div>
  )
}
