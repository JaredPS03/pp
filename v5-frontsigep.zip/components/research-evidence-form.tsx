"use client"

import type React from "react"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioCardGroup, type RadioCardOption } from "./radio-card-group"
import { RequirementsChecklist, type ChecklistItem } from "./requirements-checklist"
import { FriendlyFileUpload } from "./friendly-file-upload"

type ProductType = "article" | "book" | "chapter" | "patent" | null

const PRODUCT_TYPES: RadioCardOption[] = [
  {
    id: "article",
    label: "Artículo JCR",
    description: "Artículo publicado en revista indexada",
  },
  {
    id: "book",
    label: "Libro",
    description: "Libro completo o compilación",
  },
  {
    id: "chapter",
    label: "Capítulo",
    description: "Capítulo de libro o libro colaborativo",
  },
  {
    id: "patent",
    label: "Patente",
    description: "Patente registrada o en trámite",
  },
]

const REQUIREMENTS: ChecklistItem[] = [
  {
    id: "readable",
    label: "El PDF es legible",
    description: "Todos los textos e imágenes se ven claramente",
  },
  {
    id: "cover",
    label: "Incluye portada o portadilla",
    description: "Primera página visible del documento",
  },
  {
    id: "index",
    label: "Incluye índice",
    description: "Tabla de contenidos completa",
  },
  {
    id: "metadata",
    label: "Datos de publicación visibles",
    description: "ISBN, Editorial, DOI, etc. según corresponda",
  },
]

const QUARTILES = ["Q1", "Q2", "Q3", "Q4"]

interface FormData {
  productType: ProductType
  file: File | null
  // Article fields
  issn?: string
  journalName?: string
  impactFactor?: string
  quartile?: string
  doi?: string
  // Book fields
  isbn?: string
  publisher?: string
  country?: string
  title?: string
  // Chapter fields
  chapterTitle?: string
  bookTitle?: string
  authors?: string
  // Patent fields
  patentNumber?: string
  patentTitle?: string
  inventorNames?: string
}

export function ResearchEvidenceForm() {
  const [formData, setFormData] = useState<FormData>({
    productType: null,
    file: null,
  })

  const handleProductTypeChange = (value: string) => {
    setFormData({
      ...formData,
      productType: value as ProductType,
    })
  }

  const handleInputChange = (field: keyof FormData, value: string) => {
    setFormData({
      ...formData,
      [field]: value,
    })
  }

  const handleFileSelect = (file: File) => {
    setFormData({
      ...formData,
      file,
    })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Form data:", formData)
    // TODO: Backend - Enviar formData con file al servidor
    // Se debe validar que todos los campos requeridos estén completos
  }

  const handleCancel = () => {
    setFormData({
      productType: null,
      file: null,
    })
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold mb-2">Nueva Evidencia de Investigación</h1>
        <p className="text-lg text-muted-foreground">Complete los datos y adjunte su comprobante PDF</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Product Type Selection */}
        <Card className="p-6">
          <h2 className="text-2xl font-semibold mb-6">Tipo de Producto</h2>
          <RadioCardGroup
            options={PRODUCT_TYPES}
            value={formData.productType || ""}
            onValueChange={handleProductTypeChange}
          />
        </Card>

        {/* Dynamic Form Section */}
        {formData.productType && (
          <Card className="p-6">
            <h2 className="text-2xl font-semibold mb-6">Información del Producto</h2>
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              {/* Article Fields */}
              {formData.productType === "article" && (
                <>
                  <div>
                    <Label htmlFor="issn" className="text-base font-semibold mb-2 block">
                      ISSN
                    </Label>
                    <Input
                      id="issn"
                      placeholder="Ej: 1234-5678"
                      value={formData.issn || ""}
                      onChange={(e) => handleInputChange("issn", e.target.value)}
                      className="text-base h-12"
                    />
                    <p className="text-sm text-muted-foreground mt-2">
                      Lo encuentra en la portada o página legal de la revista
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="journalName" className="text-base font-semibold mb-2 block">
                      Nombre de la Revista
                    </Label>
                    <Input
                      id="journalName"
                      placeholder="Ej: Nature Chemistry"
                      value={formData.journalName || ""}
                      onChange={(e) => handleInputChange("journalName", e.target.value)}
                      className="text-base h-12"
                    />
                    <p className="text-sm text-muted-foreground mt-2">Nombre completo exacto de la publicación</p>
                  </div>

                  <div>
                    <Label htmlFor="impactFactor" className="text-base font-semibold mb-2 block">
                      Factor de Impacto
                    </Label>
                    <Input
                      id="impactFactor"
                      placeholder="Ej: 3.75"
                      value={formData.impactFactor || ""}
                      onChange={(e) => handleInputChange("impactFactor", e.target.value)}
                      className="text-base h-12"
                    />
                    <p className="text-sm text-muted-foreground mt-2">Valor numérico del factor de impacto (JCR)</p>
                  </div>

                  <div>
                    <Label htmlFor="quartile" className="text-base font-semibold mb-2 block">
                      Cuartil
                    </Label>
                    <Select
                      value={formData.quartile || ""}
                      onValueChange={(value) => handleInputChange("quartile", value)}
                    >
                      <SelectTrigger id="quartile" className="text-base h-12">
                        <SelectValue placeholder="Seleccione el cuartil" />
                      </SelectTrigger>
                      <SelectContent>
                        {QUARTILES.map((q) => (
                          <SelectItem key={q} value={q} className="text-base">
                            {q}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-muted-foreground mt-2">
                      Posición de la revista en su área (Q1 es el mejor)
                    </p>
                  </div>

                  <div className="md:col-span-2">
                    <Label htmlFor="doi" className="text-base font-semibold mb-2 block">
                      DOI
                    </Label>
                    <Input
                      id="doi"
                      placeholder="Ej: 10.1234/example.doi"
                      value={formData.doi || ""}
                      onChange={(e) => handleInputChange("doi", e.target.value)}
                      className="text-base h-12"
                    />
                    <p className="text-sm text-muted-foreground mt-2">
                      Identificador único del artículo (en la publicación o ScienceDirect)
                    </p>
                  </div>
                </>
              )}

              {/* Book Fields */}
              {formData.productType === "book" && (
                <>
                  <div>
                    <Label htmlFor="title" className="text-base font-semibold mb-2 block">
                      Título del Libro
                    </Label>
                    <Input
                      id="title"
                      placeholder="Ej: Historia del México Prehispánico"
                      value={formData.title || ""}
                      onChange={(e) => handleInputChange("title", e.target.value)}
                      className="text-base h-12"
                    />
                    <p className="text-sm text-muted-foreground mt-2">Título exacto como aparece en la portada</p>
                  </div>

                  <div>
                    <Label htmlFor="isbn" className="text-base font-semibold mb-2 block">
                      ISBN
                    </Label>
                    <Input
                      id="isbn"
                      placeholder="Ej: 978-0-134-69418-0"
                      value={formData.isbn || ""}
                      onChange={(e) => handleInputChange("isbn", e.target.value)}
                      className="text-base h-12"
                    />
                    <p className="text-sm text-muted-foreground mt-2">Lo encuentra en la página legal del libro</p>
                  </div>

                  <div>
                    <Label htmlFor="publisher" className="text-base font-semibold mb-2 block">
                      Editorial
                    </Label>
                    <Input
                      id="publisher"
                      placeholder="Ej: Fondo de Cultura Económica"
                      value={formData.publisher || ""}
                      onChange={(e) => handleInputChange("publisher", e.target.value)}
                      className="text-base h-12"
                    />
                    <p className="text-sm text-muted-foreground mt-2">Nombre completo de la editorial</p>
                  </div>

                  <div>
                    <Label htmlFor="country" className="text-base font-semibold mb-2 block">
                      País de Publicación
                    </Label>
                    <Input
                      id="country"
                      placeholder="Ej: México"
                      value={formData.country || ""}
                      onChange={(e) => handleInputChange("country", e.target.value)}
                      className="text-base h-12"
                    />
                    <p className="text-sm text-muted-foreground mt-2">País donde se publicó el libro</p>
                  </div>
                </>
              )}

              {/* Chapter Fields */}
              {formData.productType === "chapter" && (
                <>
                  <div className="md:col-span-2">
                    <Label htmlFor="chapterTitle" className="text-base font-semibold mb-2 block">
                      Título del Capítulo
                    </Label>
                    <Input
                      id="chapterTitle"
                      placeholder="Ej: Análisis de sistemas educativos"
                      value={formData.chapterTitle || ""}
                      onChange={(e) => handleInputChange("chapterTitle", e.target.value)}
                      className="text-base h-12"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <Label htmlFor="bookTitle" className="text-base font-semibold mb-2 block">
                      Título del Libro
                    </Label>
                    <Input
                      id="bookTitle"
                      placeholder="Ej: Tendencias en Educación Superior"
                      value={formData.bookTitle || ""}
                      onChange={(e) => handleInputChange("bookTitle", e.target.value)}
                      className="text-base h-12"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <Label htmlFor="authors" className="text-base font-semibold mb-2 block">
                      Autores del Capítulo
                    </Label>
                    <Input
                      id="authors"
                      placeholder="Ej: Dr. Juan Pérez, Dra. María López"
                      value={formData.authors || ""}
                      onChange={(e) => handleInputChange("authors", e.target.value)}
                      className="text-base h-12"
                    />
                    <p className="text-sm text-muted-foreground mt-2">Separe múltiples autores con comas</p>
                  </div>

                  <div>
                    <Label htmlFor="isbn" className="text-base font-semibold mb-2 block">
                      ISBN
                    </Label>
                    <Input
                      id="isbn"
                      placeholder="Ej: 978-0-134-69418-0"
                      value={formData.isbn || ""}
                      onChange={(e) => handleInputChange("isbn", e.target.value)}
                      className="text-base h-12"
                    />
                  </div>

                  <div>
                    <Label htmlFor="publisher" className="text-base font-semibold mb-2 block">
                      Editorial
                    </Label>
                    <Input
                      id="publisher"
                      placeholder="Ej: Fondo de Cultura Económica"
                      value={formData.publisher || ""}
                      onChange={(e) => handleInputChange("publisher", e.target.value)}
                      className="text-base h-12"
                    />
                  </div>
                </>
              )}

              {/* Patent Fields */}
              {formData.productType === "patent" && (
                <>
                  <div>
                    <Label htmlFor="patentNumber" className="text-base font-semibold mb-2 block">
                      Número de Patente
                    </Label>
                    <Input
                      id="patentNumber"
                      placeholder="Ej: US 10,123,456 B2"
                      value={formData.patentNumber || ""}
                      onChange={(e) => handleInputChange("patentNumber", e.target.value)}
                      className="text-base h-12"
                    />
                    <p className="text-sm text-muted-foreground mt-2">Número asignado por la oficina de patentes</p>
                  </div>

                  <div>
                    <Label htmlFor="patentTitle" className="text-base font-semibold mb-2 block">
                      Título de la Patente
                    </Label>
                    <Input
                      id="patentTitle"
                      placeholder="Ej: Sistema de procesamiento avanzado"
                      value={formData.patentTitle || ""}
                      onChange={(e) => handleInputChange("patentTitle", e.target.value)}
                      className="text-base h-12"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <Label htmlFor="inventorNames" className="text-base font-semibold mb-2 block">
                      Nombres de Inventores
                    </Label>
                    <Input
                      id="inventorNames"
                      placeholder="Ej: Dr. Juan Pérez, Ing. Carlos López"
                      value={formData.inventorNames || ""}
                      onChange={(e) => handleInputChange("inventorNames", e.target.value)}
                      className="text-base h-12"
                    />
                    <p className="text-sm text-muted-foreground mt-2">Separe múltiples nombres con comas</p>
                  </div>
                </>
              )}
            </div>
          </Card>
        )}

        {/* Requirements Checklist */}
        {formData.productType && <RequirementsChecklist title="Verificación de Requisitos" items={REQUIREMENTS} />}

        {/* File Upload */}
        {formData.productType && (
          <div>
            <h2 className="text-2xl font-semibold mb-6">Archivo de Evidencia</h2>
            <FriendlyFileUpload onFileSelect={handleFileSelect} />
          </div>
        )}

        {/* Action Buttons */}
        {formData.productType && (
          <div className="flex gap-4 justify-end pt-6 border-t">
            <Button
              type="button"
              variant="outline"
              size="lg"
              onClick={handleCancel}
              className="text-base font-semibold px-8 bg-transparent"
            >
              Cancelar
            </Button>
            <Button type="submit" size="lg" className="text-base font-semibold px-8 bg-primary hover:bg-primary/90">
              Guardar Evidencia
            </Button>
          </div>
        )}
      </form>
    </div>
  )
}
