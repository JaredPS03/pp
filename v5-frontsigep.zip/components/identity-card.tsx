"use client"

import { Lock } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface IdentityCardProps {
  rfc: string
  curp: string
  employeeNumber: string
}

export function IdentityCard({ rfc, curp, employeeNumber }: IdentityCardProps) {
  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="bg-muted/50 pb-3">
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">Tarjeta de Identidad</CardTitle>
            <CardDescription className="text-xs mt-1">Datos validados por RRHH</CardDescription>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <Lock className="h-3.5 w-3.5" />
            <span>Protegido</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-6 space-y-6">
        <div className="space-y-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">RFC</p>
          <p className="text-base font-medium">{rfc}</p>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">CURP</p>
          <p className="text-base font-medium">{curp}</p>
        </div>

        <div className="space-y-2">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Número de Empleado</p>
          <p className="text-base font-medium">{employeeNumber}</p>
        </div>

        <div className="mt-4 p-3 bg-blue-50 border border-blue-100 rounded-md">
          <p className="text-xs text-blue-700 leading-relaxed">
            <span className="font-semibold">Nota:</span> Estos datos son validados por RRHH. Para correcciones, acuda a
            la dirección de Recursos Humanos.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
