"use client"

import type React from "react"

import { useState } from "react"
import { AlertCircle, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface ProfileFormProps {
  initialData?: {
    academicDegree?: string
    category?: string
    phone?: string
    institutionalEmail?: string
  }
}

export function ProfileForm({ initialData }: ProfileFormProps) {
  const [formData, setFormData] = useState({
    academicDegree: initialData?.academicDegree || "",
    category: initialData?.category || "",
    phone: initialData?.phone || "",
    institutionalEmail: initialData?.institutionalEmail || "",
  })

  const [errors, setErrors] = useState<string[]>([])
  const [uploadedFile, setUploadedFile] = useState<string | null>(null)
  const [academicDegreeChanged, setAcademicDegreeChanged] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const validateForm = () => {
    const newErrors: string[] = []

    if (!formData.academicDegree) {
      newErrors.push("Grado Académico")
    }
    if (!formData.category) {
      newErrors.push("Categoría")
    }
    if (!formData.phone) {
      newErrors.push("Teléfono")
    }
    if (!formData.institutionalEmail) {
      newErrors.push("Correo Institucional")
    }
    if (academicDegreeChanged && !uploadedFile) {
      newErrors.push("Comprobante de Grado Académico")
    }

    setErrors(newErrors)
    return newErrors.length === 0
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validateForm()) {
      setIsLoading(true)
      // TODO_BACKEND: Enviar datos a base de datos
      console.log("[v0] Guardando cambios:", { formData, uploadedFile })
      setTimeout(() => {
        setIsLoading(false)
        setAcademicDegreeChanged(false)
        setUploadedFile(null)
      }, 1500)
    }
  }

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg">Datos Personales</CardTitle>
        <CardDescription className="text-xs mt-1">Actualiza tu información académica y de contacto</CardDescription>
      </CardHeader>

      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Errores */}
          {errors.length > 0 && (
            <Alert className="border-orange-200 bg-orange-50">
              <AlertCircle className="h-4 w-4 text-orange-600" />
              <AlertDescription className="text-orange-700 text-sm">
                <p className="font-semibold mb-2">Por favor, completa los siguientes campos:</p>
                <p className="text-xs">{errors.join(", ")}</p>
              </AlertDescription>
            </Alert>
          )}

          {/* Grado Académico */}
          <div className="space-y-3">
            <Label htmlFor="degree" className="text-sm font-semibold">
              Grado Académico Máximo <span className="text-red-500">*</span>
            </Label>
            <Select
              value={formData.academicDegree}
              onValueChange={(value) => {
                setFormData({ ...formData, academicDegree: value })
                setAcademicDegreeChanged(true)
              }}
            >
              <SelectTrigger id="degree" className="h-10">
                <SelectValue placeholder="Selecciona tu grado académico" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="licenciatura">Licenciatura</SelectItem>
                <SelectItem value="especialidad">Especialidad</SelectItem>
                <SelectItem value="maestria">Maestría</SelectItem>
                <SelectItem value="doctorado">Doctorado</SelectItem>
                <SelectItem value="postdoctorado">Postdoctorado</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Si cambias este campo, necesitaremos el comprobante actualizado.
            </p>
          </div>

          {/* Comprobante si cambió */}
          {academicDegreeChanged && (
            <div className="space-y-3 p-4 bg-blue-50 border border-blue-100 rounded-lg">
              <Label className="text-sm font-semibold text-blue-900">
                Cargar Comprobante de Grado Académico <span className="text-red-500">*</span>
              </Label>
              <div className="border-2 border-dashed border-blue-200 rounded-lg p-6 text-center hover:bg-blue-50/50 transition-colors cursor-pointer">
                <input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      setUploadedFile(e.target.files[0].name)
                    }
                  }}
                  className="hidden"
                  id="degree-upload"
                />
                <label htmlFor="degree-upload" className="cursor-pointer block">
                  <Upload className="h-6 w-6 mx-auto text-blue-600 mb-2" />
                  <p className="text-sm font-medium text-blue-900">
                    {uploadedFile ? `Archivo: ${uploadedFile}` : "Arrastra tu comprobante aquí"}
                  </p>
                  <p className="text-xs text-blue-700 mt-1">PDF, JPG o PNG (máx 10MB)</p>
                </label>
              </div>
            </div>
          )}

          {/* Categoría */}
          <div className="space-y-3">
            <Label htmlFor="category" className="text-sm font-semibold">
              Categoría <span className="text-red-500">*</span>
            </Label>
            <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
              <SelectTrigger id="category" className="h-10">
                <SelectValue placeholder="Selecciona tu categoría" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ptc">PTC (Profesor de Tiempo Completo)</SelectItem>
                <SelectItem value="tc">TC (Profesor de Tiempo Compartido)</SelectItem>
                <SelectItem value="asignatura">Por Asignatura</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Teléfono */}
          <div className="space-y-3">
            <Label htmlFor="phone" className="text-sm font-semibold">
              Teléfono <span className="text-red-500">*</span>
            </Label>
            <Input
              id="phone"
              type="tel"
              placeholder="Ej: +52 951 234 5678"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="h-10"
            />
          </div>

          {/* Correo Institucional */}
          <div className="space-y-3">
            <Label htmlFor="email" className="text-sm font-semibold">
              Correo Institucional <span className="text-red-500">*</span>
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="tu.nombre@uabjo.edu.mx"
              value={formData.institutionalEmail}
              onChange={(e) => setFormData({ ...formData, institutionalEmail: e.target.value })}
              className="h-10"
            />
          </div>

          {/* Botones */}
          <div className="flex gap-3 pt-4 border-t">
            <Button
              type="submit"
              className="flex-1 h-10 bg-primary hover:bg-primary/90 text-primary-foreground"
              disabled={isLoading}
            >
              {isLoading ? "Guardando..." : "Guardar Cambios"}
            </Button>
            <Button
              type="button"
              variant="outline"
              className="flex-1 h-10 bg-transparent"
              onClick={() => {
                setFormData(initialData || { academicDegree: "", category: "", phone: "", institutionalEmail: "" })
                setErrors([])
                setAcademicDegreeChanged(false)
                setUploadedFile(null)
              }}
            >
              Regresar al Inicio
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
